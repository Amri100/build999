import { useState, useCallback, useMemo, useEffect, useRef } from 'react';
import { useDropzone } from 'react-dropzone';
import { 
  Upload, ChevronRight, Globe, Download, Play, 
  CheckCircle2, Loader2, Square, CheckSquare, Layers, 
  History, Search, Trash2,
  Moon, Sun,
  Keyboard, SortAsc, SortDesc,
  BookOpen, Shield, AlertTriangle,
  Edit3, Plus,
  ArrowLeftRight, Lock, Unlock,
  Undo2,
  BarChart3,
  MoreHorizontal, Copy
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { toast } from 'sonner';
import JSZip from 'jszip';
import { motion, AnimatePresence } from 'motion/react';
import type { GameScriptEntry, TranslationProject, TranslationProvider, ProjectStats } from '@/types';
import { DonateSection } from '@/components/DonateSection';
import { 
  parseRPGMaker, parseKiriKiri, parseRenPy, parseGenericJSON, parseCSV, parseSRT,
  applyTranslations
} from '@/services/parserService';
import { translateGameText } from '@/services/translationService';
import { saveToTM, getTM, getTMStats } from '@/services/tmService';
import { translateBatchOffline } from '@/services/offlineDictionary';
import { 
  saveGlossaryEntry, deleteGlossaryEntry, searchGlossary, 
  getGlossaryStats, GLOSSARY_CATEGORIES, applyGlossaryTemplate
} from '@/services/glossaryService';
import { runQAChecks, type QAIssue } from '@/services/qaService';
import { addHistoryEntry, undoLastChange, getHistory, formatHistoryTime } from '@/services/historyService';

const LANGUAGES = [
  { code: 'id', name: 'Indonesian', flag: '🇮🇩' },
  { code: 'en', name: 'English', flag: '🇺🇸' },
  { code: 'es', name: 'Spanish', flag: '🇪🇸' },
  { code: 'fr', name: 'French', flag: '🇫🇷' },
  { code: 'de', name: 'German', flag: '🇩🇪' },
  { code: 'it', name: 'Italian', flag: '🇮🇹' },
  { code: 'pt', name: 'Portuguese', flag: '🇵🇹' },
  { code: 'ru', name: 'Russian', flag: '🇷🇺' },
  { code: 'ja', name: 'Japanese', flag: '🇯🇵' },
  { code: 'ko', name: 'Korean', flag: '🇰🇷' },
  { code: 'zh', name: 'Chinese', flag: '🇨🇳' },
  { code: 'ar', name: 'Arabic', flag: '🇸🇦' },
  { code: 'vi', name: 'Vietnamese', flag: '🇻🇳' },
  { code: 'th', name: 'Thai', flag: '🇹🇭' },
];

const PROVIDERS = [
  { id: 'offline', name: 'Offline Dictionary', status: 'offline', desc: 'No API needed, EN-JP-ID only' },
  { id: 'mymemory', name: 'MyMemory', status: 'free', desc: 'Free, 5000 chars/day limit' },
  { id: 'lingva', name: 'Lingva', status: 'free', desc: 'Free Google Translate alternative' },
  { id: 'google', name: 'Google Translate', status: 'free', desc: 'Free, may have rate limits' },
  { id: 'bing', name: 'Bing Translate', status: 'pro', desc: 'Requires API key' },
  { id: 'gemini', name: 'Gemini AI', status: 'pro', desc: 'Requires API key' },
] as const;

const ENGINES = [
  { id: 'rpgmaker', name: 'RPG Maker MV/MZ', ext: '.json', desc: 'Maps, Events, Actors, Items, System', color: 'bg-amber-500' },
  { id: 'kirikiri', name: 'KiriKiri / KAG', ext: '.ks, .tjs', desc: 'Visual Novel engine', color: 'bg-blue-500' },
  { id: 'renpy', name: "Ren'Py", ext: '.rpy', desc: 'Python-based VN engine', color: 'bg-purple-500' },
  { id: 'unity', name: 'Unity / JSON', ext: '.json', desc: 'Generic JSON localization', color: 'bg-indigo-500' },
  { id: 'subtitles', name: 'Subtitles / SRT', ext: '.srt', desc: 'Movie/cutscene subtitles', color: 'bg-emerald-500' },
  { id: 'generic', name: 'Generic / CSV', ext: '.csv, .txt', desc: 'Spreadsheet data', color: 'bg-cyan-500' },
];

export default function App() {
  const [project, setProject] = useState<TranslationProject | null>(null);
  const [isTranslating, setIsTranslating] = useState(false);
  const [targetLang, setTargetLang] = useState('Indonesian');
  const [sourceLang, setSourceLang] = useState('Auto Detect');
  const [provider, setProvider] = useState<TranslationProvider | 'offline'>('offline');
  const [activeTab, setActiveTab] = useState('upload');
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [searchQuery, setSearchQuery] = useState('');
  const [darkMode, setDarkMode] = useState(true);
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [filterStatus, setFilterStatus] = useState<'all' | 'translated' | 'untranslated' | 'reviewed'>('all');
  const [translationProgress, setTranslationProgress] = useState(0);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [fontSize] = useState(14);
  const [showOnlyIssues, setShowOnlyIssues] = useState(false);
  const [editingEntry, setEditingEntry] = useState<GameScriptEntry | null>(null);
  const [entryNotes, setEntryNotes] = useState('');
  const [entryTags, setEntryTags] = useState('');
  const [entryMaxLength, setEntryMaxLength] = useState<number | undefined>();
  const [showEntryDialog, setShowEntryDialog] = useState(false);
  const [showFindReplace, setShowFindReplace] = useState(false);
  const [showQADialog, setShowQADialog] = useState(false);
  const [showStatsDialog, setShowStatsDialog] = useState(false);
  const [showHistoryDialog, setShowHistoryDialog] = useState(false);
  const [findText, setFindText] = useState('');
  const [replaceText, setReplaceText] = useState('');
  const [qaIssues, setQaIssues] = useState<QAIssue[]>([]);
  const [glossarySearch, setGlossarySearch] = useState('');
  const [glossaryCategory, setGlossaryCategory] = useState<string>('all');
  const [editingGlossaryEntry, setEditingGlossaryEntry] = useState<any>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [lastSelectedId, setLastSelectedId] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem('gs_project_v3');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        setProject(parsed);
      } catch (e) {
        console.error('Failed to load saved project');
      }
    }
  }, []);

  useEffect(() => {
    if (project) {
      localStorage.setItem('gs_project_v3', JSON.stringify({ ...project, updatedAt: Date.now() }));
    }
  }, [project]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        switch (e.key.toLowerCase()) {
          case 'o':
            e.preventDefault();
            fileInputRef.current?.click();
            break;
          case 's':
            e.preventDefault();
            if (project) handleExport();
            break;
          case 'a':
            if (activeTab === 'editor') {
              e.preventDefault();
              toggleSelectAll();
            }
            break;
          case 'f':
            e.preventDefault();
            if (activeTab === 'editor') setShowFindReplace(true);
            break;
          case 'z':
            if (e.shiftKey) return;
            e.preventDefault();
            handleUndo();
            break;
          case 'h':
            e.preventDefault();
            setShowShortcuts(true);
            break;
        }
      }
      if (e.key === 'Escape') {
        setSelectedIds(new Set());
        setShowFindReplace(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [project, selectedIds, activeTab]);

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    if (acceptedFiles.length === 0) return;

    const newFiles: { name: string; content: string }[] = [];
    let allEntries: GameScriptEntry[] = [];
    let detectedEngine: TranslationProject["engine"] = "generic";

    toast.promise(
      (async () => {
        for (const file of acceptedFiles) {
          const content = await file.text();
          newFiles.push({ name: file.name, content });

          if (file.name.endsWith('.json')) {
            try {
              const data = JSON.parse(content);
              if (data.events || (Array.isArray(data) && data[0] === null)) {
                detectedEngine = "rpgmaker";
                allEntries = [...allEntries, ...parseRPGMaker(file.name, content)];
              } else {
                detectedEngine = "unity";
                allEntries = [...allEntries, ...parseGenericJSON(file.name, content)];
              }
            } catch (e) {
              detectedEngine = "generic";
              allEntries = [...allEntries, ...parseGenericJSON(file.name, content)];
            }
          } else if (file.name.endsWith('.ks') || file.name.endsWith('.tjs')) {
            detectedEngine = "kirikiri";
            allEntries = [...allEntries, ...parseKiriKiri(file.name, content)];
          } else if (file.name.endsWith('.rpy')) {
            detectedEngine = "renpy";
            allEntries = [...allEntries, ...parseRenPy(file.name, content)];
          } else if (file.name.endsWith('.csv')) {
            detectedEngine = "generic";
            allEntries = [...allEntries, ...parseCSV(file.name, content)];
          } else if (file.name.endsWith('.srt')) {
            detectedEngine = "subtitles";
            allEntries = [...allEntries, ...parseSRT(file.name, content)];
          } else {
            detectedEngine = "generic";
            allEntries = [...allEntries, {
              id: `raw-${file.name}-${Date.now()}`,
              original: content,
              translated: "",
              path: "raw",
              context: "Raw File Content",
              createdAt: Date.now(),
              tags: [],
              reviewed: false,
              locked: false,
            }];
          }
        }

        if (allEntries.length > 0) {
          const enrichedEntries = allEntries.map(e => ({
            ...e,
            createdAt: Date.now(),
            tags: [],
            reviewed: false,
            locked: false,
          }));
          
          setProject({
            id: Math.random().toString(36).substr(2, 9),
            name: acceptedFiles[0].name.split('.')[0] || "New Project",
            engine: detectedEngine,
            entries: enrichedEntries,
            files: newFiles,
            createdAt: Date.now(),
            sourceLang,
            targetLang,
          });
          setActiveTab('editor');
          setSelectedIds(new Set());
          
          addHistoryEntry('import', `Imported ${acceptedFiles.length} file(s)`, []);
          
          return { fileCount: acceptedFiles.length, entryCount: allEntries.length };
        }
        throw new Error('No entries found in files');
      })(),
      {
        loading: 'Parsing files...',
        success: (data) => `Loaded ${data.entryCount} strings from ${data.fileCount} file(s)`,
        error: 'Failed to parse files',
      }
    );
  }, [sourceLang, targetLang]);

  const { getRootProps, getInputProps, isDragActive, open } = useDropzone({ 
    onDrop,
    noClick: true,
    accept: {
      'application/json': ['.json'],
      'text/plain': ['.ks', '.tjs', '.rpy', '.csv', '.srt', '.txt'],
    }
  });

  const handleTranslateBatch = async (ids?: string[]) => {
    if (!project) return;
    setIsTranslating(true);
    setTranslationProgress(0);

    const targetIds = ids || Array.from(selectedIds);
    const entriesToTranslate = project.entries.filter(e => 
      targetIds.includes(e.id) && !e.locked
    );
    
    if (entriesToTranslate.length === 0) {
      toast.error('No entries selected for translation (or all are locked)');
      setIsTranslating(false);
      return;
    }

    const batchSize = 5;
    const updatedEntries = [...project.entries];
    let completed = 0;
    const changes: { entryId: string; original: string; previous: string; current: string }[] = [];

    for (let i = 0; i < entriesToTranslate.length; i += batchSize) {
      const batch = entriesToTranslate.slice(i, i + batchSize);
      const texts = batch.map(e => e.original);
      
      let results: { original: string; translated: string }[];
      
      if (provider === 'offline') {
        const offlineResults = translateBatchOffline(texts, sourceLang, targetLang);
        results = offlineResults.map(r => ({ original: r.original, translated: r.translated }));
      } else {
        results = await translateGameText(texts, targetLang, project.engine, provider as TranslationProvider);
      }
      
      results.forEach((res, idx) => {
        const entry = batch[idx];
        const prevTranslated = entry.translated;
        
        const entryIdx = updatedEntries.findIndex(e => e.id === entry.id);
        if (entryIdx !== -1) {
          updatedEntries[entryIdx] = {
            ...updatedEntries[entryIdx],
            translated: res.translated,
            tmEngineMatch: project.engine,
            updatedAt: Date.now(),
          };
          
          changes.push({
            entryId: entry.id,
            original: entry.original,
            previous: prevTranslated,
            current: res.translated,
          });
        }
        
        saveToTM(entry.original, res.translated, targetLang, project.engine);
      });

      completed += batch.length;
      setTranslationProgress(Math.round((completed / entriesToTranslate.length) * 100));
      setProject({ ...project, entries: updatedEntries });
    }

    addHistoryEntry('translate', `Translated ${entriesToTranslate.length} entries`, changes);
    
    setIsTranslating(false);
    setTranslationProgress(0);
    toast.success(`Translated ${entriesToTranslate.length} entries`);
  };

  const handleExport = async () => {
    if (!project) return;
    
    toast.promise(
      (async () => {
        const zip = new JSZip();
        
        project.files.forEach(file => {
          const fileEntries = project.entries.filter(e => e.id.includes(file.name));
          const translatedContent = applyTranslations(file.content, fileEntries, project.engine);
          zip.file(file.name, translatedContent);
        });

        const blob = await zip.generateAsync({ type: 'blob' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${project.name}_translated.zip`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
      })(),
      {
        loading: 'Exporting files...',
        success: 'Files exported with original names preserved!',
        error: 'Export failed',
      }
    );
  };

  const handleUndo = () => {
    const lastChange = undoLastChange();
    if (lastChange && project) {
      const updatedEntries = [...project.entries];
      lastChange.changes.forEach(change => {
        const idx = updatedEntries.findIndex(e => e.id === change.entryId);
        if (idx !== -1) {
          updatedEntries[idx] = { ...updatedEntries[idx], translated: change.previous };
        }
      });
      setProject({ ...project, entries: updatedEntries });
      toast.success('Undo successful');
    } else {
      toast.info('Nothing to undo');
    }
  };

  const handleFindReplace = () => {
    if (!project || !findText) return;
    
    let count = 0;
    const changes: { entryId: string; original: string; previous: string; current: string }[] = [];
    
    const newEntries = project.entries.map(entry => {
      if (entry.translated && entry.translated.includes(findText)) {
        count++;
        const prev = entry.translated;
        const current = entry.translated.split(findText).join(replaceText);
        changes.push({ entryId: entry.id, original: entry.original, previous: prev, current });
        return { ...entry, translated: current, updatedAt: Date.now() };
      }
      return entry;
    });
    
    setProject({ ...project, entries: newEntries });
    addHistoryEntry('find_replace', `Replaced "${findText}" with "${replaceText}"`, changes);
    toast.success(`Replaced in ${count} entries`);
    setFindText('');
    setReplaceText('');
    setShowFindReplace(false);
  };

  const handleQACheck = () => {
    if (!project) return;
    
    const result = runQAChecks(project.entries, targetLang);
    setQaIssues(result.issues);
    setShowQADialog(true);
    
    if (result.summary.total === 0) {
      toast.success('No issues found! Your translation looks good.');
    } else {
      toast.info(`Found ${result.summary.total} issues`);
    }
  };

  const handleToggleReview = (entryId: string) => {
    if (!project) return;
    const updated = project.entries.map(e => 
      e.id === entryId ? { ...e, reviewed: !e.reviewed, reviewedBy: !e.reviewed ? 'You' : undefined } : e
    );
    setProject({ ...project, entries: updated });
  };

  const handleToggleLock = (entryId: string) => {
    if (!project) return;
    const updated = project.entries.map(e => 
      e.id === entryId ? { ...e, locked: !e.locked } : e
    );
    setProject({ ...project, entries: updated });
    toast.success('Entry ' + (updated.find(e => e.id === entryId)?.locked ? 'locked' : 'unlocked'));
  };

  const handleSaveEntryDetails = () => {
    if (!project || !editingEntry) return;
    
    const updated = project.entries.map(e => 
      e.id === editingEntry.id ? { 
        ...e, 
        notes: entryNotes,
        tags: entryTags.split(',').map(t => t.trim()).filter(Boolean),
        maxLength: entryMaxLength,
        updatedAt: Date.now(),
      } : e
    );
    
    setProject({ ...project, entries: updated });
    setShowEntryDialog(false);
    toast.success('Entry details saved');
  };

  const openEntryDialog = (entry: GameScriptEntry) => {
    setEditingEntry(entry);
    setEntryNotes(entry.notes || '');
    setEntryTags(entry.tags?.join(', ') || '');
    setEntryMaxLength(entry.maxLength);
    setShowEntryDialog(true);
  };

  const handleGlossarySave = (entry: any) => {
    saveGlossaryEntry(entry);
    toast.success('Glossary entry saved');
    setEditingGlossaryEntry(null);
  };

  const handleGlossaryDelete = (id: string) => {
    if (confirm('Delete this glossary entry?')) {
      deleteGlossaryEntry(id);
      toast.success('Glossary entry deleted');
    }
  };

  const toggleSelect = (id: string, event?: React.MouseEvent) => {
    const newSelected = new Set(selectedIds);
    
    if (event?.shiftKey && lastSelectedId) {
      const ids = filteredEntries.map(e => e.id);
      const start = ids.indexOf(lastSelectedId);
      const end = ids.indexOf(id);
      
      if (start !== -1 && end !== -1) {
        const range = ids.slice(Math.min(start, end), Math.max(start, end) + 1);
        const isSelecting = !selectedIds.has(id);
        range.forEach(rangeId => {
          if (isSelecting) newSelected.add(rangeId);
          else newSelected.delete(rangeId);
        });
      }
    } else {
      if (newSelected.has(id)) newSelected.delete(id);
      else newSelected.add(id);
    }
    
    setSelectedIds(newSelected);
    setLastSelectedId(id);
  };

  const toggleSelectAll = () => {
    if (selectedIds.size === filteredEntries.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(filteredEntries.map(e => e.id)));
    }
  };

  const filteredEntries = useMemo(() => {
    if (!project) return [];
    
    let entries = [...project.entries];
    
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      entries = entries.filter(e => 
        e.original.toLowerCase().includes(q) || 
        e.translated.toLowerCase().includes(q) ||
        e.context?.toLowerCase().includes(q) ||
        e.notes?.toLowerCase().includes(q) ||
        e.tags?.some(t => t.toLowerCase().includes(q))
      );
    }
    
    if (filterStatus === 'translated') entries = entries.filter(e => e.translated);
    else if (filterStatus === 'untranslated') entries = entries.filter(e => !e.translated);
    else if (filterStatus === 'reviewed') entries = entries.filter(e => e.reviewed);
    
    if (showOnlyIssues && qaIssues.length > 0) {
      const issueEntryIds = new Set(qaIssues.map(i => i.entryId));
      entries = entries.filter(e => issueEntryIds.has(e.id));
    }
    
    entries.sort((a, b) => {
      const aVal = a.original || '';
      const bVal = b.original || '';
      return sortOrder === 'asc' ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
    });
    
    return entries;
  }, [project, searchQuery, filterStatus, sortOrder, showOnlyIssues, qaIssues]);

  const stats: ProjectStats = useMemo(() => {
    if (!project) return { total: 0, translated: 0, reviewed: 0, locked: 0, withNotes: 0, byTag: {}, completionPercent: 0 };
    
    const entries = project.entries;
    const byTag: Record<string, number> = {};
    
    entries.forEach(e => {
      e.tags?.forEach(tag => {
        byTag[tag] = (byTag[tag] || 0) + 1;
      });
    });
    
    return {
      total: entries.length,
      translated: entries.filter(e => e.translated).length,
      reviewed: entries.filter(e => e.reviewed).length,
      locked: entries.filter(e => e.locked).length,
      withNotes: entries.filter(e => e.notes).length,
      byTag,
      completionPercent: entries.length > 0 ? Math.round((entries.filter(e => e.translated).length / entries.length) * 100) : 0,
    };
  }, [project]);

  const tmStats = useMemo(() => getTMStats(), [activeTab]);
  const glossaryStats = useMemo(() => getGlossaryStats(), [activeTab]);
  const history = useMemo(() => getHistory(), [showHistoryDialog]);
  // Offline dictionary stats available if needed
  // const offlineStats = useMemo(() => getOfflineDictionaryStats(), []);
  const filteredGlossary = useMemo(() => searchGlossary(glossarySearch, glossaryCategory === 'all' ? undefined : glossaryCategory), [glossarySearch, glossaryCategory]);

  return (
    <div className={cn("min-h-screen flex flex-col", darkMode ? "bg-gradient-main text-white" : "bg-gray-50 text-gray-900")}>
      <input type="file" ref={fileInputRef} className="hidden" multiple accept=".json,.ks,.tjs,.rpy,.csv,.srt,.txt" onChange={(e) => e.target.files && onDrop(Array.from(e.target.files))} />

      <header className={cn("border-b sticky top-0 z-50 backdrop-blur-md", darkMode ? "border-white/5 bg-[#0B0118]/80" : "border-gray-200 bg-white/80")}>
        <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => setActiveTab('upload')}>
            <div className="w-8 h-8 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center shadow-lg">
              <Globe className="text-white w-5 h-5" />
            </div>
            <div>
              <h1 className="font-bold text-sm tracking-tight">Game Translation Hub</h1>
              <span className={cn("text-[10px]", darkMode ? "opacity-50" : "text-gray-500")}>v3.5 • Professional Localization Tool</span>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            <DonateSection />
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setDarkMode(!darkMode)}>
              {darkMode ? <Sun size={16} /> : <Moon size={16} />}
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setShowShortcuts(true)}>
              <Keyboard size={16} />
            </Button>
          </div>
        </div>
      </header>

      <main className="flex-1 max-w-7xl mx-auto w-full p-4">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="hidden">
            <TabsTrigger value="upload">Upload</TabsTrigger>
            <TabsTrigger value="editor">Editor</TabsTrigger>
            <TabsTrigger value="tm">TM</TabsTrigger>
            <TabsTrigger value="glossary">Glossary</TabsTrigger>
          </TabsList>

          <AnimatePresence mode="wait">
            <TabsContent value="upload" className="mt-0">
              <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="flex flex-col items-center pt-6">
                <div className="text-center mb-8 max-w-2xl">
                  <div className="inline-flex items-center gap-2 bg-gradient-to-r from-purple-500/10 to-pink-500/10 text-purple-400 px-3 py-1 rounded-full text-[10px] font-bold border border-purple-500/20 mb-4">
                    <span className="w-1.5 h-1.5 bg-purple-400 rounded-full animate-pulse" />
                    v3.5 Professional Edition
                  </div>
                  <h2 className="text-4xl font-bold tracking-tight mb-3">
                    Terjemahkan Game <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-400">Tanpa Sentuh Kode</span>
                  </h2>
                  <p className={cn("text-sm", darkMode ? "text-white/50" : "text-gray-600")}>
                    Tools profesional untuk lokalisasi game dengan Translation Memory, Glossary, QA Checks, dan Offline Dictionary.
                  </p>
                </div>

                <div {...getRootProps()} onClick={open} className={cn(
                  "w-full max-w-3xl rounded-2xl border-2 border-dashed p-10 mb-6 text-center cursor-pointer transition-all",
                  isDragActive ? "border-purple-500 bg-purple-500/10" : darkMode ? "border-white/10 hover:border-white/20 bg-white/5" : "border-gray-300 hover:border-gray-400 bg-white"
                )}>
                  <input {...getInputProps()} />
                  <Upload className={cn("w-10 h-10 mx-auto mb-3", isDragActive ? "text-purple-400" : darkMode ? "text-white/30" : "text-gray-400")} />
                  <p className="font-medium">{isDragActive ? 'Drop files here...' : 'Drag & drop files here'}</p>
                  <p className={cn("text-xs mt-1", darkMode ? "text-white/40" : "text-gray-500")}>.json .ks .tjs .rpy .csv .srt</p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 w-full max-w-3xl mb-6">
                  {ENGINES.map((engine) => (
                    <div key={engine.id} className={cn("p-3 rounded-xl border transition-all", darkMode ? "bg-white/5 border-white/10" : "bg-white border-gray-200")}>
                      <div className="flex items-center gap-2">
                        <div className={cn("w-8 h-8 rounded-lg flex items-center justify-center text-white text-xs", engine.color)}>
                          {engine.ext.split(',')[0].replace('.', '')}
                        </div>
                        <div>
                          <h4 className="text-xs font-bold">{engine.name}</h4>
                          <p className={cn("text-[10px]", darkMode ? "text-white/40" : "text-gray-500")}>{engine.desc}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className={cn("w-full max-w-3xl rounded-xl p-4 border mb-6", darkMode ? "bg-white/5 border-white/10" : "bg-white border-gray-200")}>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <label className={cn("text-[10px] font-bold uppercase", darkMode ? "text-white/40" : "text-gray-500")}>Source</label>
                      <Select value={sourceLang} onValueChange={setSourceLang}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Auto Detect">Auto Detect</SelectItem>
                          {LANGUAGES.map(l => <SelectItem key={l.code} value={l.name}>{l.flag} {l.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className={cn("text-[10px] font-bold uppercase", darkMode ? "text-white/40" : "text-gray-500")}>Target</label>
                      <Select value={targetLang} onValueChange={setTargetLang}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {LANGUAGES.map(l => <SelectItem key={l.code} value={l.name}>{l.flag} {l.name}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <label className={cn("text-[10px] font-bold uppercase", darkMode ? "text-white/40" : "text-gray-500")}>Provider</label>
                      <Select value={provider} onValueChange={(v) => setProvider(v as any)}>
                        <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          {PROVIDERS.map(p => <SelectItem key={p.id} value={p.id}><span className="flex items-center gap-2">{p.name}<Badge variant={p.status === 'free' ? 'default' : p.status === 'offline' ? 'secondary' : 'outline'} className="text-[8px]">{p.status}</Badge></span></SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                {project && (
                  <Button onClick={() => setActiveTab('editor')} size="lg" className="gap-2">
                    Open Editor <ChevronRight size={18} />
                  </Button>
                )}
              </motion.div>
            </TabsContent>

            <TabsContent value="editor" className="mt-0">
              {project && (
                <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex flex-col h-[calc(100vh-8rem)]">
                  <div className="flex items-center justify-between mb-3 flex-wrap gap-2">
                    <div className="flex items-center gap-3">
                      <h2 className="text-lg font-bold">{project.name}</h2>
                      <Badge variant="outline">{project.engine}</Badge>
                      <div className="flex items-center gap-2 text-xs">
                        <span className={cn("px-2 py-0.5 rounded-full", stats.completionPercent === 100 ? "bg-green-500/20 text-green-400" : "bg-purple-500/20 text-purple-400")}>
                          {stats.completionPercent}%
                        </span>
                        <span className={darkMode ? "text-white/40" : "text-gray-500"}>
                          {stats.translated}/{stats.total}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-1 flex-wrap">
                      <Button variant="outline" size="sm" onClick={() => setShowFindReplace(true)}><Search size={14} className="mr-1" /> Find</Button>
                      <Button variant="outline" size="sm" onClick={handleUndo}><Undo2 size={14} className="mr-1" /> Undo</Button>
                      <Button variant="outline" size="sm" onClick={handleQACheck}><Shield size={14} className="mr-1" /> QA</Button>
                      <Button variant="outline" size="sm" onClick={() => setShowStatsDialog(true)}><BarChart3 size={14} className="mr-1" /> Stats</Button>
                      <Button variant="outline" size="sm" onClick={() => setShowHistoryDialog(true)}><History size={14} className="mr-1" /> History</Button>
                      <Button size="sm" onClick={() => handleTranslateBatch(project.entries.filter(e => !e.translated && !e.locked).map(e => e.id))} disabled={isTranslating}>
                        {isTranslating ? <><Loader2 className="animate-spin mr-1" size={14} /> {translationProgress}%</> : <><Play size={14} className="mr-1" /> Translate All</>}
                      </Button>
                      <Button variant="secondary" size="sm" onClick={handleExport}><Download size={14} className="mr-1" /> Export</Button>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mb-3">
                    <div className="relative flex-1 max-w-xs">
                      <Search className={cn("absolute left-2 top-1/2 -translate-y-1/2", darkMode ? "text-white/30" : "text-gray-400")} size={14} />
                      <Input value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)} placeholder="Search..." className="pl-7 h-8 text-sm" />
                    </div>
                    <Select value={filterStatus} onValueChange={(v) => setFilterStatus(v as any)}>
                      <SelectTrigger className="w-28 h-8 text-xs"><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">All</SelectItem>
                        <SelectItem value="translated">Done</SelectItem>
                        <SelectItem value="untranslated">Pending</SelectItem>
                        <SelectItem value="reviewed">Reviewed</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}>
                      {sortOrder === 'asc' ? <SortAsc size={14} /> : <SortDesc size={14} />}
                    </Button>
                    <Button variant={showOnlyIssues ? "secondary" : "ghost"} size="sm" className="h-8" onClick={() => setShowOnlyIssues(!showOnlyIssues)}>
                      <AlertTriangle size={14} className="mr-1" /> Issues
                    </Button>
                    <div className="flex-1" />
                    {selectedIds.size > 0 && (
                      <Button size="sm" variant="secondary" onClick={() => handleTranslateBatch()}>
                        <Layers size={14} className="mr-1" /> ({selectedIds.size})
                      </Button>
                    )}
                  </div>

                  <div className={cn("flex-1 overflow-hidden border rounded-xl flex flex-col", darkMode ? "border-white/10 bg-white/5" : "border-gray-200 bg-white")}>
                    <div className={cn("grid grid-cols-[35px_40px_1fr_1fr_100px] px-3 py-2 border-b text-[10px] font-bold uppercase tracking-wider", darkMode ? "bg-white/[0.03] border-white/5 text-white/40" : "bg-gray-50 border-gray-200 text-gray-500")}>
                      <button onClick={toggleSelectAll}>{selectedIds.size === filteredEntries.length && filteredEntries.length > 0 ? <CheckSquare size={14} /> : <Square size={14} />}</button>
                      <div>#</div>
                      <div>Source</div>
                      <div>Translation</div>
                      <div className="text-right">Actions</div>
                    </div>
                    <ScrollArea className="flex-1">
                      {filteredEntries.map((entry, idx) => (
                        <div key={entry.id} className={cn(
                          "grid grid-cols-[35px_40px_1fr_1fr_100px] border-b px-3 py-2 transition-all text-sm items-start",
                          selectedIds.has(entry.id) ? "bg-purple-500/5" : darkMode ? "hover:bg-white/[0.02] border-white/[0.02]" : "hover:bg-gray-50 border-gray-100",
                          entry.reviewed && "border-l-2 border-l-green-500"
                        )}>
                          <button onClick={(e) => toggleSelect(entry.id, e)} className={selectedIds.has(entry.id) ? "text-purple-400" : darkMode ? "text-white/20" : "text-gray-300"}>
                            {selectedIds.has(entry.id) ? <CheckSquare size={14} /> : <Square size={14} />}
                          </button>
                          <div className={cn("text-xs pt-1", darkMode ? "text-white/30" : "text-gray-400")}>{idx + 1}</div>
                          <div className="pr-2 min-w-0">
                            <p className={cn("text-sm leading-relaxed truncate", darkMode ? "text-white/80" : "text-gray-700")} title={entry.original}>{entry.original}</p>
                            {entry.context && <Badge variant="outline" className="mt-1 text-[9px]">{entry.context}</Badge>}
                            {entry.tags && entry.tags.length > 0 && (
                              <div className="flex gap-1 mt-1 flex-wrap">
                                {entry.tags.map(tag => <Badge key={tag} variant="secondary" className="text-[8px]">{tag}</Badge>)}
                              </div>
                            )}
                          </div>
                          <div className="pr-2 min-w-0">
                            {entry.locked ? (
                              <div className="flex items-center gap-1 text-amber-400 text-xs">
                                <Lock size={12} /> Locked
                              </div>
                            ) : entry.translated ? (
                              <Textarea 
                                value={entry.translated}
                                onChange={(e) => {
                                  const val = e.target.value;
                                  const newEntries = project.entries.map(ent => ent.id === entry.id ? { ...ent, translated: val, updatedAt: Date.now() } : ent);
                                  setProject({ ...project, entries: newEntries });
                                  saveToTM(entry.original, val, targetLang, project.engine);
                                }}
                                className="min-h-[36px] text-sm resize-none"
                                style={{ fontSize: `${fontSize}px` }}
                                rows={1}
                              />
                            ) : (
                              <span className={cn("italic text-xs", darkMode ? "text-white/20" : "text-gray-300")}>Click Translate...</span>
                            )}
                            {entry.notes && <p className={cn("text-[10px] mt-1", darkMode ? "text-white/40" : "text-gray-500")}>📝 {entry.notes}</p>}
                            {entry.maxLength && entry.translated && entry.translated.length > entry.maxLength && (
                              <p className="text-[10px] mt-1 text-red-400">⚠️ {entry.translated.length}/{entry.maxLength} chars</p>
                            )}
                          </div>
                          <div className="text-right flex gap-1 justify-end">
                            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => handleToggleReview(entry.id)} title={entry.reviewed ? "Mark unreviewed" : "Mark reviewed"}>
                              {entry.reviewed ? <CheckCircle2 size={12} className="text-green-500" /> : <CheckCircle2 size={12} className={darkMode ? "text-white/20" : "text-gray-300"} />}
                            </Button>
                            <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => handleToggleLock(entry.id)} title={entry.locked ? "Unlock" : "Lock"}>
                              {entry.locked ? <Lock size={12} className="text-amber-400" /> : <Unlock size={12} className={darkMode ? "text-white/20" : "text-gray-300"} />}
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button size="icon" variant="ghost" className="h-6 w-6"><MoreHorizontal size={12} /></Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end">
                                <DropdownMenuItem onClick={() => openEntryDialog(entry)}><Edit3 size={12} className="mr-2" /> Edit Details</DropdownMenuItem>
                                <DropdownMenuItem onClick={() => { const newEntries = project.entries.map(e => e.id === entry.id ? { ...e, translated: entry.original } : e); setProject({ ...project, entries: newEntries }); }}><Copy size={12} className="mr-2" /> Copy Original</DropdownMenuItem>
                                <DropdownMenuSeparator />
                                <DropdownMenuItem onClick={() => { const newEntries = project.entries.map(e => e.id === entry.id ? { ...e, translated: "" } : e); setProject({ ...project, entries: newEntries }); }} className="text-red-400"><Trash2 size={12} className="mr-2" /> Clear</DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </div>
                      ))}
                    </ScrollArea>
                  </div>
                </motion.div>
              )}
            </TabsContent>

            <TabsContent value="tm" className="mt-0">
              <motion.div className="max-w-5xl mx-auto pt-8">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-3xl font-bold">Translation Memory</h2>
                    <p className={darkMode ? "text-white/40" : "text-gray-500"}>{tmStats.total} stored translations</p>
                  </div>
                </div>
                <div className={cn("border rounded-xl overflow-hidden", darkMode ? "border-white/10" : "border-gray-200")}>
                  <div className={cn("grid grid-cols-[1fr_1fr_100px] px-4 py-2 border-b text-xs font-bold uppercase", darkMode ? "bg-white/[0.02] text-white/40" : "bg-gray-50 text-gray-500")}>
                    <div>Source</div>
                    <div>Translation</div>
                    <div className="text-right">Lang</div>
                  </div>
                  <ScrollArea className="h-[50vh]">
                    {Object.values(getTM()).map((entry, i) => (
                      <div key={i} className={cn("grid grid-cols-[1fr_1fr_100px] px-4 py-3 border-b text-sm", darkMode ? "border-white/[0.02]" : "border-gray-100")}>
                        <div className={darkMode ? "text-white/60" : "text-gray-600"}>{entry.original}</div>
                        <div>{entry.translated}</div>
                        <div className="text-right"><Badge variant="outline">{entry.targetLang}</Badge></div>
                      </div>
                    ))}
                  </ScrollArea>
                </div>
              </motion.div>
            </TabsContent>

            <TabsContent value="glossary" className="mt-0">
              <motion.div className="max-w-5xl mx-auto pt-8">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-3xl font-bold">Glossary</h2>
                    <p className={darkMode ? "text-white/40" : "text-gray-500"}>{glossaryStats.total} terms</p>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={() => setEditingGlossaryEntry({ term: '', translation: '', category: 'term' })}><Plus size={16} className="mr-2" /> Add Term</Button>
                    <Button variant="outline" onClick={() => { const n = applyGlossaryTemplate('fantasy_rpg'); toast.success(`Added ${n} terms`); }}><BookOpen size={16} className="mr-2" /> RPG Template</Button>
                  </div>
                </div>
                <div className="flex gap-2 mb-4">
                  <Input placeholder="Search glossary..." value={glossarySearch} onChange={(e) => setGlossarySearch(e.target.value)} className="flex-1" />
                  <Select value={glossaryCategory} onValueChange={setGlossaryCategory}>
                    <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All</SelectItem>
                      {GLOSSARY_CATEGORIES.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className={cn("border rounded-xl overflow-hidden", darkMode ? "border-white/10" : "border-gray-200")}>
                  <div className={cn("grid grid-cols-[1fr_1fr_120px_80px] px-4 py-2 border-b text-xs font-bold uppercase", darkMode ? "bg-white/[0.02] text-white/40" : "bg-gray-50 text-gray-500")}>
                    <div>Term</div>
                    <div>Translation</div>
                    <div>Category</div>
                    <div className="text-right">Actions</div>
                  </div>
                  <ScrollArea className="h-[50vh]">
                    {filteredGlossary.map((entry) => (
                      <div key={entry.id} className={cn("grid grid-cols-[1fr_1fr_120px_80px] px-4 py-3 border-b text-sm items-center", darkMode ? "border-white/[0.02]" : "border-gray-100")}>
                        <div className="font-medium">{entry.term}</div>
                        <div>{entry.translation}</div>
                        <div>
                          <Badge style={{ backgroundColor: GLOSSARY_CATEGORIES.find(c => c.id === entry.category)?.color }} className="text-white text-[10px]">
                            {GLOSSARY_CATEGORIES.find(c => c.id === entry.category)?.name}
                          </Badge>
                        </div>
                        <div className="text-right flex gap-1 justify-end">
                          <Button size="icon" variant="ghost" className="h-6 w-6" onClick={() => setEditingGlossaryEntry(entry)}><Edit3 size={12} /></Button>
                          <Button size="icon" variant="ghost" className="h-6 w-6 text-red-400" onClick={() => handleGlossaryDelete(entry.id)}><Trash2 size={12} /></Button>
                        </div>
                      </div>
                    ))}
                  </ScrollArea>
                </div>
              </motion.div>
            </TabsContent>
          </AnimatePresence>
        </Tabs>
      </main>

      <Dialog open={showFindReplace} onOpenChange={setShowFindReplace}>
        <DialogContent>
          <DialogHeader><DialogTitle>Find & Replace</DialogTitle></DialogHeader>
          <div className="space-y-4 mt-4">
            <Input value={findText} onChange={(e) => setFindText(e.target.value)} placeholder="Find..." />
            <Input value={replaceText} onChange={(e) => setReplaceText(e.target.value)} placeholder="Replace with..." />
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowFindReplace(false)}>Cancel</Button>
              <Button onClick={handleFindReplace} disabled={!findText}><ArrowLeftRight size={14} className="mr-2" /> Replace All</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={showQADialog} onOpenChange={setShowQADialog}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Shield size={20} /> QA Report</DialogTitle></DialogHeader>
          <ScrollArea className="h-[50vh] mt-4">
            {qaIssues.length === 0 ? (
              <div className="text-center py-8">
                <CheckCircle2 size={48} className="mx-auto text-green-500 mb-4" />
                <p>All translations look good!</p>
              </div>
            ) : (
              <div className="space-y-2">
                {qaIssues.map((issue) => (
                  <div key={issue.id} className={cn(
                    "p-3 rounded-lg border text-sm",
                    issue.severity === 'error' ? "bg-red-500/10 border-red-500/30 text-red-400" :
                    issue.severity === 'warning' ? "bg-yellow-500/10 border-yellow-500/30 text-yellow-400" :
                    "bg-blue-500/10 border-blue-500/30 text-blue-400"
                  )}>
                    <div className="flex items-start gap-2">
                      <AlertTriangle size={16} className="mt-0.5 flex-shrink-0" />
                      <div>
                        <p className="font-medium">{issue.message}</p>
                        <p className="text-xs opacity-70 mt-1">{issue.original}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>

      <Dialog open={showStatsDialog} onOpenChange={setShowStatsDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle className="flex items-center gap-2"><BarChart3 size={20} /> Project Statistics</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-4 mt-4">
            <div className="p-4 rounded-lg bg-purple-500/10 border border-purple-500/20 text-center">
              <div className="text-3xl font-bold text-purple-400">{stats.total}</div>
              <div className="text-xs text-muted-foreground">Total Strings</div>
            </div>
            <div className="p-4 rounded-lg bg-green-500/10 border border-green-500/20 text-center">
              <div className="text-3xl font-bold text-green-400">{stats.translated}</div>
              <div className="text-xs text-muted-foreground">Translated</div>
            </div>
            <div className="p-4 rounded-lg bg-blue-500/10 border border-blue-500/20 text-center">
              <div className="text-3xl font-bold text-blue-400">{stats.reviewed}</div>
              <div className="text-xs text-muted-foreground">Reviewed</div>
            </div>
            <div className="p-4 rounded-lg bg-amber-500/10 border border-amber-500/20 text-center">
              <div className="text-3xl font-bold text-amber-400">{stats.locked}</div>
              <div className="text-xs text-muted-foreground">Locked</div>
            </div>
          </div>
          {Object.keys(stats.byTag).length > 0 && (
            <div className="mt-4">
              <h4 className="text-sm font-semibold mb-2">Tags</h4>
              <div className="flex flex-wrap gap-2">
                {Object.entries(stats.byTag).map(([tag, count]) => <Badge key={tag} variant="secondary">{tag}: {count}</Badge>)}
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={showHistoryDialog} onOpenChange={setShowHistoryDialog}>
        <DialogContent className="max-w-2xl max-h-[80vh]">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><History size={20} /> Translation History</DialogTitle></DialogHeader>
          <ScrollArea className="h-[50vh] mt-4">
            {history.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">No history yet</div>
            ) : (
              <div className="space-y-2">
                {history.slice().reverse().map((entry) => (
                  <div key={entry.id} className={cn("p-3 rounded-lg border text-sm", darkMode ? "border-white/10 bg-white/5" : "border-gray-200 bg-gray-50")}>
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{entry.description}</span>
                      <span className="text-xs text-muted-foreground">{formatHistoryTime(entry.timestamp)}</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">{entry.changes.length} changes</div>
                  </div>
                ))}
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>

      <Dialog open={showEntryDialog} onOpenChange={setShowEntryDialog}>
        <DialogContent>
          <DialogHeader><DialogTitle>Edit Entry Details</DialogTitle></DialogHeader>
          {editingEntry && (
            <div className="space-y-4 mt-4">
              <div>
                <label className="text-sm font-medium">Notes</label>
                <Textarea value={entryNotes} onChange={(e) => setEntryNotes(e.target.value)} placeholder="Add translator notes..." className="mt-1" />
              </div>
              <div>
                <label className="text-sm font-medium">Tags (comma separated)</label>
                <Input value={entryTags} onChange={(e) => setEntryTags(e.target.value)} placeholder="e.g. important, ui, dialogue" className="mt-1" />
              </div>
              <div>
                <label className="text-sm font-medium">Max Length (characters)</label>
                <Input type="number" value={entryMaxLength || ''} onChange={(e) => setEntryMaxLength(e.target.value ? parseInt(e.target.value) : undefined)} placeholder="Leave empty for no limit" className="mt-1" />
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setShowEntryDialog(false)}>Cancel</Button>
                <Button onClick={handleSaveEntryDetails}>Save</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={!!editingGlossaryEntry} onOpenChange={() => setEditingGlossaryEntry(null)}>
        <DialogContent>
          <DialogHeader><DialogTitle>{editingGlossaryEntry?.id ? 'Edit Term' : 'Add Term'}</DialogTitle></DialogHeader>
          {editingGlossaryEntry && (
            <div className="space-y-4 mt-4">
              <div>
                <label className="text-sm font-medium">Term</label>
                <Input value={editingGlossaryEntry.term} onChange={(e) => setEditingGlossaryEntry({...editingGlossaryEntry, term: e.target.value})} />
              </div>
              <div>
                <label className="text-sm font-medium">Translation</label>
                <Input value={editingGlossaryEntry.translation} onChange={(e) => setEditingGlossaryEntry({...editingGlossaryEntry, translation: e.target.value})} />
              </div>
              <div>
                <label className="text-sm font-medium">Category</label>
                <Select value={editingGlossaryEntry.category} onValueChange={(v) => setEditingGlossaryEntry({...editingGlossaryEntry, category: v})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {GLOSSARY_CATEGORIES.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setEditingGlossaryEntry(null)}>Cancel</Button>
                <Button onClick={() => handleGlossarySave(editingGlossaryEntry)}>Save</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={showShortcuts} onOpenChange={setShowShortcuts}>
        <DialogContent>
          <DialogHeader><DialogTitle className="flex items-center gap-2"><Keyboard size={20} /> Shortcuts</DialogTitle></DialogHeader>
          <div className="grid gap-2 mt-4">
            {[{ key: "Ctrl+O", desc: "Open files" }, { key: "Ctrl+S", desc: "Export" }, { key: "Ctrl+A", desc: "Select all" }, { key: "Ctrl+F", desc: "Find & Replace" }, { key: "Ctrl+Z", desc: "Undo" }, { key: "Esc", desc: "Clear selection" }].map((s, i) => (
              <div key={i} className="flex justify-between p-2 rounded bg-white/5">
                <span className={darkMode ? "text-white/60" : "text-gray-600"}>{s.desc}</span>
                <kbd className={cn("px-2 py-1 rounded text-xs", darkMode ? "bg-white/10" : "bg-gray-200")}>{s.key}</kbd>
              </div>
            ))}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
