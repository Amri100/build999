import { useState } from 'react';
import { Heart, Coffee, Wallet, Copy, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { toast } from 'sonner';

export function DonateSection() {
  const [copied, setCopied] = useState<string | null>(null);

  const donationMethods = [
    {
      id: 'qris',
      name: 'QRIS',
      icon: <Wallet className="w-5 h-5" />,
      description: 'Scan dengan aplikasi e-wallet favorit Anda',
      color: 'from-purple-500 to-pink-500',
      details: [
        { label: 'Merchant', value: 'GameTranslationHub' },
        { label: 'ID', value: 'GTH-2024-ID' },
      ],
    },
    {
      id: 'saweria',
      name: 'Saweria',
      icon: <Coffee className="w-5 h-5" />,
      description: 'Dukung via Saweria',
      color: 'from-yellow-500 to-orange-500',
      link: 'https://saweria.co/gametranslation',
    },
    {
      id: 'paypal',
      name: 'PayPal',
      icon: <Wallet className="w-5 h-5" />,
      description: 'Dukungan internasional',
      color: 'from-blue-500 to-cyan-500',
      link: 'https://paypal.me/gametranslation',
    },
  ];

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopied(label);
    toast.success(`${label} disalin!`);
    setTimeout(() => setCopied(null), 2000);
  };

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button 
          variant="ghost" 
          size="sm"
          className="gap-2 text-pink-400 hover:text-pink-500 hover:bg-pink-500/10"
        >
          <Heart size={16} className="fill-current" />
          Donasi
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-2xl">
            <Heart className="text-pink-500 fill-pink-500" />
            Dukung Developer
          </DialogTitle>
          <DialogDescription className="text-base">
            Game Translation Hub adalah proyek gratis yang dikembangkan dengan penuh dedikasi. 
            Dukungan Anda membantu kami terus meningkatkan aplikasi ini.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 mt-4">
          {/* Stats */}
          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 rounded-lg bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20">
              <div className="text-2xl font-bold text-purple-400">50K+</div>
              <div className="text-xs text-muted-foreground">Pengguna</div>
            </div>
            <div className="p-3 rounded-lg bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20">
              <div className="text-2xl font-bold text-pink-400">100+</div>
              <div className="text-xs text-muted-foreground">Game Diterjemahkan</div>
            </div>
            <div className="p-3 rounded-lg bg-gradient-to-br from-purple-500/10 to-pink-500/10 border border-purple-500/20">
              <div className="text-2xl font-bold text-cyan-400">Free</div>
              <div className="text-xs text-muted-foreground">Selamanya</div>
            </div>
          </div>

          {/* Donation Methods */}
          <div className="space-y-3">
            <h4 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">
              Metode Donasi
            </h4>
            
            {donationMethods.map((method) => (
              <div
                key={method.id}
                className="p-4 rounded-xl border border-border/50 bg-card/50 hover:bg-card transition-colors"
              >
                <div className="flex items-start gap-4">
                  <div className={`w-10 h-10 rounded-lg bg-gradient-to-br ${method.color} flex items-center justify-center text-white`}>
                    {method.icon}
                  </div>
                  <div className="flex-1">
                    <h5 className="font-semibold">{method.name}</h5>
                    <p className="text-sm text-muted-foreground">{method.description}</p>
                    
                    {method.details && (
                      <div className="mt-3 space-y-2">
                        {method.details.map((detail) => (
                          <div key={detail.label} className="flex items-center justify-between text-sm">
                            <span className="text-muted-foreground">{detail.label}:</span>
                            <div className="flex items-center gap-2">
                              <code className="px-2 py-0.5 rounded bg-muted text-xs">{detail.value}</code>
                              <button
                                onClick={() => handleCopy(detail.value, detail.label)}
                                className="text-muted-foreground hover:text-primary transition-colors"
                              >
                                {copied === detail.label ? (
                                  <Check size={14} className="text-green-500" />
                                ) : (
                                  <Copy size={14} />
                                )}
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                    
                    {method.link && (
                      <a
                        href={method.link}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center gap-2 mt-3 text-sm text-primary hover:underline"
                      >
                        Buka {method.name}
                        <Coffee size={14} />
                      </a>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Thank You Message */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-pink-500/10 via-purple-500/10 to-cyan-500/10 border border-pink-500/20 text-center">
            <p className="text-sm">
              <span className="text-pink-400">Terima kasih</span> atas dukungan Anda! 
              Setiap donasi, sekecil apapun, sangat berarti untuk pengembangan aplikasi ini.
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
