import type { GameScriptEntry, TranslationProject } from '@/types';

export function parseRPGMaker(filename: string, content: string): GameScriptEntry[] {
  const entries: GameScriptEntry[] = [];
  try {
    const data = JSON.parse(content);
    
    // RPG Maker MV/MZ Map files
    if (data.events) {
      data.events.forEach((event: any, eventIdx: number) => {
        if (!event) return;
        event.pages?.forEach((page: any, pageIdx: number) => {
          page.list?.forEach((cmd: any, cmdIdx: number) => {
            // Code 401 is "Show Text"
            if (cmd.code === 401 && cmd.parameters?.[0]) {
              entries.push({
                id: `map-${filename}-${eventIdx}-${pageIdx}-${cmdIdx}`,
                original: cmd.parameters[0],
                translated: "",
                path: `events[${eventIdx}].pages[${pageIdx}].list[${cmdIdx}].parameters[0]`,
                context: `Event: ${event.name || "Unnamed"}`
              });
            }
            // Code 102 is "Show Choices"
            if (cmd.code === 102 && cmd.parameters?.[0]) {
              cmd.parameters[0].forEach((choice: string, choiceIdx: number) => {
                entries.push({
                  id: `choice-${filename}-${eventIdx}-${pageIdx}-${cmdIdx}-${choiceIdx}`,
                  original: choice,
                  translated: "",
                  path: `events[${eventIdx}].pages[${pageIdx}].list[${cmdIdx}].parameters[0][${choiceIdx}]`,
                  context: `Choice in Event: ${event.name || "Unnamed"}`
                });
              });
            }
            // Code 356 is "Plugin Command"
            if (cmd.code === 356 && cmd.parameters?.[0]) {
              const param = cmd.parameters[0];
              // Extract text from plugin commands that contain dialogue
              if (typeof param === 'string' && (param.includes('message') || param.includes('text'))) {
                entries.push({
                  id: `plugin-${filename}-${eventIdx}-${pageIdx}-${cmdIdx}`,
                  original: param,
                  translated: "",
                  path: `events[${eventIdx}].pages[${pageIdx}].list[${cmdIdx}].parameters[0]`,
                  context: `Plugin Command in Event: ${event.name || "Unnamed"}`
                });
              }
            }
          });
        });
      });
    }
    
    // CommonEvents.json
    if (Array.isArray(data) && data[0] === null && data.length > 1 && data[1]?.list) {
       data.forEach((event: any, eventIdx: number) => {
         if (!event) return;
         event.list?.forEach((cmd: any, cmdIdx: number) => {
            if (cmd.code === 401 && cmd.parameters?.[0]) {
              entries.push({
                id: `common-${filename}-${eventIdx}-${cmdIdx}`,
                original: cmd.parameters[0],
                translated: "",
                path: `[${eventIdx}].list[${cmdIdx}].parameters[0]`,
                context: `Common Event: ${event.name || "Unnamed"}`
              });
            }
         });
       });
    }

    // Actors.json
    if (Array.isArray(data) && data.length > 0 && data[0] === null && data[1]?.nickname !== undefined) {
      data.forEach((actor: any, idx: number) => {
        if (!actor) return;
        if (actor.name) {
          entries.push({
            id: `actor-${filename}-${idx}-name`,
            original: actor.name,
            translated: "",
            path: `[${idx}].name`,
            context: `Actor Name`
          });
        }
        if (actor.nickname) {
          entries.push({
            id: `actor-${filename}-${idx}-nickname`,
            original: actor.nickname,
            translated: "",
            path: `[${idx}].nickname`,
            context: `Actor Nickname`
          });
        }
        if (actor.profile) {
          entries.push({
            id: `actor-${filename}-${idx}-profile`,
            original: actor.profile,
            translated: "",
            path: `[${idx}].profile`,
            context: `Actor Profile`
          });
        }
      });
    }

    // Items.json, Weapons.json, Armors.json, Skills.json, States.json
    if (Array.isArray(data) && data.length > 0 && data[0] === null && data[1]?.description !== undefined) {
      data.forEach((item: any, idx: number) => {
        if (!item) return;
        if (item.name) {
          entries.push({
            id: `item-${filename}-${idx}-name`,
            original: item.name,
            translated: "",
            path: `[${idx}].name`,
            context: `Item Name`
          });
        }
        if (item.description) {
          entries.push({
            id: `item-${filename}-${idx}-desc`,
            original: item.description,
            translated: "",
            path: `[${idx}].description`,
            context: `Item Description`
          });
        }
        if (item.note) {
          entries.push({
            id: `item-${filename}-${idx}-note`,
            original: item.note,
            translated: "",
            path: `[${idx}].note`,
            context: `Item Note`
          });
        }
      });
    }

    // System.json - terms and messages
    if (data.terms) {
      // Basic terms
      if (data.terms.basic) {
        data.terms.basic.forEach((term: string, idx: number) => {
          if (term) {
            entries.push({
              id: `system-${filename}-terms-basic-${idx}`,
              original: term,
              translated: "",
              path: `terms.basic[${idx}]`,
              context: `System Term`
            });
          }
        });
      }
      // Commands
      if (data.terms.commands) {
        data.terms.commands.forEach((cmd: string, idx: number) => {
          if (cmd) {
            entries.push({
              id: `system-${filename}-terms-commands-${idx}`,
              original: cmd,
              translated: "",
              path: `terms.commands[${idx}]`,
              context: `System Command`
            });
          }
        });
      }
      // Messages
      if (data.terms.messages) {
        Object.entries(data.terms.messages).forEach(([key, value]: [string, any]) => {
          if (value && typeof value === 'string') {
            entries.push({
              id: `system-${filename}-terms-messages-${key}`,
              original: value,
              translated: "",
              path: `terms.messages.${key}`,
              context: `System Message`
            });
          }
        });
      }
    }

    // Troops.json - battle events
    if (Array.isArray(data) && data.length > 0 && data[0] === null && data[1]?.members !== undefined) {
      data.forEach((troop: any, troopIdx: number) => {
        if (!troop) return;
        if (troop.name) {
          entries.push({
            id: `troop-${filename}-${troopIdx}-name`,
            original: troop.name,
            translated: "",
            path: `[${troopIdx}].name`,
            context: `Troop Name`
          });
        }
        troop.pages?.forEach((page: any, pageIdx: number) => {
          page.list?.forEach((cmd: any, cmdIdx: number) => {
            if (cmd.code === 401 && cmd.parameters?.[0]) {
              entries.push({
                id: `troop-${filename}-${troopIdx}-${pageIdx}-${cmdIdx}`,
                original: cmd.parameters[0],
                translated: "",
                path: `[${troopIdx}].pages[${pageIdx}].list[${cmdIdx}].parameters[0]`,
                context: `Troop Event`
              });
            }
          });
        });
      });
    }

  } catch (e) {
    console.error("Error parsing RPG Maker file:", e);
  }
  return entries;
}

export function parseKiriKiri(filename: string, content: string): GameScriptEntry[] {
  const entries: GameScriptEntry[] = [];
  const lines = content.split('\n');
  
  lines.forEach((line, idx) => {
    // Match [text] or *text tags (dialogue)
    const textMatch = line.match(/^\[text\]\s*(.+)$/i) || line.match(/^\*(.+)$/);
    if (textMatch) {
      entries.push({
        id: `ks-${filename}-${idx}`,
        original: textMatch[1].trim(),
        translated: "",
        path: `line-${idx}`,
        context: `Dialogue`
      });
      return;
    }
    
    // Match [name] or [nm] tags (character names)
    const nameMatch = line.match(/^\[(?:name|nm)\s+name="([^"]+)"\]/i);
    if (nameMatch) {
      entries.push({
        id: `ks-name-${filename}-${idx}`,
        original: nameMatch[1].trim(),
        translated: "",
        path: `line-${idx}`,
        context: `Character Name`
      });
      return;
    }

    // Match [ruby] tags (furigana)
    const rubyMatch = line.match(/\[ruby\s+text="([^"]+)"\]([^\[]+)\[\/ruby\]/gi);
    if (rubyMatch) {
      rubyMatch.forEach((match, ridx) => {
        const baseMatch = match.match(/\[ruby\s+text="([^"]+)"\]([^\[]+)\[\/ruby\]/i);
        if (baseMatch) {
          entries.push({
            id: `ks-ruby-${filename}-${idx}-${ridx}`,
            original: baseMatch[2].trim(),
            translated: "",
            path: `line-${idx}-ruby-${ridx}`,
            context: `Ruby Text`
          });
        }
      });
    }

    // Match [select] tags (choices)
    const selectMatch = line.match(/^\[select\s+text="([^"]+)"\]/i);
    if (selectMatch) {
      entries.push({
        id: `ks-select-${filename}-${idx}`,
        original: selectMatch[1].trim(),
        translated: "",
        path: `line-${idx}`,
        context: `Choice`
      });
    }

    // Match [caption] tags
    const captionMatch = line.match(/^\[caption\s+text="([^"]+)"\]/i);
    if (captionMatch) {
      entries.push({
        id: `ks-caption-${filename}-${idx}`,
        original: captionMatch[1].trim(),
        translated: "",
        path: `line-${idx}`,
        context: `Caption`
      });
    }
  });
  
  return entries;
}

export function parseRenPy(filename: string, content: string): GameScriptEntry[] {
  const entries: GameScriptEntry[] = [];
  const lines = content.split('\n');
  
  lines.forEach((line, idx) => {
    // Match dialogue lines: character "text" or character 'text'
    const dialogueMatch = line.match(/^(\w+)\s+["'](.+?)["']\s*$/);
    if (dialogueMatch) {
      entries.push({
        id: `rpy-dialogue-${filename}-${idx}`,
        original: dialogueMatch[2],
        translated: "",
        path: `line-${idx}`,
        context: `Dialogue by ${dialogueMatch[1]}`
      });
      return;
    }
    
    // Match menu choices
    const menuMatch = line.match(/^\s*["'](.+?)["']\s*:$/);
    if (menuMatch && (line.trim().startsWith('"') || line.trim().startsWith("'"))) {
      entries.push({
        id: `rpy-menu-${filename}-${idx}`,
        original: menuMatch[1],
        translated: "",
        path: `line-${idx}`,
        context: `Menu Choice`
      });
      return;
    }

    // Match string definitions: define x = "text"
    const defineMatch = line.match(/^define\s+\w+\s*=\s*["'](.+?)["']/);
    if (defineMatch) {
      entries.push({
        id: `rpy-define-${filename}-${idx}`,
        original: defineMatch[1],
        translated: "",
        path: `line-${idx}`,
        context: `String Definition`
      });
      return;
    }

    // Match translate blocks
    const translateMatch = line.match(/^translate\s+\w+\s+\w+:\s*$/);
    if (translateMatch) {
      // The actual translated content will be in subsequent lines
      // This is handled by the dialogue matcher above
    }
  });
  
  return entries;
}

export function parseGenericJSON(filename: string, content: string): GameScriptEntry[] {
  const entries: GameScriptEntry[] = [];
  
  function traverse(obj: any, path: string = ""): void {
    if (typeof obj === "string" && obj.trim().length > 0 && obj.length > 1) {
      // Filter out pure numbers, IDs, and file paths
      if (/^\d+$/.test(obj)) return;
      if (/^[a-zA-Z0-9_-]+\.(png|jpg|jpeg|ogg|mp3|wav|json)$/i.test(obj)) return;
      if (obj.startsWith("_") || obj.startsWith("$")) return;
      
      entries.push({
        id: `json-${filename}-${entries.length}`,
        original: obj,
        translated: "",
        path: path,
        context: `JSON Value`
      });
    } else if (Array.isArray(obj)) {
      obj.forEach((item, idx) => traverse(item, `${path}[${idx}]`));
    } else if (typeof obj === "object" && obj !== null) {
      Object.entries(obj).forEach(([key, value]) => {
        // Skip common non-translatable keys
        const skipKeys = ['id', 'key', 'filename', 'path', 'url', 'icon', 'image', 'sprite', 'audio', 'bgm', 'se', 'me'];
        if (!skipKeys.includes(key.toLowerCase())) {
          traverse(value, `${path}.${key}`);
        }
      });
    }
  }
  
  try {
    const data = JSON.parse(content);
    traverse(data, "root");
  } catch (e) {
    console.error("Error parsing JSON:", e);
  }
  
  return entries;
}

export function parseCSV(filename: string, content: string): GameScriptEntry[] {
  const entries: GameScriptEntry[] = [];
  const lines = content.split('\n');
  
  lines.forEach((line, rowIdx) => {
    if (!line.trim()) return;
    
    const cells = line.split(',').map(cell => cell.trim().replace(/^["']|["']$/g, ''));
    cells.forEach((cell, colIdx) => {
      if (cell && cell.length > 1) {
        entries.push({
          id: `csv-${filename}-${rowIdx}-${colIdx}`,
          original: cell,
          translated: "",
          path: `row-${rowIdx}-col-${colIdx}`,
          context: `CSV Cell`
        });
      }
    });
  });
  
  return entries;
}

export function parseSRT(filename: string, content: string): GameScriptEntry[] {
  const entries: GameScriptEntry[] = [];
  const blocks = content.split('\n\n');
  
  blocks.forEach((block, blockIdx) => {
    const lines = block.split('\n');
    if (lines.length >= 3) {
      // First line is index, second is timestamp, rest is text
      const textLines = lines.slice(2);
      const text = textLines.join('\n').trim();
      
      if (text) {
        entries.push({
          id: `srt-${filename}-${blockIdx}`,
          original: text,
          translated: "",
          path: `subtitle-${blockIdx}`,
          context: `Subtitle ${lines[0]}`
        });
      }
    }
  });
  
  return entries;
}

export function applyTranslations(
  originalContent: string, 
  entries: GameScriptEntry[], 
  engine: TranslationProject["engine"]
): string {
  let result = originalContent;
  
  // Sort entries by path length (longest first) to avoid partial replacements
  const sortedEntries = [...entries]
    .filter(e => e.translated)
    .sort((a, b) => b.path.length - a.path.length);
  
  if (engine === "rpgmaker") {
    try {
      const data = JSON.parse(originalContent);
      
      sortedEntries.forEach(entry => {
        try {
          // Parse path like "events[0].pages[0].list[0].parameters[0]"
          const pathParts = entry.path.match(/(\w+|\[\d+\])/g) || [];
          let current: any = data;
          
          for (let i = 0; i < pathParts.length - 1; i++) {
            const part = pathParts[i];
            if (part.startsWith('[')) {
              current = current[parseInt(part.slice(1, -1))];
            } else {
              current = current[part];
            }
            if (!current) break;
          }
          
          const lastPart = pathParts[pathParts.length - 1];
          if (lastPart?.startsWith('[')) {
            const idx = parseInt(lastPart.slice(1, -1));
            if (Array.isArray(current) && current[idx] !== undefined) {
              current[idx] = entry.translated;
            }
          } else if (lastPart && current) {
            current[lastPart] = entry.translated;
          }
        } catch (e) {
          console.error("Error applying translation:", e);
        }
      });
      
      return JSON.stringify(data, null, 2);
    } catch (e) {
      console.error("Error parsing RPG Maker JSON:", e);
      return originalContent;
    }
  }
  
  if (engine === "kirikiri" || engine === "renpy") {
    // For script files, replace line by line
    let lines = result.split('\n');
    
    sortedEntries.forEach(entry => {
      const lineIdx = parseInt(entry.path.replace('line-', ''));
      if (!isNaN(lineIdx) && lines[lineIdx]) {
        const originalLine = lines[lineIdx];
        // Replace only the text content, preserving tags
        if (engine === "kirikiri") {
          lines[lineIdx] = originalLine.replace(entry.original, entry.translated);
        } else {
          lines[lineIdx] = originalLine.replace(entry.original, entry.translated);
        }
      }
    });
    
    return lines.join('\n');
  }
  
  if (engine === "subtitles") {
    // For SRT, replace text blocks
    let blocks = result.split('\n\n');
    
    sortedEntries.forEach(entry => {
      const blockIdx = parseInt(entry.path.replace('subtitle-', ''));
      if (!isNaN(blockIdx) && blocks[blockIdx]) {
        const lines = blocks[blockIdx].split('\n');
        if (lines.length >= 3) {
          const textLines = lines.slice(2);
          const originalText = textLines.join('\n').trim();
          blocks[blockIdx] = blocks[blockIdx].replace(originalText, entry.translated);
        }
      }
    });
    
    return blocks.join('\n\n');
  }
  
  // Default: simple string replacement
  sortedEntries.forEach(entry => {
    result = result.split(entry.original).join(entry.translated);
  });
  
  return result;
}

export { type GameScriptEntry, type TranslationProject };
