// Offline Dictionary for English-Japanese-Indonesian
// This provides basic translation without requiring API calls

export interface DictionaryEntry {
  source: string;
  target: string;
  sourceLang: string;
  targetLang: string;
  category?: 'common' | 'game' | 'greeting' | 'item' | 'action';
}

// Common English-Indonesian translations
const enIdDictionary: Record<string, string> = {
  // Common words
  'hello': 'halo',
  'hi': 'hai',
  'yes': 'ya',
  'no': 'tidak',
  'ok': 'oke',
  'okay': 'oke',
  'thanks': 'terima kasih',
  'thank you': 'terima kasih',
  'please': 'tolong',
  'sorry': 'maaf',
  'goodbye': 'selamat tinggal',
  'bye': 'dadah',
  'welcome': 'selamat datang',
  
  // Game terms
  'start': 'mulai',
  'new game': 'permainan baru',
  'continue': 'lanjutkan',
  'load': 'muat',
  'save': 'simpan',
  'options': 'pengaturan',
  'settings': 'pengaturan',
  'quit': 'keluar',
  'exit': 'keluar',
  'menu': 'menu',
  'back': 'kembali',
  'cancel': 'batal',
  'confirm': 'konfirmasi',
  'attack': 'serang',
  'defend': 'bertahan',
  'magic': 'sihir',
  'item': 'barang',
  'skill': 'skill',
  'equip': 'equip',
  'status': 'status',
  'map': 'peta',
  'inventory': 'inventori',
  'shop': 'toko',
  'buy': 'beli',
  'sell': 'jual',
  'gold': 'emas',
  'money': 'uang',
  'exp': 'pengalaman',
  'level': 'level',
  'hp': 'nyawa',
  'mp': 'mana',
  'sp': 'energi',
  'strength': 'kekuatan',
  'defense': 'pertahanan',
  'speed': 'kecepatan',
  'intelligence': 'kecerdasan',
  
  // Common RPG terms
  'quest': 'misi',
  'mission': 'misi',
  'dialogue': 'dialog',
  'conversation': 'percakapan',
  'story': 'cerita',
  'chapter': 'bab',
  'stage': 'tahap',
  'world': 'dunia',
  'dungeon': 'dungeon',
  'boss': 'bos',
  'enemy': 'musuh',
  'monster': 'monster',
  'victory': 'kemenangan',
  'defeat': 'kekalahan',
  'game over': 'permainan berakhir',
  
  // Items
  'potion': 'ramuan',
  'sword': 'pedang',
  'shield': 'tameng',
  'armor': 'baju besi',
  'helmet': 'helm',
  'ring': 'cincin',
  'necklace': 'kalung',
  'key': 'kunci',
  'book': 'buku',
  'scroll': 'gulungan',
  
  // Directions
  'north': 'utara',
  'south': 'selatan',
  'east': 'timur',
  'west': 'barat',
  'up': 'atas',
  'down': 'bawah',
  'left': 'kiri',
  'right': 'kanan',
  
  // Time
  'day': 'hari',
  'night': 'malam',
  'morning': 'pagi',
  'afternoon': 'siang',
  'evening': 'sore',
  'today': 'hari ini',
  'tomorrow': 'besok',
  'yesterday': 'kemarin',
  
  // Characters
  'hero': 'pahlawan',
  'heroine': 'pahlawan wanita',
  'princess': 'putri',
  'prince': 'pangeran',
  'king': 'raja',
  'queen': 'ratu',
  'knight': 'kesatria',
  'wizard': 'penyihir',
  'witch': 'penyihir wanita',
  'merchant': 'pedagang',
  'villager': 'penduduk desa',
};

// Common English-Japanese translations
const enJpDictionary: Record<string, string> = {
  'hello': 'こんにちは',
  'hi': 'やあ',
  'yes': 'はい',
  'no': 'いいえ',
  'ok': 'オーケー',
  'okay': 'オーケー',
  'thanks': 'ありがとう',
  'thank you': 'ありがとうございます',
  'please': 'お願いします',
  'sorry': 'ごめんなさい',
  'goodbye': 'さようなら',
  'bye': 'バイバイ',
  'welcome': 'ようこそ',
  
  'start': 'スタート',
  'new game': 'ニューゲーム',
  'continue': 'コンティニュー',
  'load': 'ロード',
  'save': 'セーブ',
  'options': 'オプション',
  'settings': '設定',
  'quit': '終了',
  'exit': '出口',
  'menu': 'メニュー',
  'back': '戻る',
  'cancel': 'キャンセル',
  'confirm': '確認',
  'attack': '攻撃',
  'defend': '防御',
  'magic': '魔法',
  'item': 'アイテム',
  'skill': 'スキル',
  'equip': '装備',
  'status': 'ステータス',
  'map': 'マップ',
  'inventory': '持ち物',
  'shop': 'ショップ',
  'buy': '買う',
  'sell': '売る',
  'gold': 'ゴールド',
  'money': 'お金',
  'exp': '経験値',
  'level': 'レベル',
  'hp': 'HP',
  'mp': 'MP',
  'sp': 'SP',
  'strength': '力',
  'defense': '守備',
  'speed': '素早さ',
  'intelligence': '知力',
  
  'quest': 'クエスト',
  'mission': 'ミッション',
  'dialogue': '会話',
  'story': 'ストーリー',
  'chapter': '章',
  'stage': 'ステージ',
  'world': '世界',
  'dungeon': 'ダンジョン',
  'boss': 'ボス',
  'enemy': '敵',
  'monster': 'モンスター',
  'victory': '勝利',
  'defeat': '敗北',
  'game over': 'ゲームオーバー',
  
  'potion': 'ポーション',
  'sword': '剣',
  'shield': '盾',
  'armor': '鎧',
  'helmet': '兜',
  'ring': '指輪',
  'necklace': 'ネックレス',
  'key': '鍵',
  'book': '本',
  'scroll': '巻物',
  
  'north': '北',
  'south': '南',
  'east': '東',
  'west': '西',
  'up': '上',
  'down': '下',
  'left': '左',
  'right': '右',
  
  'day': '日',
  'night': '夜',
  'morning': '朝',
  'afternoon': '午後',
  'evening': '夕方',
  'today': '今日',
  'tomorrow': '明日',
  'yesterday': '昨日',
  
  'hero': '勇者',
  'heroine': 'ヒロイン',
  'princess': '姫',
  'prince': '王子',
  'king': '王',
  'queen': '女王',
  'knight': '騎士',
  'wizard': '魔法使い',
  'witch': '魔女',
  'merchant': '商人',
  'villager': '村人',
};

// Japanese-Indonesian dictionary
const jpIdDictionary: Record<string, string> = {
  'こんにちは': 'halo',
  'やあ': 'hai',
  'はい': 'ya',
  'いいえ': 'tidak',
  'ありがとう': 'terima kasih',
  'ありがとうございます': 'terima kasih banyak',
  'お願いします': 'tolong',
  'ごめんなさい': 'maaf',
  'さようなら': 'selamat tinggal',
  'バイバイ': 'dadah',
  'ようこそ': 'selamat datang',
  
  'スタート': 'mulai',
  'ニューゲーム': 'permainan baru',
  'コンティニュー': 'lanjutkan',
  'ロード': 'muat',
  'セーブ': 'simpan',
  'オプション': 'pengaturan',
  '設定': 'pengaturan',
  '終了': 'keluar',
  '戻る': 'kembali',
  'キャンセル': 'batal',
  '確認': 'konfirmasi',
  '攻撃': 'serang',
  '防御': 'bertahan',
  '魔法': 'sihir',
  'アイテム': 'barang',
  'スキル': 'skill',
  '装備': 'equip',
  'ステータス': 'status',
  'マップ': 'peta',
  '持ち物': 'inventori',
  'ショップ': 'toko',
  '買う': 'beli',
  '売る': 'jual',
  'ゴールド': 'emas',
  'お金': 'uang',
  '経験値': 'pengalaman',
  'レベル': 'level',
  '力': 'kekuatan',
  '守備': 'pertahanan',
  '素早さ': 'kecepatan',
  '知力': 'kecerdasan',
  
  'クエスト': 'misi',
  'ストーリー': 'cerita',
  '章': 'bab',
  'ステージ': 'tahap',
  '世界': 'dunia',
  'ダンジョン': 'dungeon',
  'ボス': 'bos',
  '敵': 'musuh',
  'モンスター': 'monster',
  '勝利': 'kemenangan',
  '敗北': 'kekalahan',
  'ゲームオーバー': 'permainan berakhir',
  
  'ポーション': 'ramuan',
  '剣': 'pedang',
  '盾': 'tameng',
  '鎧': 'baju besi',
  '兜': 'helm',
  '指輪': 'cincin',
  'ネックレス': 'kalung',
  '鍵': 'kunci',
  '本': 'buku',
  '巻物': 'gulungan',
  
  '勇者': 'pahlawan',
  'ヒロイン': 'pahlawan wanita',
  '姫': 'putri',
  '王子': 'pangeran',
  '王': 'raja',
  '女王': 'ratu',
  '騎士': 'kesatria',
  '魔法使い': 'penyihir',
  '魔女': 'penyihir wanita',
  '商人': 'pedagang',
  '村人': 'penduduk desa',
};

// Pattern-based translations for common sentence structures
const patterns: { regex: RegExp; replacement: string }[] = [
  // English patterns
  { regex: /\byou\s+got\s+a?\b/gi, replacement: 'kamu mendapatkan' },
  { regex: /\byou\s+found\b/gi, replacement: 'kamu menemukan' },
  { regex: /\byou\s+received\b/gi, replacement: 'kamu menerima' },
  { regex: /\bdo\s+you\s+want\s+to\b/gi, replacement: 'apakah kamu ingin' },
  { regex: /\bwould\s+you\s+like\s+to\b/gi, replacement: 'apakah kamu ingin' },
  { regex: /\bpress\s+(.+?)\s+to\b/gi, replacement: 'tekan $1 untuk' },
  { regex: /\bselect\s+(.+?)\b/gi, replacement: 'pilih $1' },
  { regex: /\bchoose\s+(.+?)\b/gi, replacement: 'pilih $1' },
  { regex: /\benter\s+(.+?)\b/gi, replacement: 'masuk ke $1' },
  { regex: /\bgo\s+to\s+(.+?)\b/gi, replacement: 'pergi ke $1' },
  { regex: /\btalk\s+to\s+(.+?)\b/gi, replacement: 'bicara dengan $1' },
  { regex: /\bspeak\s+to\s+(.+?)\b/gi, replacement: 'bicara dengan $1' },
  { regex: /\bfight\s+(.+?)\b/gi, replacement: 'lawan $1' },
  { regex: /\bdefeat\s+(.+?)\b/gi, replacement: 'kalahkan $1' },
  { regex: /\bfind\s+(.+?)\b/gi, replacement: 'cari $1' },
  { regex: /\bsearch\s+for\s+(.+?)\b/gi, replacement: 'cari $1' },
  { regex: /\bgive\s+(.+?)\s+to\b/gi, replacement: 'berikan $1 kepada' },
  { regex: /\btake\s+(.+?)\b/gi, replacement: 'ambil $1' },
  { regex: /\buse\s+(.+?)\b/gi, replacement: 'gunakan $1' },
  { regex: /\bopen\s+(.+?)\b/gi, replacement: 'buka $1' },
  { regex: /\bclose\s+(.+?)\b/gi, replacement: 'tutup $1' },
  { regex: /\bread\s+(.+?)\b/gi, replacement: 'baca $1' },
  { regex: /\bexamine\s+(.+?)\b/gi, replacement: 'periksa $1' },
  { regex: /\bcheck\s+(.+?)\b/gi, replacement: 'periksa $1' },
  { regex: /\bbuy\s+(.+?)\b/gi, replacement: 'beli $1' },
  { regex: /\bsell\s+(.+?)\b/gi, replacement: 'jual $1' },
  { regex: /\bequip\s+(.+?)\b/gi, replacement: 'equip $1' },
  { regex: /\bunequip\s+(.+?)\b/gi, replacement: 'lepas equip $1' },
  { regex: /\blearn\s+(.+?)\b/gi, replacement: 'pelajari $1' },
  { regex: /\bmaster\s+(.+?)\b/gi, replacement: 'kuasai $1' },
];

export function translateOffline(
  text: string,
  sourceLang: string,
  targetLang: string
): string | null {
  if (!text || text.trim().length === 0) return text;
  
  const lowerText = text.toLowerCase().trim();
  
  // Determine which dictionary to use
  let dictionary: Record<string, string> | null = null;
  
  if (sourceLang === 'English' && targetLang === 'Indonesian') {
    dictionary = enIdDictionary;
  } else if (sourceLang === 'English' && targetLang === 'Japanese') {
    dictionary = enJpDictionary;
  } else if (sourceLang === 'Japanese' && targetLang === 'Indonesian') {
    dictionary = jpIdDictionary;
  } else if (sourceLang === 'Indonesian' && targetLang === 'English') {
    // Reverse lookup for Indonesian to English
    const reverseDict: Record<string, string> = {};
    Object.entries(enIdDictionary).forEach(([en, id]) => {
      reverseDict[id.toLowerCase()] = en;
    });
    dictionary = reverseDict;
  } else if (sourceLang === 'Japanese' && targetLang === 'English') {
    // Reverse lookup for Japanese to English
    const reverseDict: Record<string, string> = {};
    Object.entries(enJpDictionary).forEach(([en, jp]) => {
      reverseDict[jp] = en;
    });
    dictionary = reverseDict;
  } else if (sourceLang === 'Indonesian' && targetLang === 'Japanese') {
    // Indonesian to Japanese (via English)
    const reverseDict: Record<string, string> = {};
    Object.entries(jpIdDictionary).forEach(([jp, id]) => {
      reverseDict[id.toLowerCase()] = jp;
    });
    dictionary = reverseDict;
  }
  
  if (!dictionary) return null;
  
  // Check for exact match first
  if (dictionary[lowerText]) {
    return preserveCase(text, dictionary[lowerText]);
  }
  
  // Try pattern matching for sentences
  for (const pattern of patterns) {
    if (pattern.regex.test(text)) {
      return text.replace(pattern.regex, pattern.replacement);
    }
  }
  
  // Try word-by-word translation
  const words = lowerText.split(/\s+/);
  const translatedWords = words.map(word => {
    // Remove punctuation
    const cleanWord = word.replace(/[^\w\s]/g, '');
    return dictionary[cleanWord] || word;
  });
  
  // If at least 50% of words were translated, return the result
  const translatedCount = translatedWords.filter((w, i) => w !== words[i]).length;
  if (translatedCount > 0 && translatedCount / words.length >= 0.3) {
    return translatedWords.join(' ');
  }
  
  return null;
}

export function translateBatchOffline(
  texts: string[],
  sourceLang: string,
  targetLang: string
): { original: string; translated: string; success: boolean }[] {
  return texts.map(text => {
    const translated = translateOffline(text, sourceLang, targetLang);
    return {
      original: text,
      translated: translated || text,
      success: translated !== null
    };
  });
}

export function getOfflineDictionaryStats(): {
  enId: number;
  enJp: number;
  jpId: number;
  total: number;
} {
  return {
    enId: Object.keys(enIdDictionary).length,
    enJp: Object.keys(enJpDictionary).length,
    jpId: Object.keys(jpIdDictionary).length,
    total: Object.keys(enIdDictionary).length + Object.keys(enJpDictionary).length + Object.keys(jpIdDictionary).length
  };
}

export function addCustomEntry(
  source: string,
  target: string,
  sourceLang: string,
  targetLang: string
): void {
  // Store custom entries in localStorage
  const key = `custom_dict_${sourceLang}_${targetLang}`;
  const existing = JSON.parse(localStorage.getItem(key) || '{}');
  existing[source.toLowerCase()] = target;
  localStorage.setItem(key, JSON.stringify(existing));
}

export function getCustomEntries(sourceLang: string, targetLang: string): Record<string, string> {
  const key = `custom_dict_${sourceLang}_${targetLang}`;
  return JSON.parse(localStorage.getItem(key) || '{}');
}

function preserveCase(original: string, translated: string): string {
  // Simple case preservation
  if (original === original.toUpperCase()) {
    return translated.toUpperCase();
  }
  if (original[0] === original[0]?.toUpperCase()) {
    return translated.charAt(0).toUpperCase() + translated.slice(1);
  }
  return translated;
}

// Common phrase templates for games
export const phraseTemplates: Record<string, string[]> = {
  'item_get': [
    'You got {item}!',
    'You obtained {item}!',
    'Received {item}!',
    '{item} acquired!',
  ],
  'level_up': [
    'Level Up!',
    'You are now level {level}!',
    '{name} reached level {level}!',
  ],
  'quest_complete': [
    'Quest Complete!',
    'Mission Accomplished!',
    'Objective Complete!',
  ],
  'save_game': [
    'Save your progress?',
    'Would you like to save?',
    'Save game?',
  ],
  'game_over': [
    'Game Over',
    'You died',
    'Try again?',
  ],
};

export function applyPhraseTemplate(
  templateName: string,
  variables: Record<string, string>,
  sourceLang: string,
  targetLang: string
): string | null {
  const templates = phraseTemplates[templateName];
  if (!templates || templates.length === 0) return null;
  
  // Pick a random template or the first one
  const template = templates[0];
  let result = template;
  
  // Replace variables
  Object.entries(variables).forEach(([key, value]) => {
    result = result.replace(`{${key}}`, value);
  });
  
  // Translate the result
  const translated = translateOffline(result, sourceLang, targetLang);
  return translated || result;
}
