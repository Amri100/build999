// Style Guide Service
// Ensures consistent tone, voice, and formatting across translations

export interface StyleRule {
  id: string;
  category: 'tone' | 'formatting' | 'terminology' | 'grammar' | 'custom';
  title: string;
  description: string;
  example?: {
    correct: string;
    incorrect: string;
  };
  enabled: boolean;
  createdAt: number;
}

export interface StyleGuide {
  projectName: string;
  targetAudience: string;
  toneOfVoice: 'formal' | 'informal' | 'friendly' | 'serious' | 'playful';
  grammaticalPerson: 'first' | 'second' | 'third';
  rules: StyleRule[];
}

const STYLE_GUIDE_KEY = 'style_guide_v1';

// Default style guide for games
export const defaultStyleGuide: StyleGuide = {
  projectName: 'Game Project',
  targetAudience: 'General players',
  toneOfVoice: 'friendly',
  grammaticalPerson: 'second',
  rules: [
    {
      id: '1',
      category: 'tone',
      title: 'Use friendly and engaging tone',
      description: 'Game text should be welcoming and engaging to players.',
      example: {
        correct: 'Welcome! Ready for your next adventure?',
        incorrect: 'You have entered the game.',
      },
      enabled: true,
      createdAt: Date.now(),
    },
    {
      id: '2',
      category: 'formatting',
      title: 'Preserve all placeholders',
      description: 'Never translate or remove placeholders like {name}, [item], %s.',
      example: {
        correct: 'Hello {name}, you found [item]!',
        incorrect: 'Hello John, you found Sword!',
      },
      enabled: true,
      createdAt: Date.now(),
    },
    {
      id: '3',
      category: 'terminology',
      title: 'Keep game terms consistent',
      description: 'Use the glossary for all game-specific terms.',
      enabled: true,
      createdAt: Date.now(),
    },
    {
      id: '4',
      category: 'grammar',
      title: 'Use active voice',
      description: 'Prefer active voice over passive voice for clarity.',
      example: {
        correct: 'You defeated the boss!',
        incorrect: 'The boss was defeated by you!',
      },
      enabled: true,
      createdAt: Date.now(),
    },
    {
      id: '5',
      category: 'formatting',
      title: 'Maintain line breaks',
      description: 'Preserve the same number of line breaks as the original text.',
      enabled: true,
      createdAt: Date.now(),
    },
  ],
};

// Get style guide
export function getStyleGuide(): StyleGuide {
  try {
    const stored = localStorage.getItem(STYLE_GUIDE_KEY);
    if (!stored) return defaultStyleGuide;
    return JSON.parse(stored);
  } catch (e) {
    console.error('Error loading style guide:', e);
    return defaultStyleGuide;
  }
}

// Save style guide
export function saveStyleGuide(guide: StyleGuide): void {
  try {
    localStorage.setItem(STYLE_GUIDE_KEY, JSON.stringify(guide));
  } catch (e) {
    console.error('Error saving style guide:', e);
  }
}

// Add a style rule
export function addStyleRule(rule: Omit<StyleRule, 'id' | 'createdAt'>): StyleRule {
  const guide = getStyleGuide();
  const newRule: StyleRule = {
    ...rule,
    id: Math.random().toString(36).substr(2, 9),
    createdAt: Date.now(),
  };
  guide.rules.push(newRule);
  saveStyleGuide(guide);
  return newRule;
}

// Update a style rule
export function updateStyleRule(id: string, updates: Partial<StyleRule>): boolean {
  const guide = getStyleGuide();
  const index = guide.rules.findIndex(r => r.id === id);
  if (index !== -1) {
    guide.rules[index] = { ...guide.rules[index], ...updates };
    saveStyleGuide(guide);
    return true;
  }
  return false;
}

// Delete a style rule
export function deleteStyleRule(id: string): boolean {
  const guide = getStyleGuide();
  const filtered = guide.rules.filter(r => r.id !== id);
  if (filtered.length !== guide.rules.length) {
    guide.rules = filtered;
    saveStyleGuide(guide);
    return true;
  }
  return false;
}

// Check text against style guide
export function checkAgainstStyleGuide(text: string): { passed: boolean; issues: string[] } {
  const guide = getStyleGuide();
  const issues: string[] = [];
  
  // Check for passive voice indicators (simplified)
  const passiveIndicators = ['was ', 'were ', 'been ', 'being '];
  const hasPassiveVoice = passiveIndicators.some(indicator => 
    text.toLowerCase().includes(indicator)
  );
  
  if (hasPassiveVoice && guide.rules.find(r => r.title.includes('active voice'))?.enabled) {
    issues.push('Text may contain passive voice. Consider using active voice.');
  }
  
  return { passed: issues.length === 0, issues };
}

// Get enabled rules
export function getEnabledRules(): StyleRule[] {
  const guide = getStyleGuide();
  return guide.rules.filter(r => r.enabled);
}

// Export style guide
export function exportStyleGuide(): string {
  return JSON.stringify(getStyleGuide(), null, 2);
}

// Import style guide
export function importStyleGuide(jsonString: string): boolean {
  try {
    const data = JSON.parse(jsonString);
    if (data.rules && Array.isArray(data.rules)) {
      saveStyleGuide(data);
      return true;
    }
    return false;
  } catch (e) {
    console.error('Error importing style guide:', e);
    return false;
  }
}
