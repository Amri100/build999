// Quality Assurance Service
// Checks for common translation issues and provides warnings

import type { GameScriptEntry } from '@/types';

export interface QAIssue {
  id: string;
  type: 'missing' | 'too_long' | 'format_mismatch' | 'inconsistent' | 'placeholder_missing' | 'untranslated';
  severity: 'error' | 'warning' | 'info';
  entryId: string;
  original: string;
  translated: string;
  message: string;
  suggestion?: string;
}

export interface QAResult {
  issues: QAIssue[];
  summary: {
    errors: number;
    warnings: number;
    info: number;
    total: number;
  };
}

// Maximum length multipliers (translated text shouldn't exceed these)
const LENGTH_MULTIPLIERS: Record<string, number> = {
  'Japanese': 1.5,
  'Chinese': 1.2,
  'Korean': 1.3,
  'Indonesian': 1.4,
  'English': 1.0,
  'German': 1.3,
  'French': 1.2,
  'Spanish': 1.2,
  'default': 1.5,
};

// Run all QA checks
export function runQAChecks(
  entries: GameScriptEntry[],
  targetLang: string,
  maxLength?: number
): QAResult {
  const issues: QAIssue[] = [];
  
  issues.push(...checkMissingTranslations(entries));
  issues.push(...checkLengthViolations(entries, targetLang, maxLength));
  issues.push(...checkFormatMismatches(entries));
  issues.push(...checkPlaceholderConsistency(entries));
  issues.push(...checkInconsistentTranslations(entries));
  
  const summary = {
    errors: issues.filter(i => i.severity === 'error').length,
    warnings: issues.filter(i => i.severity === 'warning').length,
    info: issues.filter(i => i.severity === 'info').length,
    total: issues.length,
  };
  
  return { issues, summary };
}

// Check for missing translations
function checkMissingTranslations(entries: GameScriptEntry[]): QAIssue[] {
  const issues: QAIssue[] = [];
  
  entries.forEach(entry => {
    if (!entry.translated || entry.translated.trim() === '') {
      issues.push({
        id: `missing-${entry.id}`,
        type: 'missing',
        severity: 'error',
        entryId: entry.id,
        original: entry.original,
        translated: '',
        message: 'Translation is missing',
        suggestion: 'Please provide a translation for this text',
      });
    }
  });
  
  return issues;
}

// Check for length violations
function checkLengthViolations(
  entries: GameScriptEntry[],
  targetLang: string,
  maxLength?: number
): QAIssue[] {
  const issues: QAIssue[] = [];
  const multiplier = LENGTH_MULTIPLIERS[targetLang] || LENGTH_MULTIPLIERS.default;
  
  entries.forEach(entry => {
    if (!entry.translated) return;
    
    const originalLength = entry.original.length;
    const translatedLength = entry.translated.length;
    const allowedLength = maxLength || Math.floor(originalLength * multiplier);
    
    if (translatedLength > allowedLength) {
      issues.push({
        id: `length-${entry.id}`,
        type: 'too_long',
        severity: 'warning',
        entryId: entry.id,
        original: entry.original,
        translated: entry.translated,
        message: `Translation is too long (${translatedLength} chars, max ${allowedLength})`,
        suggestion: 'Try to shorten the translation or use abbreviations',
      });
    }
  });
  
  return issues;
}

// Check for format mismatches (e.g., different number of newlines)
function checkFormatMismatches(entries: GameScriptEntry[]): QAIssue[] {
  const issues: QAIssue[] = [];
  
  entries.forEach(entry => {
    if (!entry.translated) return;
    
    const originalNewlines = (entry.original.match(/\n/g) || []).length;
    const translatedNewlines = (entry.translated.match(/\n/g) || []).length;
    
    if (originalNewlines !== translatedNewlines) {
      issues.push({
        id: `format-${entry.id}`,
        type: 'format_mismatch',
        severity: 'warning',
        entryId: entry.id,
        original: entry.original,
        translated: entry.translated,
        message: `Newline count mismatch (original: ${originalNewlines}, translated: ${translatedNewlines})`,
        suggestion: 'Preserve the same number of line breaks as the original',
      });
    }
    
    // Check for trailing/leading whitespace differences
    const originalHasLeadingSpace = entry.original.startsWith(' ');
    const translatedHasLeadingSpace = entry.translated.startsWith(' ');
    const originalHasTrailingSpace = entry.original.endsWith(' ');
    const translatedHasTrailingSpace = entry.translated.endsWith(' ');
    
    if (originalHasLeadingSpace !== translatedHasLeadingSpace ||
        originalHasTrailingSpace !== translatedHasTrailingSpace) {
      issues.push({
        id: `whitespace-${entry.id}`,
        type: 'format_mismatch',
        severity: 'info',
        entryId: entry.id,
        original: entry.original,
        translated: entry.translated,
        message: 'Leading/trailing whitespace mismatch',
        suggestion: 'Preserve whitespace from the original text',
      });
    }
  });
  
  return issues;
}

// Check for placeholder consistency (e.g., {name}, [player], etc.)
function checkPlaceholderConsistency(entries: GameScriptEntry[]): QAIssue[] {
  const issues: QAIssue[] = [];
  
  // Common placeholder patterns
  const placeholderPatterns = [
    /\{[^}]+\}/g,  // {name}, {item}, etc.
    /\[[^\]]+\]/g, // [player], [target], etc.
    /%\w+/g,       // %s, %d, etc.
    /\$\w+/g,      // $name, etc.
    /<[^>]+>/g,    // <name>, etc.
  ];
  
  entries.forEach(entry => {
    if (!entry.translated) return;
    
    for (const pattern of placeholderPatterns) {
      const originalPlaceholders = entry.original.match(pattern) || [];
      const translatedPlaceholders = entry.translated.match(pattern) || [];
      
      // Check if all placeholders are preserved
      for (const placeholder of originalPlaceholders) {
        if (!(translatedPlaceholders as string[]).includes(placeholder as string)) {
          issues.push({
            id: `placeholder-${entry.id}-${placeholder}`,
            type: 'placeholder_missing',
            severity: 'error',
            entryId: entry.id,
            original: entry.original,
            translated: entry.translated,
            message: `Missing placeholder: "${placeholder}"`,
            suggestion: `Make sure to include "${placeholder}" in the translation`,
          });
        }
      }
      
      // Check for extra placeholders
      for (const placeholder of translatedPlaceholders) {
        if (!(originalPlaceholders as string[]).includes(placeholder as string)) {
          issues.push({
            id: `placeholder-extra-${entry.id}-${placeholder}`,
            type: 'placeholder_missing',
            severity: 'warning',
            entryId: entry.id,
            original: entry.original,
            translated: entry.translated,
            message: `Extra placeholder: "${placeholder}"`,
            suggestion: `Remove "${placeholder}" unless it was intentionally added`,
          });
        }
      }
    }
  });
  
  return issues;
}

// Check for inconsistent translations (same source translated differently)
function checkInconsistentTranslations(entries: GameScriptEntry[]): QAIssue[] {
  const issues: QAIssue[] = [];
  const translationMap = new Map<string, Set<string>>();
  
  // Group translations by original text
  entries.forEach(entry => {
    if (!entry.translated) return;
    
    const key = entry.original.toLowerCase().trim();
    if (!translationMap.has(key)) {
      translationMap.set(key, new Set());
    }
    translationMap.get(key)!.add(entry.translated);
  });
  
  // Find inconsistencies
  translationMap.forEach((translations, original) => {
    if (translations.size > 1) {
      // Find entries with this original text
      const affectedEntries = entries.filter(e => 
        e.original.toLowerCase().trim() === original && e.translated
      );
      
      if (affectedEntries.length > 1) {
        const firstTranslation = affectedEntries[0].translated;
        affectedEntries.slice(1).forEach(entry => {
          if (entry.translated !== firstTranslation) {
            issues.push({
              id: `inconsistent-${entry.id}`,
              type: 'inconsistent',
              severity: 'info',
              entryId: entry.id,
              original: entry.original,
              translated: entry.translated,
              message: `Inconsistent translation (also translated as: "${firstTranslation}")`,
              suggestion: 'Consider using the same translation for consistency',
            });
          }
        });
      }
    }
  });
  
  return issues;
}

// Quick check for untranslated text (text that looks like the original)
export function checkUntranslated(entries: GameScriptEntry[]): QAIssue[] {
  const issues: QAIssue[] = [];
  
  entries.forEach(entry => {
    if (!entry.translated) return;
    
    const similarity = calculateSimilarity(
      entry.original.toLowerCase(),
      entry.translated.toLowerCase()
    );
    
    // If similarity is very high, it might be untranslated
    if (similarity > 0.9 && entry.original !== entry.translated) {
      issues.push({
        id: `untranslated-${entry.id}`,
        type: 'untranslated',
        severity: 'warning',
        entryId: entry.id,
        original: entry.original,
        translated: entry.translated,
        message: 'Text appears to be untranslated or minimally changed',
        suggestion: 'Please verify this translation is correct',
      });
    }
  });
  
  return issues;
}

// Calculate similarity between two strings (0-1)
function calculateSimilarity(str1: string, str2: string): number {
  if (str1 === str2) return 1;
  if (!str1.length || !str2.length) return 0;
  
  const longer = str1.length > str2.length ? str1 : str2;
  const shorter = str1.length > str2.length ? str2 : str1;
  
  if (longer.length === 0) return 1;
  
  const distance = levenshteinDistance(longer, shorter);
  return (longer.length - distance) / longer.length;
}

function levenshteinDistance(str1: string, str2: string): number {
  const matrix: number[][] = [];
  
  for (let i = 0; i <= str2.length; i++) {
    matrix[i] = [i];
  }
  
  for (let j = 0; j <= str1.length; j++) {
    matrix[0][j] = j;
  }
  
  for (let i = 1; i <= str2.length; i++) {
    for (let j = 1; j <= str1.length; j++) {
      if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  
  return matrix[str2.length][str1.length];
}

// Get issues for a specific entry
export function getIssuesForEntry(entryId: string, issues: QAIssue[]): QAIssue[] {
  return issues.filter(i => i.entryId === entryId);
}

// Filter issues by type
export function filterIssuesByType(issues: QAIssue[], type: QAIssue['type']): QAIssue[] {
  return issues.filter(i => i.type === type);
}

// Filter issues by severity
export function filterIssuesBySeverity(issues: QAIssue[], severity: QAIssue['severity']): QAIssue[] {
  return issues.filter(i => i.severity === severity);
}
