# Game Translation Hub - v4.0 Enhanced Edition

## Overview

This is an enhanced version of the Game Translation Hub with numerous new features and improvements for professional game localization.

## New Features Added

### 1. AI Translation Support (NEW)
- **OpenRouter Integration**: Support for multiple AI models including:
  - Claude 3.5 Sonnet
  - GPT-4o Mini
  - Gemini Flash 1.5
  - Llama 3.1 70B
  - Claude 3 Haiku
- **Ollama Local AI**: Run AI models locally for privacy
- Configurable temperature, max tokens, and endpoints
- Test connection functionality

### 2. Enhanced Export Formats (NEW)
- **ZIP Archive**: Original file structure with translations applied
- **JSON**: Structured JSON format
- **CSV**: Spreadsheet format
- **XLSX**: Microsoft Excel format
- **PO**: GNU Gettext format for localization
- **XLIFF**: Localization interchange format for CAT tools
- **YAML**: Human-readable configuration format

### 3. Collaboration Features (NEW)
- Real-time user presence tracking
- Activity logs for all team actions
- Comments system for translator communication
- Share links (view-only and edit permissions)
- User avatars and status indicators
- Team member management

### 4. Backup & Restore (NEW)
- Automatic backup with configurable intervals
- Manual backup creation
- Backup import/export
- Storage usage tracking
- Backup history management
- Compressed backup support

### 5. Additional Game Engine Support (NEW)
- **TyranoBuilder**: TyranoScript VN engine
- **Visual Novel Maker**: Degica VN Maker
- **Wolf RPG Editor**: Wolf RPG format
- **GameMaker Studio**: GameMaker localization

### 6. Enhanced UI Components
- **AISettingsDialog**: Configure AI translation providers
- **ExportDialog**: Multi-format export with options
- **CollaborationPanel**: Team collaboration interface
- **BackupDialog**: Backup/restore management

### 7. Improved Types & Interfaces
- Extended GameScriptEntry with new fields
- New types for AI providers, export configs
- Collaboration user and activity types
- Backup info and settings types

## File Structure Changes

```
src/
├── components/
│   ├── AISettingsDialog.tsx      # NEW - AI provider configuration
│   ├── BackupDialog.tsx          # NEW - Backup management
│   ├── CollaborationPanel.tsx    # NEW - Team collaboration
│   ├── DonateSection.tsx         # Existing
│   └── ExportDialog.tsx          # NEW - Multi-format export
├── services/
│   ├── aiTranslationService.ts   # NEW - AI translation logic
│   ├── backupService.ts          # NEW - Backup functionality
│   ├── collaborationService.ts   # NEW - Collaboration features
│   ├── enhancedParserService.ts  # NEW - Additional parsers
│   └── exportImportService.ts    # NEW - Export formats
└── types/
    └── index.ts                  # UPDATED - Extended types
```

## Dependencies Added

```json
{
  "file-saver": "^2.0.5"
}
```

## How to Use

### Setup
```bash
npm install
npm run dev
```

### AI Translation
1. Click the "AI" button in the editor toolbar
2. Configure your OpenRouter API key or Ollama endpoint
3. Select your preferred model
4. Use AI translation for selected entries

### Export
1. Click the "Export" button in the editor toolbar
2. Select your desired format
3. Configure export options
4. Download the exported file

### Collaboration
1. Click the "Team" button in the header
2. Share the project link with team members
3. Track user activity and add comments

### Backup
1. Click the "Backup" button in the header
2. Configure auto-backup settings
3. Create manual backups or restore from history

## Keyboard Shortcuts

- `Ctrl+O`: Open files
- `Ctrl+S`: Export
- `Ctrl+A`: Select all
- `Ctrl+F`: Find & Replace
- `Ctrl+Z`: Undo
- `Esc`: Clear selection

## Supported File Formats

- RPG Maker MV/MZ (.json)
- KiriKiri/KAG (.ks, .tjs)
- Ren'Py (.rpy)
- TyranoBuilder (.ks)
- Visual Novel Maker (.json)
- Wolf RPG (.mps, .dat)
- GameMaker Studio (.json, .yyp)
- Unity/JSON (.json)
- Subtitles/SRT (.srt)
- Generic/CSV (.csv, .txt)

## Credits

Enhanced by AI Assistant based on the original Game Translation Hub by Amri100.
