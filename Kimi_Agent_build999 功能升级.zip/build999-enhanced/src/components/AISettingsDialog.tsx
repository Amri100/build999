import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { toast } from 'sonner';
import { Brain, Key, Server, TestTube, CheckCircle, XCircle, Loader2 } from 'lucide-react';
import { getAllAIProviders, saveAIProviderConfig, testAIProvider, type AIProviderConfig } from '@/services/aiTranslationService';

interface AISettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

const OPENROUTER_MODELS = [
  { id: 'anthropic/claude-3.5-sonnet', name: 'Claude 3.5 Sonnet', desc: 'Best for translations' },
  { id: 'openai/gpt-4o-mini', name: 'GPT-4o Mini', desc: 'Fast and affordable' },
  { id: 'google/gemini-flash-1.5', name: 'Gemini Flash 1.5', desc: 'Fast responses' },
  { id: 'meta-llama/llama-3.1-70b-instruct', name: 'Llama 3.1 70B', desc: 'Open source' },
  { id: 'anthropic/claude-3-haiku', name: 'Claude 3 Haiku', desc: 'Quick translations' },
];

const OLLAMA_MODELS = [
  { id: 'llama3', name: 'Llama 3', desc: 'General purpose' },
  { id: 'llama3.1', name: 'Llama 3.1', desc: 'Improved version' },
  { id: 'mistral', name: 'Mistral', desc: 'Good for translations' },
  { id: 'gemma2', name: 'Gemma 2', desc: 'Google model' },
  { id: 'qwen2', name: 'Qwen 2', desc: 'Multilingual' },
];

export function AISettingsDialog({ open, onOpenChange }: AISettingsDialogProps) {
  const [providers, setProviders] = useState<AIProviderConfig[]>([]);
  const [activeTab, setActiveTab] = useState('openrouter');
  const [testing, setTesting] = useState(false);
  const [testResult, setTestResult] = useState<{ success: boolean; message: string } | null>(null);

  useEffect(() => {
    if (open) {
      setProviders(getAllAIProviders());
    }
  }, [open]);

  const activeProvider = providers.find(p => p.id === activeTab);

  const handleSave = () => {
    if (activeProvider) {
      saveAIProviderConfig(activeProvider);
      toast.success('AI provider settings saved');
    }
  };

  const handleTest = async () => {
    if (!activeProvider) return;
    
    setTesting(true);
    setTestResult(null);
    
    const result = await testAIProvider(activeProvider.id);
    setTestResult(result);
    
    setTesting(false);
    
    if (result.success) {
      toast.success(result.message);
    } else {
      toast.error(result.message);
    }
  };

  const updateProvider = (updates: Partial<AIProviderConfig>) => {
    if (activeProvider) {
      const updated = { ...activeProvider, ...updates };
      setProviders(providers.map(p => p.id === activeTab ? updated : p));
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Brain className="w-5 h-5" />
            AI Translation Settings
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          <div className="flex gap-2">
            <Button
              variant={activeTab === 'openrouter' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setActiveTab('openrouter')}
              className="flex-1"
            >
              <Server className="w-4 h-4 mr-2" />
              OpenRouter
            </Button>
            <Button
              variant={activeTab === 'ollama' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setActiveTab('ollama')}
              className="flex-1"
            >
              <Server className="w-4 h-4 mr-2" />
              Ollama (Local)
            </Button>
          </div>

          {activeProvider && (
            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 rounded-lg bg-muted">
                <div>
                  <Label className="font-medium">Enable {activeProvider.name}</Label>
                  <p className="text-sm text-muted-foreground">
                    Use this provider for AI translations
                  </p>
                </div>
                <Switch
                  checked={activeProvider.enabled}
                  onCheckedChange={(checked) => updateProvider({ enabled: checked })}
                />
              </div>

              {activeTab === 'openrouter' && (
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Key className="w-4 h-4" />
                    API Key
                  </Label>
                  <Input
                    type="password"
                    placeholder="sk-or-v1-..."
                    value={activeProvider.apiKey || ''}
                    onChange={(e) => updateProvider({ apiKey: e.target.value })}
                  />
                  <p className="text-xs text-muted-foreground">
                    Get your API key from{' '}
                    <a href="https://openrouter.ai/keys" target="_blank" rel="noopener noreferrer" className="text-primary underline">
                      openrouter.ai/keys
                    </a>
                  </p>
                </div>
              )}

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Server className="w-4 h-4" />
                  Endpoint URL
                </Label>
                <Input
                  value={activeProvider.endpoint || ''}
                  onChange={(e) => updateProvider({ endpoint: e.target.value })}
                  placeholder={activeTab === 'ollama' ? 'http://localhost:11434' : 'https://openrouter.ai/api/v1/chat/completions'}
                />
              </div>

              <div className="space-y-2">
                <Label>Model</Label>
                <Select
                  value={activeProvider.model}
                  onValueChange={(value) => updateProvider({ model: value })}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {(activeTab === 'openrouter' ? OPENROUTER_MODELS : OLLAMA_MODELS).map((model) => (
                      <SelectItem key={model.id} value={model.id}>
                        <div className="flex flex-col items-start">
                          <span>{model.name}</span>
                          <span className="text-xs text-muted-foreground">{model.desc}</span>
                        </div>
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between">
                  <Label>Temperature</Label>
                  <span className="text-sm text-muted-foreground">{activeProvider.temperature}</span>
                </div>
                <Slider
                  value={[activeProvider.temperature || 0.3]}
                  onValueChange={([value]) => updateProvider({ temperature: value })}
                  min={0}
                  max={1}
                  step={0.1}
                />
                <p className="text-xs text-muted-foreground">
                  Lower values = more consistent translations, Higher = more creative
                </p>
              </div>

              <div className="space-y-2">
                <Label>Max Tokens</Label>
                <Input
                  type="number"
                  value={activeProvider.maxTokens || 2000}
                  onChange={(e) => updateProvider({ maxTokens: parseInt(e.target.value) })}
                  min={100}
                  max={8000}
                  step={100}
                />
              </div>

              {testResult && (
                <div className={`p-3 rounded-lg flex items-center gap-2 ${testResult.success ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
                  {testResult.success ? <CheckCircle className="w-5 h-5" /> : <XCircle className="w-5 h-5" />}
                  <span className="text-sm">{testResult.message}</span>
                </div>
              )}

              <div className="flex gap-2">
                <Button variant="outline" onClick={handleTest} disabled={testing} className="flex-1">
                  {testing ? <Loader2 className="w-4 h-4 mr-2 animate-spin" /> : <TestTube className="w-4 h-4 mr-2" />}
                  Test Connection
                </Button>
                <Button onClick={handleSave} className="flex-1">
                  Save Settings
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
