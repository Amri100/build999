import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  FileArchive,
  FileJson,
  FileSpreadsheet,
  FileCode,
  Languages,
  Download,
  Check,
  AlertCircle,
  Loader2,
} from 'lucide-react';
import { ExportFormat, ExportConfig } from '@/types';
import { exportImportService } from '@/services/exportImportService';
import { toast } from 'sonner';

interface ExportDialogProps {
  isOpen: boolean;
  onClose: () => void;
  entries: any[];
  projectName: string;
}

const exportFormats: { value: ExportFormat; label: string; icon: React.ElementType; description: string }[] = [
  { value: 'zip', label: 'ZIP Archive', icon: FileArchive, description: 'Export all files as a compressed ZIP archive' },
  { value: 'json', label: 'JSON Format', icon: FileJson, description: 'Export in structured JSON format' },
  { value: 'csv', label: 'CSV Spreadsheet', icon: FileSpreadsheet, description: 'Export as CSV for spreadsheet applications' },
  { value: 'xlsx', label: 'Excel Workbook', icon: FileSpreadsheet, description: 'Export as Excel workbook with multiple sheets' },
  { value: 'po', label: 'Gettext PO', icon: FileCode, description: 'Export as GNU Gettext PO file' },
  { value: 'xliff', label: 'XLIFF 2.0', icon: Languages, description: 'Export as XLIFF for CAT tools' },
  { value: 'yaml', label: 'YAML Format', icon: FileCode, description: 'Export as YAML for configuration files' },
];

export const ExportDialog: React.FC<ExportDialogProps> = ({
  isOpen,
  onClose,
  entries,
  projectName,
}) => {
  const [selectedFormat, setSelectedFormat] = useState<ExportFormat>('zip');
  const [activeTab, setActiveTab] = useState('format');
  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportComplete, setExportComplete] = useState(false);

  // Export options
  const [options, setOptions] = useState({
    includeMetadata: true,
    includeComments: true,
    includeHistory: false,
    onlyTranslated: false,
    onlyApproved: false,
    preserveStructure: true,
  });

  const handleExport = async () => {
    if (entries.length === 0) {
      toast.error('No entries to export');
      return;
    }

    setIsExporting(true);
    setExportProgress(0);
    setExportComplete(false);

    const config: ExportConfig = {
      format: selectedFormat,
      ...options,
    };

    try {
      // Simulate progress
      const progressInterval = setInterval(() => {
        setExportProgress((prev) => {
          if (prev >= 90) {
            clearInterval(progressInterval);
            return 90;
          }
          return prev + 10;
        });
      }, 200);

      await exportImportService.exportTranslations(entries, config, projectName);

      clearInterval(progressInterval);
      setExportProgress(100);
      setExportComplete(true);
      toast.success(`Successfully exported as ${selectedFormat.toUpperCase()}`);

      setTimeout(() => {
        onClose();
        setIsExporting(false);
        setExportProgress(0);
        setExportComplete(false);
      }, 1500);
    } catch (error) {
      setIsExporting(false);
      toast.error('Export failed: ' + (error as Error).message);
    }
  };

  const toggleOption = (key: keyof typeof options) => {
    setOptions((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const SelectedIcon = exportFormats.find((f) => f.value === selectedFormat)?.icon || FileArchive;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="w-5 h-5" />
            Export Translations
          </DialogTitle>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="format">Select Format</TabsTrigger>
            <TabsTrigger value="options">Export Options</TabsTrigger>
          </TabsList>

          <TabsContent value="format" className="mt-4">
            <ScrollArea className="h-[400px] pr-4">
              <RadioGroup
                value={selectedFormat}
                onValueChange={(value) => setSelectedFormat(value as ExportFormat)}
                className="space-y-3"
              >
                {exportFormats.map((format) => {
                  const Icon = format.icon;
                  return (
                    <div
                      key={format.value}
                      className={`flex items-start space-x-3 p-4 rounded-lg border-2 transition-all cursor-pointer ${
                        selectedFormat === format.value
                          ? 'border-primary bg-primary/5'
                          : 'border-border hover:border-primary/50'
                      }`}
                      onClick={() => setSelectedFormat(format.value)}
                    >
                      <RadioGroupItem value={format.value} id={format.value} className="mt-1" />
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <Icon className="w-5 h-5 text-primary" />
                          <Label
                            htmlFor={format.value}
                            className="font-semibold cursor-pointer"
                          >
                            {format.label}
                          </Label>
                          {selectedFormat === format.value && (
                            <Badge variant="default" className="ml-auto">
                              <Check className="w-3 h-3 mr-1" />
                              Selected
                            </Badge>
                          )}
                        </div>
                        <p className="text-sm text-muted-foreground mt-1 ml-7">
                          {format.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </RadioGroup>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="options" className="mt-4">
            <ScrollArea className="h-[400px] pr-4">
              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <FileJson className="w-4 h-4" />
                    Content Options
                  </h4>
                  <div className="space-y-3 ml-6">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="includeMetadata"
                        checked={options.includeMetadata}
                        onCheckedChange={() => toggleOption('includeMetadata')}
                      />
                      <Label htmlFor="includeMetadata" className="cursor-pointer">
                        Include metadata (timestamps, authors, etc.)
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="includeComments"
                        checked={options.includeComments}
                        onCheckedChange={() => toggleOption('includeComments')}
                      />
                      <Label htmlFor="includeComments" className="cursor-pointer">
                        Include translator comments
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="includeHistory"
                        checked={options.includeHistory}
                        onCheckedChange={() => toggleOption('includeHistory')}
                      />
                      <Label htmlFor="includeHistory" className="cursor-pointer">
                        Include translation history
                      </Label>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <Languages className="w-4 h-4" />
                    Filter Options
                  </h4>
                  <div className="space-y-3 ml-6">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="onlyTranslated"
                        checked={options.onlyTranslated}
                        onCheckedChange={() => toggleOption('onlyTranslated')}
                      />
                      <Label htmlFor="onlyTranslated" className="cursor-pointer">
                        Export only translated entries
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="onlyApproved"
                        checked={options.onlyApproved}
                        onCheckedChange={() => toggleOption('onlyApproved')}
                      />
                      <Label htmlFor="onlyApproved" className="cursor-pointer">
                        Export only approved translations
                      </Label>
                    </div>
                  </div>
                </div>

                <Separator />

                <div>
                  <h4 className="font-semibold mb-3 flex items-center gap-2">
                    <FileArchive className="w-4 h-4" />
                    Structure Options
                  </h4>
                  <div className="space-y-3 ml-6">
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="preserveStructure"
                        checked={options.preserveStructure}
                        onCheckedChange={() => toggleOption('preserveStructure')}
                      />
                      <Label htmlFor="preserveStructure" className="cursor-pointer">
                        Preserve original file structure
                      </Label>
                    </div>
                  </div>
                </div>

                <div className="bg-muted p-4 rounded-lg flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-muted-foreground flex-shrink-0 mt-0.5" />
                  <div className="text-sm text-muted-foreground">
                    <strong>Export Summary:</strong> You are about to export{' '}
                    <strong>{entries.length}</strong> entries in{' '}
                    <strong>{selectedFormat.toUpperCase()}</strong> format.
                    {options.onlyTranslated && ' Only translated entries will be included.'}
                    {options.onlyApproved && ' Only approved translations will be included.'}
                  </div>
                </div>
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>

        {isExporting && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                Exporting...
              </span>
              <span>{exportProgress}%</span>
            </div>
            <Progress value={exportProgress} className="h-2" />
          </div>
        )}

        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button variant="outline" onClick={onClose} disabled={isExporting}>
            Cancel
          </Button>
          <Button
            onClick={handleExport}
            disabled={isExporting || entries.length === 0}
            className="gap-2"
          >
            {isExporting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Exporting...
              </>
            ) : exportComplete ? (
              <>
                <Check className="w-4 h-4" />
                Complete!
              </>
            ) : (
              <>
                <SelectedIcon className="w-4 h-4" />
                Export as {selectedFormat.toUpperCase()}
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
