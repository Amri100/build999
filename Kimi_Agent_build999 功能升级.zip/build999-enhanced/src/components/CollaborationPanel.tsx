import React, { useState, useEffect } from 'react';
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Users,
  MessageSquare,
  Activity,
  Send,
  MoreHorizontal,
  UserPlus,
  Link2,
  Clock,
  Check,
  X,
  Edit3,
  Eye,
} from 'lucide-react';
import { collaborationService, CollaborationUser, ActivityLog, Comment } from '@/services/collaborationService';
import { toast } from 'sonner';
import { formatDistanceToNow } from 'date-fns';

interface CollaborationPanelProps {
  projectId: string;
  currentUser: CollaborationUser;
  entryId?: string;
}

export const CollaborationPanel: React.FC<CollaborationPanelProps> = ({
  projectId,
  currentUser,
  entryId,
}) => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeUsers, setActiveUsers] = useState<CollaborationUser[]>([]);
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [inviteEmail, setInviteEmail] = useState('');
  const [showInviteInput, setShowInviteInput] = useState(false);

  useEffect(() => {
    if (isOpen) {
      // Initialize collaboration service
      collaborationService.initialize(projectId, currentUser);
      setIsConnected(true);

      // Subscribe to updates
      const unsubscribeUsers = collaborationService.onUsersUpdate(setActiveUsers);
      const unsubscribeActivities = collaborationService.onActivitiesUpdate(setActivities);
      const unsubscribeComments = collaborationService.onCommentsUpdate(setComments);

      return () => {
        unsubscribeUsers();
        unsubscribeActivities();
        unsubscribeComments();
      };
    }
  }, [isOpen, projectId, currentUser]);

  const handleSendComment = () => {
    if (!newComment.trim()) return;

    collaborationService.addComment({
      entryId,
      content: newComment,
      author: currentUser,
    });

    setNewComment('');
    toast.success('Comment added');
  };

  const handleInviteUser = () => {
    if (!inviteEmail.trim()) return;

    collaborationService.inviteUser(inviteEmail);
    setInviteEmail('');
    setShowInviteInput(false);
    toast.success(`Invitation sent to ${inviteEmail}`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'away':
        return 'bg-yellow-500';
      case 'busy':
        return 'bg-red-500';
      default:
        return 'bg-gray-400';
    }
  };

  const getActivityIcon = (action: string) => {
    switch (action) {
      case 'translate':
        return <Edit3 className="w-4 h-4" />;
      case 'review':
        return <Check className="w-4 h-4" />;
      case 'comment':
        return <MessageSquare className="w-4 h-4" />;
      case 'join':
        return <UserPlus className="w-4 h-4" />;
      default:
        return <Activity className="w-4 h-4" />;
    }
  };

  return (
    <Sheet open={isOpen} onOpenChange={setIsOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2 relative">
          <Users className="w-4 h-4" />
          Team
          {activeUsers.length > 0 && (
            <Badge variant="secondary" className="ml-1 h-5 min-w-5 flex items-center justify-center">
              {activeUsers.length}
            </Badge>
          )}
          {isConnected && (
            <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full border-2 border-background" />
          )}
        </Button>
      </SheetTrigger>
      <SheetContent className="w-[400px] sm:w-[540px]">
        <SheetHeader>
          <SheetTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Team Collaboration
            {isConnected && (
              <Badge variant="outline" className="ml-auto text-green-600 border-green-600">
                Live
              </Badge>
            )}
          </SheetTitle>
        </SheetHeader>

        <Tabs defaultValue="users" className="mt-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="users" className="gap-1">
              <Users className="w-4 h-4" />
              Users
            </TabsTrigger>
            <TabsTrigger value="activity" className="gap-1">
              <Activity className="w-4 h-4" />
              Activity
            </TabsTrigger>
            <TabsTrigger value="comments" className="gap-1">
              <MessageSquare className="w-4 h-4" />
              Comments
            </TabsTrigger>
          </TabsList>

          <TabsContent value="users" className="mt-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-semibold text-muted-foreground">
                  Active Users ({activeUsers.length})
                </h4>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowInviteInput(!showInviteInput)}
                >
                  <UserPlus className="w-4 h-4 mr-1" />
                  Invite
                </Button>
              </div>

              {showInviteInput && (
                <div className="flex gap-2">
                  <Input
                    placeholder="Enter email address"
                    value={inviteEmail}
                    onChange={(e) => setInviteEmail(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleInviteUser()}
                  />
                  <Button size="sm" onClick={handleInviteUser}>
                    <Send className="w-4 h-4" />
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setShowInviteInput(false)}>
                    <X className="w-4 h-4" />
                  </Button>
                </div>
              )}

              <ScrollArea className="h-[400px]">
                <div className="space-y-3">
                  {activeUsers.map((user) => (
                    <div
                      key={user.id}
                      className="flex items-center gap-3 p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                    >
                      <div className="relative">
                        <Avatar className="w-10 h-10">
                          <AvatarImage src={user.avatar} />
                          <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <span
                          className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-background ${getStatusColor(
                            user.status
                          )}`}
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className="font-medium truncate">{user.name}</span>
                          {user.id === currentUser.id && (
                            <Badge variant="secondary" className="text-xs">
                              You
                            </Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-sm text-muted-foreground">
                          <span className="truncate">{user.email}</span>
                          {user.currentEntry && (
                            <>
                              <span>•</span>
                              <span className="flex items-center gap-1">
                                <Edit3 className="w-3 h-3" />
                                Editing
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                      <TooltipProvider>
                        <Tooltip>
                          <TooltipTrigger asChild>
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <Eye className="w-4 h-4" />
                            </Button>
                          </TooltipTrigger>
                          <TooltipContent>
                            <p>View user activity</p>
                          </TooltipContent>
                        </Tooltip>
                      </TooltipProvider>
                    </div>
                  ))}

                  {activeUsers.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <Users className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No active users</p>
                      <p className="text-sm">Invite team members to collaborate</p>
                    </div>
                  )}
                </div>
              </ScrollArea>

              <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                <Link2 className="w-4 h-4 text-muted-foreground" />
                <Input
                  value={`${window.location.origin}/join/${projectId}`}
                  readOnly
                  className="flex-1 text-sm"
                />
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    navigator.clipboard.writeText(`${window.location.origin}/join/${projectId}`);
                    toast.success('Link copied to clipboard');
                  }}
                >
                  Copy
                </Button>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="activity" className="mt-4">
            <ScrollArea className="h-[450px]">
              <div className="space-y-4">
                {activities.map((activity) => (
                  <div key={activity.id} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                        {getActivityIcon(activity.action)}
                      </div>
                      <div className="w-px flex-1 bg-border mt-2" />
                    </div>
                    <div className="flex-1 pb-4">
                      <div className="flex items-start justify-between">
                        <div>
                          <span className="font-medium">{activity.userName}</span>{' '}
                          <span className="text-muted-foreground">
                            {activity.action === 'translate' && 'translated'}
                            {activity.action === 'review' && 'approved'}
                            {activity.action === 'comment' && 'commented on'}
                            {activity.action === 'join' && 'joined the project'}
                          </span>{' '}
                          {activity.entryKey && (
                            <span className="text-primary">"{activity.entryKey}"</span>
                          )}
                        </div>
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <span className="text-xs text-muted-foreground flex items-center gap-1">
                                <Clock className="w-3 h-3" />
                                {formatDistanceToNow(activity.timestamp, { addSuffix: true })}
                              </span>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>{activity.timestamp.toLocaleString()}</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                      {activity.details && (
                        <p className="text-sm text-muted-foreground mt-1">{activity.details}</p>
                      )}
                    </div>
                  </div>
                ))}

                {activities.length === 0 && (
                  <div className="text-center py-8 text-muted-foreground">
                    <Activity className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No recent activity</p>
                  </div>
                )}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="comments" className="mt-4">
            <div className="flex flex-col h-[450px]">
              <ScrollArea className="flex-1 pr-4">
                <div className="space-y-4">
                  {comments.map((comment) => (
                    <div key={comment.id} className="flex gap-3">
                      <Avatar className="w-8 h-8 flex-shrink-0">
                        <AvatarImage src={comment.author.avatar} />
                        <AvatarFallback>{comment.author.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-sm">{comment.author.name}</span>
                          <span className="text-xs text-muted-foreground">
                            {formatDistanceToNow(comment.timestamp, { addSuffix: true })}
                          </span>
                        </div>
                        <p className="text-sm mt-1">{comment.content}</p>
                        {comment.entryId && (
                          <Badge variant="outline" className="mt-2 text-xs">
                            On: {comment.entryId}
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))}

                  {comments.length === 0 && (
                    <div className="text-center py-8 text-muted-foreground">
                      <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" />
                      <p>No comments yet</p>
                      <p className="text-sm">Start a conversation with your team</p>
                    </div>
                  )}
                </div>
              </ScrollArea>

              <Separator className="my-4" />

              <div className="flex gap-2">
                <Textarea
                  placeholder="Add a comment..."
                  value={newComment}
                  onChange={(e) => setNewComment(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === 'Enter' && e.metaKey) {
                      handleSendComment();
                    }
                  }}
                  className="min-h-[80px] resize-none"
                />
                <Button
                  className="self-end"
                  onClick={handleSendComment}
                  disabled={!newComment.trim()}
                >
                  <Send className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </SheetContent>
    </Sheet>
  );
};
