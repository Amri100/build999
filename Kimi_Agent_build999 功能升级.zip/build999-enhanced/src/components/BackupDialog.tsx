import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Progress } from '@/components/ui/progress';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';
import {
  Archive,
  Download,
  Upload,
  Trash2,
  Clock,
  HardDrive,
  Cloud,
  Check,
  X,
  RotateCcw,
  Calendar,
  Settings,
  AlertCircle,
  Loader2,
} from 'lucide-react';
import { backupService, BackupInfo, BackupSettings } from '@/services/backupService';
import { toast } from 'sonner';
import { formatDistanceToNow, format } from 'date-fns';

interface BackupDialogProps {
  isOpen: boolean;
  onClose: () => void;
  projectId: string;
  projectData: any;
}

export const BackupDialog: React.FC<BackupDialogProps> = ({
  isOpen,
  onClose,
  projectId,
  projectData,
}) => {
  const [backups, setBackups] = useState<BackupInfo[]>([]);
  const [settings, setSettings] = useState<BackupSettings>({
    autoBackup: true,
    backupInterval: 30,
    maxBackups: 10,
    includeHistory: true,
    compressBackups: true,
  });
  const [isCreating, setIsCreating] = useState(false);
  const [isRestoring, setIsRestoring] = useState(false);
  const [progress, setProgress] = useState(0);
  const [storageInfo, setStorageInfo] = useState({ used: 0, total: 100 * 1024 * 1024 }); // 100MB default

  useEffect(() => {
    if (isOpen) {
      loadBackups();
      loadSettings();
    }
  }, [isOpen]);

  const loadBackups = () => {
    const allBackups = backupService.getAllBackups();
    setBackups(allBackups);
  };

  const loadSettings = () => {
    const savedSettings = backupService.getSettings();
    if (savedSettings) {
      setSettings(savedSettings);
    }
  };

  const handleCreateBackup = async () => {
    setIsCreating(true);
    setProgress(0);

    try {
      // Simulate progress
      const interval = setInterval(() => {
        setProgress((prev) => Math.min(prev + 20, 80));
      }, 200);

      await backupService.createBackup(projectId, projectData);

      clearInterval(interval);
      setProgress(100);
      toast.success('Backup created successfully');
      loadBackups();

      setTimeout(() => {
        setIsCreating(false);
        setProgress(0);
      }, 500);
    } catch (error) {
      setIsCreating(false);
      toast.error('Failed to create backup');
    }
  };

  const handleRestoreBackup = async (backupId: string) => {
    setIsRestoring(true);

    try {
      const restored = await backupService.restoreBackup(backupId);
      if (restored) {
        toast.success('Backup restored successfully');
        // You might want to reload the page or update the app state here
      } else {
        toast.error('Backup not found');
      }
    } catch (error) {
      toast.error('Failed to restore backup');
    } finally {
      setIsRestoring(false);
    }
  };

  const handleDeleteBackup = (backupId: string) => {
    const success = backupService.deleteBackup(backupId);
    if (success) {
      toast.success('Backup deleted');
      loadBackups();
    } else {
      toast.error('Failed to delete backup');
    }
  };

  const handleExportBackup = (backupId: string) => {
    const success = backupService.exportBackup(backupId);
    if (success) {
      toast.success('Backup exported');
    } else {
      toast.error('Failed to export backup');
    }
  };

  const handleImportBackup = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      await backupService.importBackup(file);
      toast.success('Backup imported successfully');
      loadBackups();
    } catch (error) {
      toast.error('Failed to import backup');
    }

    // Reset input
    event.target.value = '';
  };

  const updateSettings = (key: keyof BackupSettings, value: any) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    backupService.updateSettings(newSettings);
  };

  const formatBytes = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const totalBackupSize = backups.reduce((sum, b) => sum + b.size, 0);
  const storagePercent = (totalBackupSize / storageInfo.total) * 100;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Archive className="w-5 h-5" />
            Backup & Restore
          </DialogTitle>
          <DialogDescription>
            Manage your project backups and configure auto-backup settings
          </DialogDescription>
        </DialogHeader>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
          {/* Storage Overview */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <HardDrive className="w-4 h-4" />
                Storage Usage
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Used</span>
                  <span className="font-medium">{formatBytes(totalBackupSize)}</span>
                </div>
                <Progress value={storagePercent} className="h-2" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{backups.length} backups</span>
                  <span>{formatBytes(storageInfo.total)} total</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                <RotateCcw className="w-4 h-4" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2">
                <Button
                  onClick={handleCreateBackup}
                  disabled={isCreating}
                  className="w-full"
                  size="sm"
                >
                  {isCreating ? (
                    <Loader2 className="w-4 h-4 mr-1 animate-spin" />
                  ) : (
                    <Archive className="w-4 h-4 mr-1" />
                  )}
                  Backup Now
                </Button>
                <Label className="cursor-pointer">
                  <Input
                    type="file"
                    accept=".json,.zip"
                    className="hidden"
                    onChange={handleImportBackup}
                  />
                  <div className="flex items-center justify-center w-full h-9 px-3 rounded-md text-sm font-medium bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors">
                    <Upload className="w-4 h-4 mr-1" />
                    Import
                  </div>
                </Label>
              </div>
            </CardContent>
          </Card>
        </div>

        {isCreating && (
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="flex items-center gap-2">
                <Loader2 className="w-4 h-4 animate-spin" />
                Creating backup...
              </span>
              <span>{progress}%</span>
            </div>
            <Progress value={progress} className="h-2" />
          </div>
        )}

        {/* Backup List */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Backup History
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[250px]">
              <div className="space-y-2">
                {backups.length === 0 ? (
                  <div className="text-center py-8 text-muted-foreground">
                    <Archive className="w-12 h-12 mx-auto mb-3 opacity-50" />
                    <p>No backups yet</p>
                    <p className="text-sm">Create your first backup to protect your work</p>
                  </div>
                ) : (
                  backups.map((backup) => (
                    <div
                      key={backup.id}
                      className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                          <Archive className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <div className="font-medium">{backup.projectName}</div>
                          <div className="flex items-center gap-2 text-sm text-muted-foreground">
                            <Clock className="w-3 h-3" />
                            {formatDistanceToNow(backup.timestamp, { addSuffix: true })}
                            <span>•</span>
                            <span>{formatBytes(backup.size)}</span>
                            {backup.compressed && (
                              <Badge variant="outline" className="text-xs">
                                Compressed
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => handleRestoreBackup(backup.id)}
                                disabled={isRestoring}
                              >
                                <RotateCcw className="w-4 h-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Restore this backup</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>

                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8"
                                onClick={() => handleExportBackup(backup.id)}
                              >
                                <Download className="w-4 h-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Download backup</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>

                        <TooltipProvider>
                          <Tooltip>
                            <TooltipTrigger asChild>
                              <Button
                                variant="ghost"
                                size="icon"
                                className="h-8 w-8 text-destructive hover:text-destructive"
                                onClick={() => handleDeleteBackup(backup.id)}
                              >
                                <Trash2 className="w-4 h-4" />
                              </Button>
                            </TooltipTrigger>
                            <TooltipContent>
                              <p>Delete backup</p>
                            </TooltipContent>
                          </Tooltip>
                        </TooltipProvider>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </ScrollArea>
          </CardContent>
        </Card>

        {/* Settings */}
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium flex items-center gap-2">
              <Settings className="w-4 h-4" />
              Auto-Backup Settings
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="auto-backup">Enable Auto-Backup</Label>
                  <p className="text-sm text-muted-foreground">
                    Automatically create backups at regular intervals
                  </p>
                </div>
                <Switch
                  id="auto-backup"
                  checked={settings.autoBackup}
                  onCheckedChange={(checked) => updateSettings('autoBackup', checked)}
                />
              </div>

              <Separator />

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Backup Interval</Label>
                  <span className="text-sm font-medium">{settings.backupInterval} minutes</span>
                </div>
                <Slider
                  value={[settings.backupInterval]}
                  onValueChange={([value]) => updateSettings('backupInterval', value)}
                  min={5}
                  max={120}
                  step={5}
                  disabled={!settings.autoBackup}
                />
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Label>Max Backups to Keep</Label>
                  <span className="text-sm font-medium">{settings.maxBackups}</span>
                </div>
                <Slider
                  value={[settings.maxBackups]}
                  onValueChange={([value]) => updateSettings('maxBackups', value)}
                  min={5}
                  max={50}
                  step={5}
                />
              </div>

              <Separator />

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="include-history">Include History</Label>
                  <p className="text-sm text-muted-foreground">
                    Include translation history in backups
                  </p>
                </div>
                <Switch
                  id="include-history"
                  checked={settings.includeHistory}
                  onCheckedChange={(checked) => updateSettings('includeHistory', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label htmlFor="compress">Compress Backups</Label>
                  <p className="text-sm text-muted-foreground">
                    Compress backups to save storage space
                  </p>
                </div>
                <Switch
                  id="compress"
                  checked={settings.compressBackups}
                  onCheckedChange={(checked) => updateSettings('compressBackups', checked)}
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};
