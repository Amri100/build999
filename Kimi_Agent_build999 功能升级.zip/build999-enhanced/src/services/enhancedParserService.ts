import type { GameScriptEntry, TranslationProject } from '@/types';

export function parseTyranoBuilder(filename: string, content: string): GameScriptEntry[] {
  const entries: GameScriptEntry[] = [];
  const lines = content.split('\n');
  
  lines.forEach((line, idx) => {
    const textMatch = line.match(/\[text\s*(?:name="([^"]*)")?\s*\](.+?)(?:\[\/text\])?/i);
    if (textMatch) {
      entries.push({
        id: `tyrano-text-${filename}-${idx}`,
        original: textMatch[2].trim(),
        translated: "",
        path: `line-${idx}`,
        context: textMatch[1] ? `Character: ${textMatch[1]}` : 'Dialogue'
      });
      return;
    }

    const pMatch = line.match(/\[p\](.+?)\[\/p\]/i);
    if (pMatch) {
      entries.push({
        id: `tyrano-p-${filename}-${idx}`,
        original: pMatch[1].trim(),
        translated: "",
        path: `line-${idx}`,
        context: 'Paragraph'
      });
      return;
    }

    const buttonMatch = line.match(/\[button\s+[^>]*text="([^"]+)"/i);
    if (buttonMatch) {
      entries.push({
        id: `tyrano-button-${filename}-${idx}`,
        original: buttonMatch[1].trim(),
        translated: "",
        path: `line-${idx}`,
        context: 'Button'
      });
      return;
    }

    const titleMatch = line.match(/\[title\s*text="([^"]+)"/i);
    if (titleMatch) {
      entries.push({
        id: `tyrano-title-${filename}-${idx}`,
        original: titleMatch[1].trim(),
        translated: "",
        path: `line-${idx}`,
        context: 'Title'
      });
      return;
    }
  });

  return entries;
}

export function parseVisualNovelMaker(filename: string, content: string): GameScriptEntry[] {
  const entries: GameScriptEntry[] = [];
  
  try {
    const data = JSON.parse(content);

    if (data.dialogues && Array.isArray(data.dialogues)) {
      data.dialogues.forEach((dialogue: any, idx: number) => {
        if (dialogue.text) {
          entries.push({
            id: `vnm-dialogue-${filename}-${idx}`,
            original: dialogue.text,
            translated: "",
            path: `dialogues[${idx}].text`,
            context: dialogue.speaker ? `Speaker: ${dialogue.speaker}` : 'Dialogue'
          });
        }
        if (dialogue.speaker) {
          entries.push({
            id: `vnm-speaker-${filename}-${idx}`,
            original: dialogue.speaker,
            translated: "",
            path: `dialogues[${idx}].speaker`,
            context: 'Speaker Name'
          });
        }
      });
    }

    if (data.choices && Array.isArray(data.choices)) {
      data.choices.forEach((choice: any, idx: number) => {
        if (choice.text) {
          entries.push({
            id: `vnm-choice-${filename}-${idx}`,
            original: choice.text,
            translated: "",
            path: `choices[${idx}].text`,
            context: 'Choice'
          });
        }
      });
    }

    if (data.ui && typeof data.ui === 'object') {
      Object.entries(data.ui).forEach(([key, value]: [string, any]) => {
        if (typeof value === 'string') {
          entries.push({
            id: `vnm-ui-${filename}-${key}`,
            original: value,
            translated: "",
            path: `ui.${key}`,
            context: 'UI Text'
          });
        }
      });
    }

    traverseVNMData(data, '', entries, filename);

  } catch (e) {
    console.error('Error parsing Visual Novel Maker file:', e);
  }

  return entries;
}

function traverseVNMData(obj: any, path: string, entries: GameScriptEntry[], filename: string): void {
  if (typeof obj === 'string' && obj.trim().length > 2) {
    if (/\.(png|jpg|jpeg|ogg|mp3|wav|json)$/i.test(obj)) return;
    if (/^#?[0-9a-f]{6}$/i.test(obj)) return;
    if (/^\d+$/.test(obj)) return;

    entries.push({
      id: `vnm-${filename}-${entries.length}`,
      original: obj,
      translated: "",
      path: path,
      context: 'VNM Data'
    });
  } else if (Array.isArray(obj)) {
    obj.forEach((item, idx) => traverseVNMData(item, `${path}[${idx}]`, entries, filename));
  } else if (typeof obj === 'object' && obj !== null) {
    const skipKeys = ['id', 'uuid', 'filename', 'path', 'url', 'icon', 'image', 'sprite', 'audio', 'bgm', 'se', 'me', 'color', 'position', 'size'];
    
    Object.entries(obj).forEach(([key, value]) => {
      if (!skipKeys.includes(key.toLowerCase())) {
        traverseVNMData(value, path ? `${path}.${key}` : key, entries, filename);
      }
    });
  }
}

export function parseWolfRPG(filename: string, content: string): GameScriptEntry[] {
  const entries: GameScriptEntry[] = [];
  
  try {
    const data = JSON.parse(content);

    if (data.CommonEvents && Array.isArray(data.CommonEvents)) {
      data.CommonEvents.forEach((event: any, eventIdx: number) => {
        if (event.Name) {
          entries.push({
            id: `wolf-ce-name-${filename}-${eventIdx}`,
            original: event.Name,
            translated: "",
            path: `CommonEvents[${eventIdx}].Name`,
            context: 'Common Event Name'
          });
        }

        if (event.Commands && Array.isArray(event.Commands)) {
          event.Commands.forEach((cmd: any, cmdIdx: number) => {
            if (cmd.Code === 0 && cmd.StringParams && cmd.StringParams[0]) {
              entries.push({
                id: `wolf-ce-cmd-${filename}-${eventIdx}-${cmdIdx}`,
                original: cmd.StringParams[0],
                translated: "",
                path: `CommonEvents[${eventIdx}].Commands[${cmdIdx}].StringParams[0]`,
                context: `Common Event: ${event.Name || eventIdx}`
              });
            }
          });
        }
      });
    }

    if (data.Database && typeof data.Database === 'object') {
      Object.entries(data.Database).forEach(([dbName, dbData]: [string, any]) => {
        if (Array.isArray(dbData)) {
          dbData.forEach((item: any, idx: number) => {
            if (item.Name) {
              entries.push({
                id: `wolf-db-${filename}-${dbName}-${idx}`,
                original: item.Name,
                translated: "",
                path: `Database.${dbName}[${idx}].Name`,
                context: `${dbName} Name`
              });
            }
            if (item.Description) {
              entries.push({
                id: `wolf-db-desc-${filename}-${dbName}-${idx}`,
                original: item.Description,
                translated: "",
                path: `Database.${dbName}[${idx}].Description`,
                context: `${dbName} Description`
              });
            }
          });
        }
      });
    }

  } catch (e) {
    console.error('Error parsing Wolf RPG file:', e);
  }

  return entries;
}

export function parseGameMaker(filename: string, content: string): GameScriptEntry[] {
  const entries: GameScriptEntry[] = [];
  
  try {
    const data = JSON.parse(content);

    if (data.strings && Array.isArray(data.strings)) {
      data.strings.forEach((str: any, idx: number) => {
        if (str.text || str.value || str.string) {
          entries.push({
            id: `gm-string-${filename}-${idx}`,
            original: str.text || str.value || str.string,
            translated: "",
            path: `strings[${idx}]`,
            context: str.context || str.key || 'String'
          });
        }
      });
    }

    traverseGameMakerData(data, '', entries, filename);

  } catch (e) {
    console.error('Error parsing GameMaker file:', e);
  }

  return entries;
}

function traverseGameMakerData(obj: any, path: string, entries: GameScriptEntry[], filename: string): void {
  if (typeof obj === 'string' && obj.trim().length > 2) {
    if (/\.(png|jpg|jpeg|ogg|mp3|wav|yy|json)$/i.test(obj)) return;
    if (/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(obj)) return;

    entries.push({
      id: `gm-${filename}-${entries.length}`,
      original: obj,
      translated: "",
      path: path,
      context: 'GameMaker Data'
    });
  } else if (Array.isArray(obj)) {
    obj.forEach((item, idx) => traverseGameMakerData(item, `${path}[${idx}]`, entries, filename));
  } else if (typeof obj === 'object' && obj !== null) {
    const skipKeys = ['resourceVersion', 'resourceType', 'name', 'path', 'tags', 'resourcePath', 'parentId'];
    
    Object.entries(obj).forEach(([key, value]) => {
      if (!skipKeys.includes(key)) {
        traverseGameMakerData(value, path ? `${path}.${key}` : key, entries, filename);
      }
    });
  }
}

export function applyEnhancedTranslations(
  originalContent: string,
  entries: GameScriptEntry[],
  engine: TranslationProject['engine']
): string {
  switch (engine) {
    case 'tyranobuilder':
      return applyTyranoBuilderTranslations(originalContent, entries);
    case 'visualnovelmaker':
      return applyVNMTranslations(originalContent, entries);
    case 'wolf':
      return applyWolfTranslations(originalContent, entries);
    default:
      return originalContent;
  }
}

function applyTyranoBuilderTranslations(content: string, entries: GameScriptEntry[]): string {
  let result = content;
  
  for (const entry of entries) {
    if (!entry.translated) continue;
    result = result.replace(entry.original, entry.translated);
  }
  
  return result;
}

function applyVNMTranslations(content: string, entries: GameScriptEntry[]): string {
  try {
    const data = JSON.parse(content);
    
    for (const entry of entries) {
      if (!entry.translated) continue;
      
      const pathParts = entry.path.split('.');
      let current: any = data;
      
      for (let i = 0; i < pathParts.length - 1; i++) {
        const part = pathParts[i];
        const arrayMatch = part.match(/(.+)\[(\d+)\]/);
        if (arrayMatch) {
          current = current[arrayMatch[1]][parseInt(arrayMatch[2])];
        } else {
          current = current[part];
        }
        if (!current) break;
      }
      
      const lastPart = pathParts[pathParts.length - 1];
      const arrayMatch = lastPart.match(/(.+)\[(\d+)\]/);
      if (arrayMatch) {
        current[arrayMatch[1]][parseInt(arrayMatch[2])] = entry.translated;
      } else {
        current[lastPart] = entry.translated;
      }
    }
    
    return JSON.stringify(data, null, 2);
  } catch (e) {
    console.error('Error applying VNM translations:', e);
    return content;
  }
}

function applyWolfTranslations(content: string, entries: GameScriptEntry[]): string {
  try {
    const data = JSON.parse(content);
    
    for (const entry of entries) {
      if (!entry.translated) continue;
      
      const pathParts = entry.path.split('.');
      let current: any = data;
      
      for (let i = 0; i < pathParts.length - 1; i++) {
        const part = pathParts[i];
        const arrayMatch = part.match(/(.+)\[(\d+)\]/);
        if (arrayMatch) {
          current = current[arrayMatch[1]][parseInt(arrayMatch[2])];
        } else {
          current = current[part];
        }
        if (!current) break;
      }
      
      const lastPart = pathParts[pathParts.length - 1];
      const arrayMatch = lastPart.match(/(.+)\[(\d+)\]/);
      if (arrayMatch) {
        current[arrayMatch[1]][parseInt(arrayMatch[2])] = entry.translated;
      } else {
        current[lastPart] = entry.translated;
      }
    }
    
    return JSON.stringify(data, null, 2);
  } catch (e) {
    console.error('Error applying Wolf translations:', e);
    return content;
  }
}
