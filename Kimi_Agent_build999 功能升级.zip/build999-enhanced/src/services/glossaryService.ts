// Glossary/Terminology Manager Service
// Ensures consistent translation of specific terms (character names, items, places, etc.)

export interface GlossaryEntry {
  id: string;
  term: string;
  translation: string;
  context?: string;
  category: 'character' | 'item' | 'location' | 'skill' | 'term' | 'other';
  notes?: string;
  createdAt: number;
  updatedAt: number;
}

export interface GlossaryCategory {
  id: string;
  name: string;
  description: string;
  color: string;
}

const GLOSSARY_KEY = 'game_glossary_v1';
const GLOSSARY_ENABLED_KEY = 'game_glossary_enabled';

export const GLOSSARY_CATEGORIES: GlossaryCategory[] = [
  { id: 'character', name: 'Characters', description: 'Character names and titles', color: '#EF4444' },
  { id: 'item', name: 'Items', description: 'Items, weapons, armor, consumables', color: '#F59E0B' },
  { id: 'location', name: 'Locations', description: 'Places, towns, dungeons, areas', color: '#10B981' },
  { id: 'skill', name: 'Skills', description: 'Skills, spells, abilities', color: '#3B82F6' },
  { id: 'term', name: 'Terms', description: 'Game-specific terminology', color: '#8B5CF6' },
  { id: 'other', name: 'Other', description: 'Miscellaneous entries', color: '#6B7280' },
];

// Get all glossary entries
export function getGlossary(): GlossaryEntry[] {
  try {
    const stored = localStorage.getItem(GLOSSARY_KEY);
    if (!stored) return [];
    return JSON.parse(stored);
  } catch (e) {
    console.error('Error loading glossary:', e);
    return [];
  }
}

// Save glossary entries
export function saveGlossary(entries: GlossaryEntry[]): void {
  try {
    localStorage.setItem(GLOSSARY_KEY, JSON.stringify(entries));
  } catch (e) {
    console.error('Error saving glossary:', e);
  }
}

// Add or update glossary entry
export function saveGlossaryEntry(entry: Omit<GlossaryEntry, 'id' | 'createdAt' | 'updatedAt'> & { id?: string }): GlossaryEntry {
  const entries = getGlossary();
  const now = Date.now();
  
  if (entry.id) {
    // Update existing
    const index = entries.findIndex(e => e.id === entry.id);
    if (index !== -1) {
      entries[index] = { 
        ...entries[index], 
        ...entry, 
        updatedAt: now 
      };
      saveGlossary(entries);
      return entries[index];
    }
  }
  
  // Add new
  const newEntry: GlossaryEntry = {
    ...entry,
    id: Math.random().toString(36).substr(2, 9),
    createdAt: now,
    updatedAt: now,
  };
  entries.push(newEntry);
  saveGlossary(entries);
  return newEntry;
}

// Delete glossary entry
export function deleteGlossaryEntry(id: string): boolean {
  const entries = getGlossary();
  const filtered = entries.filter(e => e.id !== id);
  if (filtered.length !== entries.length) {
    saveGlossary(filtered);
    return true;
  }
  return false;
}

// Find glossary entry by term
export function findGlossaryEntry(term: string): GlossaryEntry | null {
  const entries = getGlossary();
  const lowerTerm = term.toLowerCase().trim();
  return entries.find(e => e.term.toLowerCase() === lowerTerm) || null;
}

// Search glossary entries
export function searchGlossary(query: string, category?: string): GlossaryEntry[] {
  const entries = getGlossary();
  const lowerQuery = query.toLowerCase();
  
  return entries.filter(entry => {
    const matchesQuery = 
      entry.term.toLowerCase().includes(lowerQuery) ||
      entry.translation.toLowerCase().includes(lowerQuery) ||
      entry.context?.toLowerCase().includes(lowerQuery) ||
      entry.notes?.toLowerCase().includes(lowerQuery);
    
    const matchesCategory = !category || entry.category === category;
    
    return matchesQuery && matchesCategory;
  });
}

// Apply glossary to text
export function applyGlossary(text: string): { text: string; replacements: { original: string; replacement: string; position: number }[] } {
  const entries = getGlossary();
  if (!isGlossaryEnabled() || entries.length === 0) {
    return { text, replacements: [] };
  }
  
  let result = text;
  const replacements: { original: string; replacement: string; position: number }[] = [];
  
  // Sort by length (longest first) to avoid partial replacements
  const sortedEntries = [...entries].sort((a, b) => b.term.length - a.term.length);
  
  for (const entry of sortedEntries) {
    const regex = new RegExp(`\\b${escapeRegex(entry.term)}\\b`, 'gi');
    let match;
    while ((match = regex.exec(result)) !== null) {
      replacements.push({
        original: match[0],
        replacement: entry.translation,
        position: match.index,
      });
    }
    result = result.replace(regex, entry.translation);
  }
  
  return { text: result, replacements };
}

// Apply glossary to multiple texts
export function applyGlossaryBatch(texts: string[]): { texts: string; totalReplacements: number } {
  let totalReplacements = 0;
  const processedTexts = texts.map(text => {
    const result = applyGlossary(text);
    totalReplacements += result.replacements.length;
    return result.text;
  });
  return { texts: processedTexts.join('\n'), totalReplacements };
}

// Check if text contains glossary terms
export function containsGlossaryTerms(text: string): { found: boolean; terms: GlossaryEntry[] } {
  const entries = getGlossary();
  const foundTerms: GlossaryEntry[] = [];
  
  for (const entry of entries) {
    const regex = new RegExp(`\\b${escapeRegex(entry.term)}\\b`, 'gi');
    if (regex.test(text)) {
      foundTerms.push(entry);
    }
  }
  
  return { found: foundTerms.length > 0, terms: foundTerms };
}

// Import glossary from JSON
export function importGlossary(jsonString: string): boolean {
  try {
    const data = JSON.parse(jsonString);
    if (Array.isArray(data)) {
      const entries: GlossaryEntry[] = data.map(item => ({
        ...item,
        id: item.id || Math.random().toString(36).substr(2, 9),
        createdAt: item.createdAt || Date.now(),
        updatedAt: item.updatedAt || Date.now(),
      }));
      saveGlossary(entries);
      return true;
    }
    return false;
  } catch (e) {
    console.error('Error importing glossary:', e);
    return false;
  }
}

// Export glossary to JSON
export function exportGlossary(): string {
  return JSON.stringify(getGlossary(), null, 2);
}

// Get glossary statistics
export function getGlossaryStats(): {
  total: number;
  byCategory: Record<string, number>;
} {
  const entries = getGlossary();
  const byCategory: Record<string, number> = {};
  
  entries.forEach(entry => {
    byCategory[entry.category] = (byCategory[entry.category] || 0) + 1;
  });
  
  return { total: entries.length, byCategory };
}

// Enable/disable glossary
export function setGlossaryEnabled(enabled: boolean): void {
  localStorage.setItem(GLOSSARY_ENABLED_KEY, JSON.stringify(enabled));
}

export function isGlossaryEnabled(): boolean {
  const stored = localStorage.getItem(GLOSSARY_ENABLED_KEY);
  return stored ? JSON.parse(stored) : true;
}

// Clear all glossary entries
export function clearGlossary(): void {
  localStorage.removeItem(GLOSSARY_KEY);
}

// Helper function to escape special regex characters
function escapeRegex(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

// Predefined glossary templates for common game types
export const glossaryTemplates: Record<string, Partial<GlossaryEntry>[]> = {
  'fantasy_rpg': [
    { term: 'HP', translation: 'HP', category: 'term', notes: 'Health Points' },
    { term: 'MP', translation: 'MP', category: 'term', notes: 'Magic Points' },
    { term: 'EXP', translation: 'EXP', category: 'term', notes: 'Experience Points' },
    { term: 'LV', translation: 'Level', category: 'term' },
    { term: 'ATK', translation: 'Attack', category: 'term' },
    { term: 'DEF', translation: 'Defense', category: 'term' },
    { term: 'SPD', translation: 'Speed', category: 'term' },
    { term: 'INT', translation: 'Intelligence', category: 'term' },
    { term: 'STR', translation: 'Strength', category: 'term' },
    { term: 'AGI', translation: 'Agility', category: 'term' },
  ],
  'visual_novel': [
    { term: 'Prologue', translation: 'Prolog', category: 'term' },
    { term: 'Chapter', translation: 'Bab', category: 'term' },
    { term: 'End', translation: 'Akhir', category: 'term' },
    { term: 'True End', translation: 'Akhir Sejati', category: 'term' },
    { term: 'Bad End', translation: 'Akhir Buruk', category: 'term' },
    { term: 'Good End', translation: 'Akhir Baik', category: 'term' },
    { term: 'Normal End', translation: 'Akhir Normal', category: 'term' },
  ],
  'jrpg': [
    { term: 'Inn', translation: 'Penginapan', category: 'location' },
    { term: 'Shop', translation: 'Toko', category: 'location' },
    { term: 'Weapon Shop', translation: 'Toko Senjata', category: 'location' },
    { term: 'Item Shop', translation: 'Toko Barang', category: 'location' },
    { term: 'Guild', translation: 'Guild', category: 'location' },
    { term: 'Tavern', translation: 'Kedai', category: 'location' },
  ],
};

// Apply a template to create initial glossary
export function applyGlossaryTemplate(templateName: string): number {
  const template = glossaryTemplates[templateName];
  if (!template) return 0;
  
  const now = Date.now();
  const newEntries: GlossaryEntry[] = template.map(item => ({
    ...item,
    id: Math.random().toString(36).substr(2, 9),
    createdAt: now,
    updatedAt: now,
  })) as GlossaryEntry[];
  
  const existing = getGlossary();
  const merged = [...existing, ...newEntries];
  saveGlossary(merged);
  
  return newEntries.length;
}
