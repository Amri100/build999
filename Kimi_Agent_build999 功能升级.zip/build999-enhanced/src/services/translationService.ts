import type { TranslationResult, TranslationProvider } from '@/types';

const BATCH_DELAY = 300; // ms between batch requests to avoid rate limiting

export async function translateGameText(
  texts: string[],
  targetLang: string,
  engine: string,
  provider: TranslationProvider = 'mymemory',
  context?: string
): Promise<TranslationResult[]> {
  if (!texts.length) return [];

  try {
    switch (provider) {
      case 'google':
        return await translateWithGoogle(texts, targetLang);
      case 'bing':
        return await translateWithBing(texts, targetLang);
      case 'mymemory':
        return await translateWithMyMemory(texts, targetLang);
      case 'lingva':
        return await translateWithLingva(texts, targetLang);
      case 'gemini':
        return await translateWithGemini(texts, targetLang, engine, context);
      default:
        return await translateWithMyMemory(texts, targetLang);
    }
  } catch (error) {
    console.error(`Translation error with ${provider}:`, error);
    // Fallback to MyMemory if other providers fail
    if (provider !== 'mymemory') {
      console.log('Falling back to MyMemory...');
      return await translateWithMyMemory(texts, targetLang);
    }
    return texts.map(t => ({ original: t, translated: t }));
  }
}

async function translateWithGoogle(
  texts: string[],
  targetLang: string
): Promise<TranslationResult[]> {
  const results: TranslationResult[] = [];
  
  for (const text of texts) {
    try {
      // Using a free Google Translate API endpoint
      const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${getLangCode(targetLang)}&dt=t&q=${encodeURIComponent(text)}`;
      const response = await fetch(url);
      
      if (!response.ok) throw new Error('Google Translate API error');
      
      const data = await response.json();
      const translated = data[0]?.map((item: any) => item[0]).join('') || text;
      
      results.push({ original: text, translated });
      await delay(BATCH_DELAY);
    } catch (e) {
      console.error('Google translate error:', e);
      results.push({ original: text, translated: text });
    }
  }
  
  return results;
}

async function translateWithBing(
  texts: string[],
  targetLang: string
): Promise<TranslationResult[]> {
  const results: TranslationResult[] = [];
  
  for (const text of texts) {
    try {
      const url = `https://api.bing.microsoft.com/v7.0/translate?to=${getLangCode(targetLang)}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Ocp-Apim-Subscription-Key': '', // Would need actual key
        },
        body: JSON.stringify([{ Text: text }]),
      });
      
      if (!response.ok) throw new Error('Bing Translate API error');
      
      const data = await response.json();
      const translated = data[0]?.translations[0]?.text || text;
      
      results.push({ original: text, translated });
      await delay(BATCH_DELAY);
    } catch (e) {
      console.error('Bing translate error:', e);
      results.push({ original: text, translated: text });
    }
  }
  
  return results;
}

async function translateWithMyMemory(
  texts: string[],
  targetLang: string
): Promise<TranslationResult[]> {
  const results: TranslationResult[] = [];
  const langCode = getLangCode(targetLang);
  
  for (const text of texts) {
    try {
      // MyMemory API - free up to 5000 chars/day
      const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=auto|${langCode}`;
      const response = await fetch(url);
      
      if (!response.ok) throw new Error('MyMemory API error');
      
      const data = await response.json();
      const translated = data.responseData?.translatedText || text;
      
      results.push({ original: text, translated });
      await delay(100); // MyMemory has stricter rate limits
    } catch (e) {
      console.error('MyMemory translate error:', e);
      results.push({ original: text, translated: text });
    }
  }
  
  return results;
}

async function translateWithLingva(
  texts: string[],
  targetLang: string
): Promise<TranslationResult[]> {
  const results: TranslationResult[] = [];
  const langCode = getLangCode(targetLang);
  
  for (const text of texts) {
    try {
      // Lingva Translate - free alternative to Google Translate
      const url = `https://lingva.ml/api/v1/auto/${langCode}/${encodeURIComponent(text)}`;
      const response = await fetch(url);
      
      if (!response.ok) throw new Error('Lingva API error');
      
      const data = await response.json();
      const translated = data.translation || text;
      
      results.push({ original: text, translated });
      await delay(BATCH_DELAY);
    } catch (e) {
      console.error('Lingva translate error:', e);
      results.push({ original: text, translated: text });
    }
  }
  
  return results;
}

async function translateWithGemini(
  texts: string[],
  targetLang: string,
  _engine: string,
  _context?: string
): Promise<TranslationResult[]> {
  // Gemini requires API key - we'll use a mock implementation
  // In production, this would call a backend API
  console.warn('Gemini translation requires API key. Falling back to MyMemory.');
  return await translateWithMyMemory(texts, targetLang);
}

function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function getLangCode(lang: string): string {
  const langMap: Record<string, string> = {
    'Indonesian': 'id',
    'English': 'en',
    'Spanish': 'es',
    'French': 'fr',
    'German': 'de',
    'Italian': 'it',
    'Portuguese': 'pt',
    'Russian': 'ru',
    'Japanese': 'ja',
    'Korean': 'ko',
    'Chinese': 'zh',
    'Arabic': 'ar',
    'Dutch': 'nl',
    'Polish': 'pl',
    'Turkish': 'tr',
    'Vietnamese': 'vi',
    'Thai': 'th',
    'Auto Detect': 'auto',
  };
  
  return langMap[lang] || 'auto';
}

export function detectLanguage(text: string): string {
  // Simple language detection based on character patterns
  if (/[\u3040-\u309F\u30A0-\u30FF]/.test(text)) return 'Japanese';
  if (/[\u4E00-\u9FFF]/.test(text)) return 'Chinese';
  if (/[\uAC00-\uD7AF]/.test(text)) return 'Korean';
  if (/[\u0400-\u04FF]/.test(text)) return 'Russian';
  if (/[\u0600-\u06FF]/.test(text)) return 'Arabic';
  if (/[àáâãäåæçèéêëìíîïðñòóôõöøùúûüýþÿ]/.test(text)) return 'French';
  return 'English';
}
