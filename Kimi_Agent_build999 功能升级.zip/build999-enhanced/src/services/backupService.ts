import type { TranslationProject, BackupData, UserPreferences } from '@/types';
import { getTM, importTM } from './tmService';
import { getGlossary, importGlossary } from './glossaryService';
import { getHistory } from './historyService';

const BACKUP_KEY = 'game_translation_backup_v1';
const BACKUP_TIMESTAMP_KEY = 'game_translation_backup_timestamp';
const AUTO_BACKUP_INTERVAL = 5 * 60 * 1000;

export function createBackup(): BackupData {
  const projects: TranslationProject[] = [];
  
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key?.startsWith('gs_project_')) {
      try {
        const project = JSON.parse(localStorage.getItem(key) || '');
        projects.push(project);
      } catch (e) {
        console.error('Error parsing project:', e);
      }
    }
  }

  const backup: BackupData = {
    projects,
    tm: getTM(),
    glossary: getGlossary(),
    history: getHistory(),
    preferences: getUserPreferences(),
    exportedAt: Date.now(),
    version: '4.0.0',
  };

  try {
    localStorage.setItem(BACKUP_KEY, JSON.stringify(backup));
    localStorage.setItem(BACKUP_TIMESTAMP_KEY, String(Date.now()));
  } catch (e) {
    console.error('Error saving backup:', e);
    if (e instanceof DOMException && e.name === 'QuotaExceededError') {
      cleanupOldBackups();
    }
  }

  return backup;
}

export function restoreBackup(backupData: BackupData): boolean {
  try {
    for (const project of backupData.projects) {
      localStorage.setItem(`gs_project_${project.id}`, JSON.stringify(project));
    }

    if (backupData.tm) {
      importTM(JSON.stringify(backupData.tm));
    }

    if (backupData.glossary) {
      importGlossary(JSON.stringify(backupData.glossary));
    }

    if (backupData.preferences) {
      saveUserPreferences(backupData.preferences);
    }

    return true;
  } catch (e) {
    console.error('Error restoring backup:', e);
    return false;
  }
}

export function exportBackupToFile(): void {
  const backup = createBackup();
  const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  
  const a = document.createElement('a');
  a.href = url;
  a.download = `game_translation_backup_${new Date().toISOString().split('T')[0]}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export async function importBackupFromFile(file: File): Promise<{ success: boolean; message: string }> {
  try {
    const content = await file.text();
    const backup: BackupData = JSON.parse(content);

    if (!backup.version || !Array.isArray(backup.projects)) {
      return { success: false, message: 'Invalid backup file format' };
    }

    const projectCount = backup.projects.length;
    const confirmRestore = confirm(
      `Restore backup from ${new Date(backup.exportedAt).toLocaleString()}?\n\n` +
      `This will restore ${projectCount} project(s) and overwrite existing data.`
    );

    if (!confirmRestore) {
      return { success: false, message: 'Restore cancelled' };
    }

    const success = restoreBackup(backup);
    if (success) {
      return { success: true, message: `Successfully restored ${projectCount} project(s)` };
    } else {
      return { success: false, message: 'Failed to restore backup' };
    }
  } catch (e) {
    console.error('Error importing backup:', e);
    return { success: false, message: 'Error reading backup file' };
  }
}

export function getLastBackupInfo(): { timestamp: number | null; age: number } {
  const timestamp = localStorage.getItem(BACKUP_TIMESTAMP_KEY);
  if (!timestamp) {
    return { timestamp: null, age: Infinity };
  }
  
  const ts = parseInt(timestamp);
  const age = Date.now() - ts;
  return { timestamp: ts, age };
}

let autoBackupInterval: number | null = null;

export function startAutoBackup(): void {
  stopAutoBackup();
  autoBackupInterval = window.setInterval(() => {
    createBackup();
    console.log('Auto backup created at', new Date().toLocaleString());
  }, AUTO_BACKUP_INTERVAL);
}

export function stopAutoBackup(): void {
  if (autoBackupInterval) {
    clearInterval(autoBackupInterval);
    autoBackupInterval = null;
  }
}

export function getUserPreferences(): UserPreferences {
  const stored = localStorage.getItem('user_preferences_v1');
  if (stored) {
    return JSON.parse(stored);
  }
  
  return {
    theme: 'dark',
    language: 'en',
    fontSize: 14,
    sidebarCollapsed: false,
    showPreview: true,
    shortcuts: {},
    recentProjects: [],
  };
}

export function saveUserPreferences(prefs: UserPreferences): void {
  localStorage.setItem('user_preferences_v1', JSON.stringify(prefs));
}

export function addRecentProject(projectId: string): void {
  const prefs = getUserPreferences();
  prefs.recentProjects = [projectId, ...prefs.recentProjects.filter(id => id !== projectId)].slice(0, 10);
  saveUserPreferences(prefs);
}

function cleanupOldBackups(): void {
  const keysToRemove: string[] = [];
  
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key?.startsWith('gs_project_')) {
      try {
        const project = JSON.parse(localStorage.getItem(key) || '');
        if (project.updatedAt && Date.now() - project.updatedAt > 30 * 24 * 60 * 60 * 1000) {
          keysToRemove.push(key);
        }
      } catch (e) {
        keysToRemove.push(key);
      }
    }
  }
  
  for (const key of keysToRemove) {
    localStorage.removeItem(key);
  }
}

export function getBackupStats(): {
  totalProjects: number;
  totalEntries: number;
  tmEntries: number;
  glossaryEntries: number;
  lastBackup: number | null;
} {
  const backup = localStorage.getItem(BACKUP_KEY);
  const backupData: BackupData | null = backup ? JSON.parse(backup) : null;
  
  const projects: TranslationProject[] = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key?.startsWith('gs_project_')) {
      try {
        const project = JSON.parse(localStorage.getItem(key) || '');
        projects.push(project);
      } catch (e) {}
    }
  }

  return {
    totalProjects: projects.length,
    totalEntries: projects.reduce((sum, p) => sum + (p.entries?.length || 0), 0),
    tmEntries: Object.keys(backupData?.tm || getTM()).length,
    glossaryEntries: (backupData?.glossary || getGlossary()).length,
    lastBackup: backupData?.exportedAt || null,
  };
}
