// Translation History / Version Control Service
// Tracks all changes to translations for undo/redo and audit purposes

export interface HistoryEntry {
  id: string;
  timestamp: number;
  type: 'translate' | 'edit' | 'bulk' | 'import' | 'glossary' | 'find_replace';
  description: string;
  changes: {
    entryId: string;
    original: string;
    previous: string;
    current: string;
  }[];
  user?: string;
}

const HISTORY_KEY = 'translation_history_v1';
const MAX_HISTORY_ENTRIES = 50;

// Get all history entries
export function getHistory(): HistoryEntry[] {
  try {
    const stored = localStorage.getItem(HISTORY_KEY);
    if (!stored) return [];
    return JSON.parse(stored);
  } catch (e) {
    console.error('Error loading history:', e);
    return [];
  }
}

// Save history entries
function saveHistory(entries: HistoryEntry[]): void {
  try {
    // Keep only the most recent entries
    const trimmed = entries.slice(-MAX_HISTORY_ENTRIES);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(trimmed));
  } catch (e) {
    console.error('Error saving history:', e);
  }
}

// Add a new history entry
export function addHistoryEntry(
  type: HistoryEntry['type'],
  description: string,
  changes: HistoryEntry['changes'],
  user?: string
): void {
  const entries = getHistory();
  const newEntry: HistoryEntry = {
    id: Math.random().toString(36).substr(2, 9),
    timestamp: Date.now(),
    type,
    description,
    changes,
    user: user || 'Anonymous',
  };
  entries.push(newEntry);
  saveHistory(entries);
}

// Undo the last change (returns the changes to revert)
export function undoLastChange(): HistoryEntry | null {
  const entries = getHistory();
  if (entries.length === 0) return null;
  
  const lastEntry = entries[entries.length - 1];
  // Remove from history
  entries.pop();
  saveHistory(entries);
  
  return lastEntry;
}

// Get history for a specific entry
export function getHistoryForEntry(entryId: string): HistoryEntry[] {
  const entries = getHistory();
  return entries.filter(h => h.changes.some(c => c.entryId === entryId));
}

// Clear all history
export function clearHistory(): void {
  localStorage.removeItem(HISTORY_KEY);
}

// Export history
export function exportHistory(): string {
  return JSON.stringify(getHistory(), null, 2);
}

// Get statistics from history
export function getHistoryStats(): {
  totalEdits: number;
  totalTranslations: number;
  totalBulkOps: number;
  lastActive: number | null;
} {
  const entries = getHistory();
  return {
    totalEdits: entries.filter(e => e.type === 'edit').length,
    totalTranslations: entries.filter(e => e.type === 'translate').length,
    totalBulkOps: entries.filter(e => e.type === 'bulk').length,
    lastActive: entries.length > 0 ? entries[entries.length - 1].timestamp : null,
  };
}

// Format timestamp for display
export function formatHistoryTime(timestamp: number): string {
  const date = new Date(timestamp);
  const now = new Date();
  const diff = now.getTime() - date.getTime();
  
  // Less than 1 minute
  if (diff < 60000) {
    return 'Just now';
  }
  // Less than 1 hour
  if (diff < 3600000) {
    const mins = Math.floor(diff / 60000);
    return `${mins} minute${mins > 1 ? 's' : ''} ago`;
  }
  // Less than 24 hours
  if (diff < 86400000) {
    const hours = Math.floor(diff / 3600000);
    return `${hours} hour${hours > 1 ? 's' : ''} ago`;
  }
  
  return date.toLocaleDateString();
}
