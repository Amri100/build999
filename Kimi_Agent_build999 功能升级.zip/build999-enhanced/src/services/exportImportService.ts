import type { TranslationProject, GameScriptEntry, ExportConfig } from '@/types';
import JSZip from 'jszip';

export async function exportProject(project: TranslationProject, config: ExportConfig): Promise<void> {
  switch (config.format) {
    case 'zip':
      await exportAsZip(project, config);
      break;
    case 'json':
      await exportAsJSON(project, config);
      break;
    case 'csv':
      await exportAsCSV(project, config);
      break;
    case 'xlsx':
      await exportAsXLSX(project, config);
      break;
    case 'po':
      await exportAsPO(project, config);
      break;
    case 'xliff':
      await exportAsXLIFF(project, config);
      break;
    case 'yaml':
      await exportAsYAML(project, config);
      break;
    default:
      throw new Error(`Unsupported export format: ${config.format}`);
  }
}

async function exportAsZip(project: TranslationProject, config: ExportConfig): Promise<void> {
  const zip = new JSZip();
  const entries = filterEntries(project.entries, config);

  const entriesByFile = new Map<string, GameScriptEntry[]>();
  
  for (const entry of entries) {
    const fileMatch = entry.id.match(/^(?:map|choice|plugin|common|actor|item|system|troop|ks|rpy|json|csv|srt)-(.+?)-\d/);
    const filename = fileMatch ? fileMatch[1] : 'unknown.txt';
    
    if (!entriesByFile.has(filename)) {
      entriesByFile.set(filename, []);
    }
    entriesByFile.get(filename)!.push(entry);
  }

  for (const [filename, fileEntries] of entriesByFile) {
    const originalFile = project.files.find(f => f.name === filename);
    if (!originalFile) continue;

    let content = originalFile.content;

    for (const entry of fileEntries) {
      if (entry.translated) {
        content = content.replace(entry.original, entry.translated);
      }
    }

    zip.file(filename, content);
  }

  const metadata = {
    name: project.name,
    engine: project.engine,
    sourceLang: project.sourceLang,
    targetLang: project.targetLang,
    exportedAt: Date.now(),
    totalEntries: entries.length,
    translatedEntries: entries.filter(e => e.translated).length,
  };
  zip.file('_translation_metadata.json', JSON.stringify(metadata, null, 2));

  const blob = await zip.generateAsync({ type: 'blob' });
  downloadFile(blob, `${project.name}_translated.zip`);
}

async function exportAsJSON(project: TranslationProject, config: ExportConfig): Promise<void> {
  const entries = filterEntries(project.entries, config);
  
  const data = {
    project: {
      name: project.name,
      engine: project.engine,
      sourceLang: project.sourceLang,
      targetLang: project.targetLang,
    },
    entries: entries.map(e => ({
      id: e.id,
      original: e.original,
      translation: e.translated,
      context: config.includeContext ? e.context : undefined,
      notes: config.includeNotes ? e.notes : undefined,
      reviewed: e.reviewed,
      tags: e.tags,
    })),
  };

  const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
  downloadFile(blob, `${project.name}_translations.json`);
}

async function exportAsCSV(project: TranslationProject, config: ExportConfig): Promise<void> {
  const entries = filterEntries(project.entries, config);
  
  let csv = 'ID,Original,Translation';
  if (config.includeContext) csv += ',Context';
  if (config.includeNotes) csv += ',Notes';
  csv += ',Reviewed,Tags\n';

  for (const entry of entries) {
    const row = [
      escapeCSV(entry.id),
      escapeCSV(entry.original),
      escapeCSV(entry.translated),
    ];
    if (config.includeContext) row.push(escapeCSV(entry.context || ''));
    if (config.includeNotes) row.push(escapeCSV(entry.notes || ''));
    row.push(entry.reviewed ? 'Yes' : 'No');
    row.push(escapeCSV((entry.tags || []).join('; ')));
    
    csv += row.join(',') + '\n';
  }

  const blob = new Blob(['\ufeff' + csv], { type: 'text/csv;charset=utf-8;' });
  downloadFile(blob, `${project.name}_translations.csv`);
}

async function exportAsXLSX(project: TranslationProject, config: ExportConfig): Promise<void> {
  const entries = filterEntries(project.entries, config);
  
  let tsv = 'ID\tOriginal\tTranslation';
  if (config.includeContext) tsv += '\tContext';
  if (config.includeNotes) tsv += '\tNotes';
  tsv += '\tReviewed\tTags\n';

  for (const entry of entries) {
    const row = [
      entry.id,
      entry.original,
      entry.translated,
    ];
    if (config.includeContext) row.push(entry.context || '');
    if (config.includeNotes) row.push(entry.notes || '');
    row.push(entry.reviewed ? 'Yes' : 'No');
    row.push((entry.tags || []).join('; '));
    
    tsv += row.join('\t') + '\n';
  }

  const blob = new Blob([tsv], { type: 'application/vnd.ms-excel' });
  downloadFile(blob, `${project.name}_translations.xls`);
}

async function exportAsPO(project: TranslationProject, config: ExportConfig): Promise<void> {
  const entries = filterEntries(project.entries, config);
  
  let po = `# ${project.name} Translation\n`;
  po += `# Source Language: ${project.sourceLang || 'Unknown'}\n`;
  po += `# Target Language: ${project.targetLang || 'Unknown'}\n`;
  po += `# Exported: ${new Date().toISOString()}\n`;
  po += `msgid ""\nmsgstr ""\n"Content-Type: text/plain; charset=UTF-8\\n"\n\n`;

  for (const entry of entries) {
    if (config.includeContext && entry.context) {
      po += `#: ${entry.context}\n`;
    }
    if (config.includeNotes && entry.notes) {
      po += `#. ${entry.notes.replace(/\n/g, '\n#. ')}\n`;
    }
    if (entry.tags && entry.tags.length > 0) {
      po += `#, ${entry.tags.join(', ')}\n`;
    }
    po += `msgid "${escapePO(entry.original)}"\n`;
    po += `msgstr "${escapePO(entry.translated)}"\n\n`;
  }

  const blob = new Blob([po], { type: 'text/x-gettext-translation' });
  downloadFile(blob, `${project.name}.po`);
}

async function exportAsXLIFF(project: TranslationProject, config: ExportConfig): Promise<void> {
  const entries = filterEntries(project.entries, config);
  
  let xliff = `<?xml version="1.0" encoding="UTF-8"?>\n`;
  xliff += `<xliff version="1.2" xmlns="urn:oasis:names:tc:xliff:document:1.2">\n`;
  xliff += `  <file original="${project.name}" source-language="${project.sourceLang || 'en'}" target-language="${project.targetLang || 'id'}" datatype="plaintext">\n`;
  xliff += `    <body>\n`;

  for (const entry of entries) {
    xliff += `      <trans-unit id="${escapeXML(entry.id)}">\n`;
    xliff += `        <source>${escapeXML(entry.original)}</source>\n`;
    xliff += `        <target>${escapeXML(entry.translated)}</target>\n`;
    if (config.includeContext && entry.context) {
      xliff += `        <context-group purpose="location">\n`;
      xliff += `          <context context-type="sourcefile">${escapeXML(entry.context)}</context>\n`;
      xliff += `        </context-group>\n`;
    }
    if (entry.reviewed) {
      xliff += `        <target state="final"/>\n`;
    } else if (entry.translated) {
      xliff += `        <target state="translated"/>\n`;
    } else {
      xliff += `        <target state="initial"/>\n`;
    }
    xliff += `      </trans-unit>\n`;
  }

  xliff += `    </body>\n`;
  xliff += `  </file>\n`;
  xliff += `</xliff>`;

  const blob = new Blob([xliff], { type: 'application/xliff+xml' });
  downloadFile(blob, `${project.name}.xlf`);
}

async function exportAsYAML(project: TranslationProject, config: ExportConfig): Promise<void> {
  const entries = filterEntries(project.entries, config);
  
  const data: Record<string, any> = {
    project: {
      name: project.name,
      engine: project.engine,
      source_language: project.sourceLang,
      target_language: project.targetLang,
    },
    translations: {},
  };

  for (const entry of entries) {
    data.translations[entry.id] = {
      original: entry.original,
      translation: entry.translated,
    };
    if (config.includeContext) data.translations[entry.id].context = entry.context;
    if (config.includeNotes) data.translations[entry.id].notes = entry.notes;
    if (entry.reviewed) data.translations[entry.id].reviewed = true;
  }

  const yaml = objectToYAML(data);
  const blob = new Blob([yaml], { type: 'application/x-yaml' });
  downloadFile(blob, `${project.name}.yml`);
}

function filterEntries(entries: GameScriptEntry[], config: ExportConfig): GameScriptEntry[] {
  return entries.filter(e => {
    if (config.onlyTranslated && !e.translated) return false;
    if (config.onlyReviewed && !e.reviewed) return false;
    return true;
  });
}

function downloadFile(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

function escapeCSV(value: string): string {
  if (!value) return '';
  if (value.includes(',') || value.includes('"') || value.includes('\n')) {
    return '"' + value.replace(/"/g, '""') + '"';
  }
  return value;
}

function escapePO(value: string): string {
  return value
    .replace(/\\/g, '\\\\')
    .replace(/"/g, '\\"')
    .replace(/\n/g, '\\n');
}

function escapeXML(value: string): string {
  return value
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function objectToYAML(obj: any, indent: number = 0): string {
  let yaml = '';
  const spaces = '  '.repeat(indent);

  for (const [key, value] of Object.entries(obj)) {
    if (value === undefined || value === null) continue;
    
    if (typeof value === 'object' && !Array.isArray(value)) {
      yaml += `${spaces}${key}:\n`;
      yaml += objectToYAML(value, indent + 1);
    } else if (Array.isArray(value)) {
      yaml += `${spaces}${key}:\n`;
      for (const item of value) {
        yaml += `${spaces}- ${item}\n`;
      }
    } else {
      const strValue = String(value);
      if (strValue.includes('\n') || strValue.includes(':') || strValue.includes('#')) {
        yaml += `${spaces}${key}: |\n${spaces}  ${strValue.replace(/\n/g, '\n' + spaces + '  ')}\n`;
      } else {
        yaml += `${spaces}${key}: ${strValue}\n`;
      }
    }
  }

  return yaml;
}
