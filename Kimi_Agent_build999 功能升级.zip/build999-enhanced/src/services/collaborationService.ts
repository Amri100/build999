import type { Collaborator, Comment } from '@/types';

const COLLABORATORS_KEY = 'project_collaborators';
const ACTIVITY_KEY = 'collaboration_activity';
const COMMENTS_KEY = 'entry_comments';

export function generateUserColor(): string {
  const colors = [
    '#EF4444', '#F59E0B', '#10B981', '#3B82F6', '#8B5CF6',
    '#EC4899', '#14B8A6', '#F97316', '#6366F1', '#84CC16',
  ];
  return colors[Math.floor(Math.random() * colors.length)];
}

export function getCurrentUser(): Collaborator {
  const stored = localStorage.getItem('current_user');
  if (stored) {
    return JSON.parse(stored);
  }

  const user: Collaborator = {
    id: Math.random().toString(36).substr(2, 9),
    name: `User ${Math.floor(Math.random() * 1000)}`,
    role: 'owner',
    joinedAt: Date.now(),
    color: generateUserColor(),
  };

  localStorage.setItem('current_user', JSON.stringify(user));
  return user;
}

export function updateCurrentUser(updates: Partial<Collaborator>): void {
  const user = getCurrentUser();
  const updated = { ...user, ...updates };
  localStorage.setItem('current_user', JSON.stringify(updated));
}

export function getCollaborators(): Collaborator[] {
  const stored = localStorage.getItem(COLLABORATORS_KEY);
  if (stored) {
    return JSON.parse(stored);
  }
  return [getCurrentUser()];
}

export function addCollaborator(collaborator: Omit<Collaborator, 'id' | 'joinedAt'>): Collaborator {
  const collaborators = getCollaborators();
  const newCollaborator: Collaborator = {
    ...collaborator,
    id: Math.random().toString(36).substr(2, 9),
    joinedAt: Date.now(),
  };

  collaborators.push(newCollaborator);
  localStorage.setItem(COLLABORATORS_KEY, JSON.stringify(collaborators));
  return newCollaborator;
}

export function removeCollaborator(userId: string): boolean {
  const collaborators = getCollaborators();
  const filtered = collaborators.filter(c => c.id !== userId);
  
  if (filtered.length < collaborators.length) {
    localStorage.setItem(COLLABORATORS_KEY, JSON.stringify(filtered));
    return true;
  }
  return false;
}

export function updateCollaboratorRole(userId: string, role: Collaborator['role']): boolean {
  const collaborators = getCollaborators();
  const index = collaborators.findIndex(c => c.id === userId);
  
  if (index !== -1) {
    collaborators[index].role = role;
    localStorage.setItem(COLLABORATORS_KEY, JSON.stringify(collaborators));
    return true;
  }
  return false;
}

export interface ActivityEvent {
  id: string;
  userId: string;
  userName: string;
  userColor: string;
  type: 'edit' | 'translate' | 'review' | 'comment' | 'join' | 'leave';
  entryId?: string;
  description: string;
  timestamp: number;
}

export function addActivity(event: Omit<ActivityEvent, 'id' | 'timestamp'>): void {
  const activities = getActivities();
  const newActivity: ActivityEvent = {
    ...event,
    id: Math.random().toString(36).substr(2, 9),
    timestamp: Date.now(),
  };

  activities.push(newActivity);
  
  if (activities.length > 100) {
    activities.shift();
  }

  localStorage.setItem(ACTIVITY_KEY, JSON.stringify(activities));
}

export function getActivities(limit: number = 50): ActivityEvent[] {
  const stored = localStorage.getItem(ACTIVITY_KEY);
  const activities: ActivityEvent[] = stored ? JSON.parse(stored) : [];
  return activities.slice(-limit);
}

const activeEdits = new Map<string, { userId: string; userName: string; userColor: string; timestamp: number }>();

export function startEditing(entryId: string): void {
  const user = getCurrentUser();
  activeEdits.set(entryId, {
    userId: user.id,
    userName: user.name,
    userColor: user.color,
    timestamp: Date.now(),
  });

  addActivity({
    userId: user.id,
    userName: user.name,
    userColor: user.color,
    type: 'edit',
    entryId,
    description: `started editing entry`,
  });
}

export function stopEditing(entryId: string): void {
  activeEdits.delete(entryId);
}

export function getActiveEditors(entryId: string): { userId: string; userName: string; userColor: string } | null {
  const edit = activeEdits.get(entryId);
  if (edit && Date.now() - edit.timestamp < 60000) {
    return {
      userId: edit.userId,
      userName: edit.userName,
      userColor: edit.userColor,
    };
  }
  return null;
}

export function getComments(entryId: string): Comment[] {
  const stored = localStorage.getItem(`${COMMENTS_KEY}_${entryId}`);
  return stored ? JSON.parse(stored) : [];
}

export function addComment(entryId: string, text: string): Comment {
  const user = getCurrentUser();
  const comments = getComments(entryId);
  
  const newComment: Comment = {
    id: Math.random().toString(36).substr(2, 9),
    entryId,
    text,
    author: user.name,
    authorId: user.id,
    timestamp: Date.now(),
  };

  comments.push(newComment);
  localStorage.setItem(`${COMMENTS_KEY}_${entryId}`, JSON.stringify(comments));

  addActivity({
    userId: user.id,
    userName: user.name,
    userColor: user.color,
    type: 'comment',
    entryId,
    description: `added a comment`,
  });

  return newComment;
}

export function deleteComment(entryId: string, commentId: string): boolean {
  const comments = getComments(entryId);
  const filtered = comments.filter(c => c.id !== commentId);
  
  if (filtered.length < comments.length) {
    localStorage.setItem(`${COMMENTS_KEY}_${entryId}`, JSON.stringify(filtered));
    return true;
  }
  return false;
}

export function editComment(entryId: string, commentId: string, newText: string): boolean {
  const comments = getComments(entryId);
  const index = comments.findIndex(c => c.id === commentId);
  
  if (index !== -1) {
    comments[index].text = newText;
    comments[index].editedAt = Date.now();
    localStorage.setItem(`${COMMENTS_KEY}_${entryId}`, JSON.stringify(comments));
    return true;
  }
  return false;
}

export function getTotalCommentCount(entryIds: string[]): number {
  let count = 0;
  for (const entryId of entryIds) {
    count += getComments(entryId).length;
  }
  return count;
}

export interface RealTimeUpdate {
  type: 'entry_updated' | 'entry_reviewed' | 'entry_locked' | 'comment_added';
  entryId: string;
  userId: string;
  userName: string;
  data: any;
  timestamp: number;
}

const updateListeners: ((update: RealTimeUpdate) => void)[] = [];

export function subscribeToUpdates(callback: (update: RealTimeUpdate) => void): () => void {
  updateListeners.push(callback);
  return () => {
    const index = updateListeners.indexOf(callback);
    if (index !== -1) {
      updateListeners.splice(index, 1);
    }
  };
}

export function broadcastUpdate(update: Omit<RealTimeUpdate, 'timestamp'>): void {
  const fullUpdate: RealTimeUpdate = {
    ...update,
    timestamp: Date.now(),
  };

  localStorage.setItem('last_update', JSON.stringify(fullUpdate));
  updateListeners.forEach(listener => listener(fullUpdate));
}

window.addEventListener('storage', (e) => {
  if (e.key === 'last_update' && e.newValue) {
    const update: RealTimeUpdate = JSON.parse(e.newValue);
    const currentUser = getCurrentUser();
    
    if (update.userId !== currentUser.id) {
      updateListeners.forEach(listener => listener(update));
    }
  }
});

export function canEdit(userId?: string): boolean {
  const user = userId ? getCollaborators().find(c => c.id === userId) : getCurrentUser();
  if (!user) return false;
  return ['owner', 'admin', 'translator'].includes(user.role);
}

export function canReview(userId?: string): boolean {
  const user = userId ? getCollaborators().find(c => c.id === userId) : getCurrentUser();
  if (!user) return false;
  return ['owner', 'admin', 'reviewer'].includes(user.role);
}

export function canManageProject(userId?: string): boolean {
  const user = userId ? getCollaborators().find(c => c.id === userId) : getCurrentUser();
  if (!user) return false;
  return ['owner', 'admin'].includes(user.role);
}

export function generateShareLink(projectId: string, permission: 'view' | 'edit' = 'view'): string {
  const token = btoa(JSON.stringify({ projectId, permission, expires: Date.now() + 7 * 24 * 60 * 60 * 1000 }));
  return `${window.location.origin}/join?token=${token}`;
}

export function parseShareLink(token: string): { projectId: string; permission: 'view' | 'edit' } | null {
  try {
    const data = JSON.parse(atob(token));
    if (data.expires < Date.now()) {
      return null;
    }
    return { projectId: data.projectId, permission: data.permission };
  } catch (e) {
    return null;
  }
}

export function getCollaborationStats(): {
  totalCollaborators: number;
  activeEditors: number;
  totalComments: number;
  recentActivity: number;
} {
  const collaborators = getCollaborators();
  const activities = getActivities();
  
  const activeEditors = Array.from(activeEdits.values()).filter(
    edit => Date.now() - edit.timestamp < 5 * 60 * 1000
  ).length;

  const recentActivity = activities.filter(
    a => Date.now() - a.timestamp < 60 * 60 * 1000
  ).length;

  return {
    totalCollaborators: collaborators.length,
    activeEditors,
    totalComments: activities.filter(a => a.type === 'comment').length,
    recentActivity,
  };
}
