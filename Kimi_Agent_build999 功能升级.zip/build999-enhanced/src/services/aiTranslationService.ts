import type { TranslationResult, AIProviderConfig } from '@/types';

const BATCH_DELAY = 500;

const DEFAULT_PROVIDERS: AIProviderConfig[] = [
  {
    id: 'openrouter',
    name: 'OpenRouter',
    endpoint: 'https://openrouter.ai/api/v1/chat/completions',
    model: 'anthropic/claude-3.5-sonnet',
    temperature: 0.3,
    maxTokens: 2000,
    enabled: false,
  },
  {
    id: 'ollama',
    name: 'Ollama (Local)',
    endpoint: 'http://localhost:11434/api/generate',
    model: 'llama3',
    temperature: 0.3,
    maxTokens: 2000,
    enabled: false,
  },
];

export function getAIProviderConfig(providerId: string): AIProviderConfig | null {
  const stored = localStorage.getItem(`ai_provider_${providerId}`);
  if (stored) {
    return JSON.parse(stored);
  }
  return DEFAULT_PROVIDERS.find(p => p.id === providerId) || null;
}

export function saveAIProviderConfig(config: AIProviderConfig): void {
  localStorage.setItem(`ai_provider_${config.id}`, JSON.stringify(config));
}

export function getAllAIProviders(): AIProviderConfig[] {
  return DEFAULT_PROVIDERS.map(p => getAIProviderConfig(p.id) || p);
}

export async function translateWithAI(
  texts: string[],
  targetLang: string,
  engine: string,
  providerId: string = 'openrouter',
  context?: string,
  glossaryTerms?: Record<string, string>
): Promise<TranslationResult[]> {
  const config = getAIProviderConfig(providerId);
  if (!config || !config.enabled) {
    console.warn(`AI provider ${providerId} not configured or disabled`);
    return texts.map(t => ({ original: t, translated: t }));
  }

  const results: TranslationResult[] = [];

  for (const text of texts) {
    try {
      const translated = await translateSingleWithAI(text, targetLang, engine, config, context, glossaryTerms);
      results.push({ original: text, translated, provider: providerId });
      await delay(BATCH_DELAY);
    } catch (error) {
      console.error(`AI translation error:`, error);
      results.push({ original: text, translated: text });
    }
  }

  return results;
}

async function translateSingleWithAI(
  text: string,
  targetLang: string,
  engine: string,
  config: AIProviderConfig,
  context?: string,
  glossaryTerms?: Record<string, string>
): Promise<string> {
  const systemPrompt = buildSystemPrompt(targetLang, engine, glossaryTerms);
  const userPrompt = buildUserPrompt(text, targetLang, context);

  if (config.id === 'openrouter') {
    return await callOpenRouter(systemPrompt, userPrompt, config);
  } else if (config.id === 'ollama') {
    return await callOllama(systemPrompt, userPrompt, config);
  }

  return text;
}

async function callOpenRouter(
  systemPrompt: string,
  userPrompt: string,
  config: AIProviderConfig
): Promise<string> {
  const response = await fetch(config.endpoint!, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${config.apiKey}`,
      'HTTP-Referer': window.location.origin,
      'X-Title': 'Game Translation Hub',
    },
    body: JSON.stringify({
      model: config.model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt }
      ],
      temperature: config.temperature,
      max_tokens: config.maxTokens,
    }),
  });

  if (!response.ok) {
    throw new Error(`OpenRouter API error: ${response.status}`);
  }

  const data = await response.json();
  return extractTranslation(data.choices?.[0]?.message?.content || '');
}

async function callOllama(
  systemPrompt: string,
  userPrompt: string,
  config: AIProviderConfig
): Promise<string> {
  const response = await fetch(config.endpoint!, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      model: config.model,
      prompt: `${systemPrompt}\n\n${userPrompt}`,
      stream: false,
      options: {
        temperature: config.temperature,
        num_predict: config.maxTokens,
      },
    }),
  });

  if (!response.ok) {
    throw new Error(`Ollama API error: ${response.status}`);
  }

  const data = await response.json();
  return extractTranslation(data.response || '');
}

function buildSystemPrompt(
  targetLang: string,
  engine: string,
  glossaryTerms?: Record<string, string>
): string {
  let prompt = `You are a professional game translator specializing in ${targetLang} localization. 
Translate the following game text accurately while preserving the tone, style, and context.

Rules:
1. Maintain character personality and dialogue style
2. Preserve game terminology consistency
3. Keep formatting tags and placeholders intact (e.g., {name}, [variable], <color>)
4. Adapt cultural references appropriately for the target audience
5. Keep translations concise for UI elements
6. Preserve line breaks and spacing`;

  if (engine === 'rpgmaker') {
    prompt += '\n7. This is RPG Maker content - use appropriate RPG terminology';
  } else if (engine === 'renpy') {
    prompt += "\n7. This is Ren'Py visual novel content - maintain narrative flow and character voices";
  } else if (engine === 'kirikiri') {
    prompt += '\n7. This is KiriKiri visual novel content - preserve Japanese VN style and honorifics if appropriate';
  }

  if (glossaryTerms && Object.keys(glossaryTerms).length > 0) {
    prompt += '\n\nUse these glossary terms consistently:\n';
    Object.entries(glossaryTerms).forEach(([term, translation]) => {
      prompt += `- "${term}" → "${translation}"\n`;
    });
  }

  prompt += '\nRespond ONLY with the translated text, no explanations.';

  return prompt;
}

function buildUserPrompt(text: string, targetLang: string, context?: string): string {
  let prompt = `Translate to ${targetLang}:\n\n"${text}"`;
  
  if (context) {
    prompt += `\n\nContext: ${context}`;
  }

  return prompt;
}

function extractTranslation(response: string): string {
  let cleaned = response.trim();
  if (cleaned.startsWith('"') && cleaned.endsWith('"')) {
    cleaned = cleaned.slice(1, -1);
  }
  if (cleaned.startsWith("'") && cleaned.endsWith("'")) {
    cleaned = cleaned.slice(1, -1);
  }
  cleaned = cleaned.replace(/^Translation:\s*/i, '');
  return cleaned;
}

export async function getTranslationAlternatives(
  text: string,
  targetLang: string,
  engine: string,
  providerId: string = 'openrouter'
): Promise<string[]> {
  const config = getAIProviderConfig(providerId);
  if (!config || !config.apiKey) return [];

  try {
    const prompt = `Provide 3 alternative translations for this game text in ${targetLang}, with slightly different tones/styles.
Format: Number each option (1., 2., 3.) and provide only the translation text.

Text: "${text}"`;

    const response = await fetch(config.endpoint!, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.apiKey}`,
        'HTTP-Referer': window.location.origin,
      },
      body: JSON.stringify({
        model: config.model,
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7,
        max_tokens: 500,
      }),
    });

    if (!response.ok) return [];

    const data = await response.json();
    const content = data.choices?.[0]?.message?.content || '';
    
    const alternatives: string[] = [];
    const lines = content.split('\n');
    for (const line of lines) {
      const match = line.match(/^\d+[.\)]\s*(.+)$/);
      if (match) {
        alternatives.push(match[1].trim());
      }
    }

    return alternatives.slice(0, 3);
  } catch (error) {
    console.error('Error getting alternatives:', error);
    return [];
  }
}

function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export async function testAIProvider(providerId: string): Promise<{ success: boolean; message: string }> {
  const config = getAIProviderConfig(providerId);
  if (!config) {
    return { success: false, message: 'Provider not found' };
  }
  if (!config.apiKey && providerId === 'openrouter') {
    return { success: false, message: 'API key not configured' };
  }

  try {
    const testText = 'Hello, world!';
    const result = await translateSingleWithAI(testText, 'Indonesian', 'generic', config);
    if (result && result !== testText) {
      return { success: true, message: `Test successful! Translated: "${result}"` };
    }
    return { success: false, message: 'Translation returned empty or unchanged' };
  } catch (error: any) {
    return { success: false, message: error.message || 'Connection failed' };
  }
}
