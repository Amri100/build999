import type { TMEntry } from '@/types';

const TM_KEY = 'game_script_tm_v2';
const TM_INDEX_KEY = 'game_script_tm_index';

// In-memory cache for faster lookups
let tmCache: Record<string, TMEntry> | null = null;

export function saveToTM(original: string, translated: string, targetLang: string, engine: string): void {
  if (!original || !translated || original === translated) return;
  if (original.trim().length < 2) return; // Skip very short strings
  
  try {
    const tm = getTM();
    const key = createKey(original, targetLang);
    
    tm[key] = { 
      original: original.trim(), 
      translated: translated.trim(), 
      targetLang, 
      engine 
    };
    
    // Update index for faster searching
    updateIndex(original, targetLang);
    
    // Save to localStorage
    localStorage.setItem(TM_KEY, JSON.stringify(tm));
    tmCache = tm;
  } catch (e) {
    console.error('Error saving to TM:', e);
    // If storage is full, clear old entries
    if (e instanceof DOMException && e.name === 'QuotaExceededError') {
      cleanupOldEntries();
    }
  }
}

export function getTM(): Record<string, TMEntry> {
  if (tmCache) return tmCache;
  
  try {
    const stored = localStorage.getItem(TM_KEY);
    if (!stored) return {};
    const parsed = JSON.parse(stored);
    tmCache = parsed;
    return parsed;
  } catch (e) {
    console.error('Error loading TM:', e);
    return {};
  }
}

export function findInTM(original: string, targetLang: string): TMEntry | null {
  const tm = getTM();
  const key = createKey(original, targetLang);
  
  // Exact match
  if (tm[key]) {
    return tm[key];
  }
  
  // Fuzzy match - look for similar strings
  const normalizedOriginal = normalizeString(original);
  for (const entry of Object.values(tm)) {
    if (entry.targetLang === targetLang) {
      const normalizedEntry = normalizeString(entry.original);
      if (normalizedEntry === normalizedOriginal) {
        return entry;
      }
      // Check for high similarity (80% match)
      if (calculateSimilarity(normalizedOriginal, normalizedEntry) > 0.8) {
        return entry;
      }
    }
  }
  
  return null;
}

export function searchTM(query: string, targetLang?: string): TMEntry[] {
  const tm = getTM();
  const normalizedQuery = normalizeString(query);
  const results: TMEntry[] = [];
  
  for (const entry of Object.values(tm)) {
    if (targetLang && entry.targetLang !== targetLang) continue;
    
    const normalizedOriginal = normalizeString(entry.original);
    const normalizedTranslated = normalizeString(entry.translated);
    
    if (normalizedOriginal.includes(normalizedQuery) || 
        normalizedTranslated.includes(normalizedQuery) ||
        calculateSimilarity(normalizedOriginal, normalizedQuery) > 0.6) {
      results.push(entry);
    }
  }
  
  return results.slice(0, 50); // Limit results
}

export function clearTM(): void {
  localStorage.removeItem(TM_KEY);
  localStorage.removeItem(TM_INDEX_KEY);
  tmCache = {};
}

export function getTMStats(): { total: number; byLanguage: Record<string, number> } {
  const tm = getTM();
  const entries = Object.values(tm);
  
  const byLanguage: Record<string, number> = {};
  entries.forEach(entry => {
    byLanguage[entry.targetLang] = (byLanguage[entry.targetLang] || 0) + 1;
  });
  
  return {
    total: entries.length,
    byLanguage
  };
}

export function exportTM(): string {
  const tm = getTM();
  return JSON.stringify(tm, null, 2);
}

export function importTM(jsonString: string): boolean {
  try {
    const data = JSON.parse(jsonString);
    if (typeof data === 'object' && data !== null) {
      localStorage.setItem(TM_KEY, JSON.stringify(data));
      tmCache = data;
      return true;
    }
    return false;
  } catch (e) {
    console.error('Error importing TM:', e);
    return false;
  }
}

// Helper functions
function createKey(original: string, targetLang: string): string {
  // Create a hash of the original text for the key
  const normalized = normalizeString(original);
  return `${targetLang}:${normalized}`;
}

function normalizeString(str: string): string {
  return str
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/[^\w\s]/g, '')
    .trim();
}

function calculateSimilarity(str1: string, str2: string): number {
  if (str1 === str2) return 1;
  if (!str1.length || !str2.length) return 0;
  
  const longer = str1.length > str2.length ? str1 : str2;
  const shorter = str1.length > str2.length ? str2 : str1;
  
  if (longer.length === 0) return 1;
  
  const distance = levenshteinDistance(longer, shorter);
  return (longer.length - distance) / longer.length;
}

function levenshteinDistance(str1: string, str2: string): number {
  const matrix: number[][] = [];
  
  for (let i = 0; i <= str2.length; i++) {
    matrix[i] = [i];
  }
  
  for (let j = 0; j <= str1.length; j++) {
    matrix[0][j] = j;
  }
  
  for (let i = 1; i <= str2.length; i++) {
    for (let j = 1; j <= str1.length; j++) {
      if (str2.charAt(i - 1) === str1.charAt(j - 1)) {
        matrix[i][j] = matrix[i - 1][j - 1];
      } else {
        matrix[i][j] = Math.min(
          matrix[i - 1][j - 1] + 1,
          matrix[i][j - 1] + 1,
          matrix[i - 1][j] + 1
        );
      }
    }
  }
  
  return matrix[str2.length][str1.length];
}

function updateIndex(original: string, targetLang: string): void {
  try {
    const indexStr = localStorage.getItem(TM_INDEX_KEY);
    const index = indexStr ? JSON.parse(indexStr) : {};
    
    const words = original.toLowerCase().split(/\s+/);
    words.forEach(word => {
      if (word.length > 2) {
        if (!index[word]) index[word] = [];
        if (!index[word].includes(targetLang)) {
          index[word].push(targetLang);
        }
      }
    });
    
    localStorage.setItem(TM_INDEX_KEY, JSON.stringify(index));
  } catch (e) {
    console.error('Error updating TM index:', e);
  }
}

function cleanupOldEntries(): void {
  try {
    const tm = getTM();
    const entries = Object.entries(tm);
    
    // Keep only the most recent 1000 entries
    if (entries.length > 1000) {
      const sortedEntries = entries.slice(-1000);
      const newTm: Record<string, TMEntry> = {};
      sortedEntries.forEach(([key, value]) => {
        newTm[key] = value;
      });
      
      localStorage.setItem(TM_KEY, JSON.stringify(newTm));
      tmCache = newTm;
    }
  } catch (e) {
    console.error('Error cleaning up TM:', e);
  }
}
