export interface GameScriptEntry {
  id: string;
  original: string;
  translated: string;
  context?: string;
  path: string;
  tmEngineMatch?: string;
  // New fields
  notes?: string;              // Translator notes/comments
  reviewed?: boolean;          // Mark as reviewed
  locked?: boolean;            // Lock entry from auto-translation
  tags?: string[];             // Tags for categorization
  maxLength?: number;          // Maximum character limit
  createdAt?: number;          // When entry was created
  updatedAt?: number;          // When entry was last updated
  translatedBy?: string;       // Who translated this (for collaboration)
  reviewedBy?: string;         // Who reviewed this
}

export interface TranslationProject {
  id: string;
  name: string;
  engine: "kirikiri" | "rpgmaker" | "renpy" | "unity" | "generic" | "subtitles" | "tyrano" | "vnmaker" | "wolf" | "gamemaker";
  entries: GameScriptEntry[];
  files: { name: string; content: string }[];
  // New fields
  createdAt?: number;
  updatedAt?: number;
  sourceLang?: string;
  targetLang?: string;
  description?: string;
}

export interface TMEntry {
  original: string;
  translated: string;
  targetLang: string;
  engine: string;
  createdAt?: number;
  useCount?: number;
}

export interface TranslationResult {
  original: string;
  translated: string;
  confidence?: number;
}

export type TranslationProvider = 'gemini' | 'google' | 'bing' | 'mymemory' | 'lingva' | 'offline' | 'openrouter' | 'ollama';

export interface EngineConfig {
  name: string;
  description: string;
  extensions: string[];
  color: string;
  icon: string;
}

export interface Comment {
  id: string;
  entryId: string;
  text: string;
  author: string;
  timestamp: number;
}

export interface ProjectStats {
  total: number;
  translated: number;
  reviewed: number;
  locked: number;
  withNotes: number;
  byTag: Record<string, number>;
  completionPercent: number;
}

// === NEW ENHANCED TYPES ===

// AI Translation Types
export interface AIProviderConfig {
  provider: 'openrouter' | 'ollama';
  apiKey?: string;
  endpoint?: string;
  model: string;
  temperature: number;
  maxTokens: number;
}

export interface OpenRouterModel {
  id: string;
  name: string;
  description: string;
  contextLength: number;
}

export interface OllamaModel {
  name: string;
  size: number;
  parameterSize?: string;
}

// Export/Import Types
export type ExportFormat = 'zip' | 'json' | 'csv' | 'xlsx' | 'po' | 'xliff' | 'yaml';

export interface ExportConfig {
  format: ExportFormat;
  includeMetadata?: boolean;
  includeComments?: boolean;
  includeHistory?: boolean;
  onlyTranslated?: boolean;
  onlyApproved?: boolean;
  preserveStructure?: boolean;
}

// Collaboration Types
export interface CollaborationUser {
  id: string;
  name: string;
  email: string;
  avatar?: string;
  status: 'online' | 'away' | 'busy' | 'offline';
  currentEntry?: string;
  lastSeen?: number;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  action: 'translate' | 'review' | 'comment' | 'join' | 'leave' | 'import' | 'export';
  entryId?: string;
  entryKey?: string;
  details?: string;
  timestamp: Date;
}

export interface TeamComment {
  id: string;
  entryId?: string;
  content: string;
  author: CollaborationUser;
  timestamp: Date;
  replies?: TeamComment[];
}

// Backup Types
export interface BackupInfo {
  id: string;
  projectId: string;
  projectName: string;
  timestamp: Date;
  size: number;
  compressed: boolean;
  entries: number;
}

export interface BackupSettings {
  autoBackup: boolean;
  backupInterval: number; // in minutes
  maxBackups: number;
  includeHistory: boolean;
  compressBackups: boolean;
}

// Enhanced Entry Types
export interface EnhancedGameScriptEntry extends GameScriptEntry {
  comments?: TeamComment[];
  aiSuggestions?: string[];
  similarityScore?: number; // For TM fuzzy matching
  glossaryMatches?: GlossaryMatch[];
}

export interface GlossaryMatch {
  term: string;
  translation: string;
  position: number;
  length: number;
}

// Project Settings
export interface ProjectSettings {
  autoTranslate: boolean;
  autoSave: boolean;
  qaEnabled: boolean;
  glossaryEnforced: boolean;
  maxSuggestions: number;
}
