export interface GameScriptEntry {
  id: string;
  original: string;
  translated: string;
  context?: string;
  path: string;
  tmEngineMatch?: string;
  // New fields
  notes?: string;              // Translator notes/comments
  reviewed?: boolean;          // Mark as reviewed
  locked?: boolean;            // Lock entry from auto-translation
  tags?: string[];             // Tags for categorization
  maxLength?: number;          // Maximum character limit
  createdAt?: number;          // When entry was created
  updatedAt?: number;          // When entry was last updated
  translatedBy?: string;       // Who translated this (for collaboration)
  reviewedBy?: string;         // Who reviewed this
}

export interface TranslationProject {
  id: string;
  name: string;
  engine: "kirikiri" | "rpgmaker" | "renpy" | "unity" | "generic" | "subtitles";
  entries: GameScriptEntry[];
  files: { name: string; content: string }[];
  // New fields
  createdAt?: number;
  updatedAt?: number;
  sourceLang?: string;
  targetLang?: string;
  description?: string;
}

export interface TMEntry {
  original: string;
  translated: string;
  targetLang: string;
  engine: string;
  createdAt?: number;
  useCount?: number;
}

export interface TranslationResult {
  original: string;
  translated: string;
  confidence?: number;
}

export type TranslationProvider = 'gemini' | 'google' | 'bing' | 'mymemory' | 'lingva' | 'offline';

export interface EngineConfig {
  name: string;
  description: string;
  extensions: string[];
  color: string;
  icon: string;
}

export interface Comment {
  id: string;
  entryId: string;
  text: string;
  author: string;
  timestamp: number;
}

export interface ProjectStats {
  total: number;
  translated: number;
  reviewed: number;
  locked: number;
  withNotes: number;
  byTag: Record<string, number>;
  completionPercent: number;
}
